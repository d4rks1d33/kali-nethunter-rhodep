#!/usr/bin/env python3
# Find a monotonic-increasing table of u32 whose values span 0..~0x2444000
# (the .clade.comp compressed-data size). Such a table would be the CLADE
# metadata (per-page compressed byte-offset, or bit-offset).
import numpy as np, glob, os

MAXV = 0x2444000
files = sorted(glob.glob('/tmp/clade/modem.b*'))
best = []
for f in files:
    raw = open(f,'rb').read()
    a = np.frombuffer(raw[:len(raw)//4*4], dtype='<u4').astype(np.int64)
    n = len(a)
    if n < 100: continue
    # slide a window; find longest run where a is strictly increasing and in [0,MAXV]
    inrange = (a >= 0) & (a <= MAXV)
    incr = np.zeros(n, dtype=bool)
    incr[1:] = a[1:] > a[:-1]
    # a position is "good" if inrange and (first or incr)
    i = 0
    while i < n:
        if not inrange[i]:
            i += 1; continue
        j = i+1
        while j < n and inrange[j] and a[j] > a[j-1]:
            j += 1
        runlen = j - i
        if runlen >= 200:
            best.append((runlen, os.path.basename(f), i*4, int(a[i]), int(a[j-1])))
        i = j
best.sort(reverse=True)
for runlen, fn, fo, v0, vN in best[:30]:
    print(f"{fn} foff 0x{fo:x} len {runlen}  first={v0:x} last={vN:x}")
print("total runs>=200:", len(best))
