# CLADE / q6zip RE tools — the two repos that cracked the modem decompression

Preserved so the exact tool versions used are kept. Both cloned 2026-09-24.

> **IMPORTANT — do NOT re-clone these from GitHub.** Both repos here have LOCAL
> changes of ours that upstream does not have, and the project depends on them.
> A fresh clone would be incomplete/different and would NOT decompress this
> modem correctly. Use THIS copy. Each repo has a `LOCAL-CHANGES.md` explaining
> exactly what we added and why; `git status` in each also shows our files as
> untracked.

## qualcomm-q6zip (nlitsme)
- URL: https://github.com/nlitsme/qualcomm-q6zip
- pinned commit: `ecf58b7`
- **Our change:** `unclade_exc.py` — the CLADE decoder with the exception-marker
  fix (upstream `unclade.py` mis-reads CLADE code `0b11` as an inline 32-bit
  literal; it is actually a zero-bit exception marker, which desynced the stream
  and corrupted ~26% of words). See its `LOCAL-CHANGES.md`.

## qualcomm_baseband_scripts (mzakocs)
- URL: https://github.com/mzakocs/qualcomm_baseband_scripts
- pinned commit: `1bd9198`
- Ships **`libclade.so`** — the real Qualcomm CLADE codec (x86-64) with the
  exception words implemented, which gave the HW-accurate decompression.
- **Our additions:** `clade_extractor_sm6375.c` (+ `.h`, + the built binary) —
  our SM6375 harness derived from the repo's Pixel-5 extractor. See its
  `LOCAL-CHANGES.md`.

## How they were used together
1. Found the CLADE dicts in modem.b26 (offsets 0x2444000/0x2446000/0x2448000),
   .clade.comp = b26 @ 0.
2. Built `clade_extractor_sm6375` against `libclade.so`, ran it under
   `qemu-x86_64-static`.
3. Got `clade_dec_full.bin` (10 MB of clean Hexagon), from which the FTM RF-test
   protocol was decoded. See `../clade-re-preserve.tgz` and the git repo's
   `docs/modem-diag-wip/blob-analysis/`.
