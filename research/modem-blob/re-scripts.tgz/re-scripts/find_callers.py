import struct, sys

BASE = 0xd8000000
data = open('/tmp/modemre/clade_dec_full.bin','rb').read()

def find_calls(target):
    """Find hexagon 'call' (J2_call) instructions targeting `target`.
    Encoding: 0101 1101 ... PC-relative 24-bit (with parity bits scattered).
    We brute force: for each 4-byte word, decode as call and check target."""
    res=[]
    for off in range(0, len(data)-4, 4):
        w = struct.unpack('<I', data[off:off+4])[0]
        # J2_call: bits[31:28]=0101 (0x5), bit27=1, bit26=0 ... top byte 0x5d for call, 0x5b immext-less?
        top = (w>>24)&0xff
        if top not in (0x5b,0x5d):  # call variants
            continue
        # extract imm: bits [24:16] and [13:1]
        # Hexagon J2_call: imm22 = { b[24:16], b[13:1] } << 2 sign extended
        b_hi = (w>>16)&0x1ff   # 9 bits
        b_lo = (w>>1)&0x1fff   # 13 bits
        imm = (b_hi<<13)|b_lo  # 22 bits
        if imm & (1<<21):
            imm -= (1<<22)
        va = BASE+off
        tgt = va + (imm<<2)
        if tgt == target:
            res.append(va)
    return res

if __name__=='__main__':
    tgt=int(sys.argv[1],0)
    for va in find_calls(tgt):
        print(hex(va))
