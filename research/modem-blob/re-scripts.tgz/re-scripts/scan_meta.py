import sys, struct
sys.path.insert(0,'/tmp/q6zip')
import ELF

elf=ELF.read(open('/tmp/modemre/modem_full.elf','rb'))
fh=open('/tmp/modemre/modem_full.elf','rb')
segs=[s for s in elf.pgm if (s.type<=1 and s.filesize>0)]

# We look for a page-pointer/offset table. dlpager pages are typically 0x1000 (4KB)
# uncompressed. seg26 compressed size 0x213a000 ~= 34.8MB. If it maps 0x1000-pages,
# number of pages ~ (0x2139000/0x1000) = 8505 if 1:1, but compressed so table entries
# are offsets into compressed data increasing by ~ (compressed page size, 0..0x1000).
# Table could be absolute (0xcc.. / 0xd4..) or relative (0..0x213a000).
# Scan for long monotonic non-decreasing runs with average delta 0x100..0x1000.

def scan(lo, hi, name, minlen=1000, maxdelta=0x1800):
    res=[]
    for s in segs:
        fh.seek(s.fileoffset); data=fh.read(s.filesize)
        n=len(data)//4; words=struct.unpack_from('<%dL'%n,data,0)
        i=0
        while i<n-minlen:
            if not (lo<=words[i]<hi):
                i+=1; continue
            j=i+1; prev=words[i]; ok=True
            while j<n:
                w=words[j]
                if lo<=w<hi and prev<=w and (w-prev)<maxdelta:
                    prev=w; j+=1
                else:
                    break
            if j-i>=minlen:
                res.append((name,s.vaddr+i*4,j-i,words[i],words[j-1]))
                i=j
            else:
                i+=1
    return res

ranges=[
 ('abs_seg26',0xcc000000,0xce13a000),
 ('rel_off',   0x0,       0x213b000),
 ('rel_small', 0x0,       0x40000),
 ('d4win',     0xd4400000,0xd6539000),
]
allr=[]
for nm,lo,hi in ranges:
    allr+=scan(lo,hi,nm)
allr.sort(key=lambda x:-x[2])
print("candidate meta tables (name,va,len,first,last):")
for nm,va,l,f,la in allr[:30]:
    print("  %-10s @%08x len=%6d [%08x..%08x] avgdelta=%d"%(nm,va,l,f,la,(la-f)//max(1,l-1)))
