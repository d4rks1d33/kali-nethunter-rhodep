#!/usr/bin/env python3
# Measure, per 4KB page of the linearly-decompressed CLADE output, the fraction
# of 32-bit words that are valid Hexagon-ish. Heuristic validity: a word is
# "plausible" if its top nibble (instruction class) is a known Hexagon iclass
# and it is not a rare/garbage pattern. Better: count immext+jump/call target
# sanity. We approximate by checking iclass distribution.
import struct, sys

d=open('/tmp/modemre/clade_full_linear.bin','rb').read()
n=len(d)//4
import numpy as np
a=np.frombuffer(d[:n*4],dtype='<u4')

# Hexagon instruction encoding: bits 31..28 = iclass (parse bits 15..14 separate).
# Valid iclasses 0x0..0xf mostly used. Garbage indicator: words that are 0 or all-f
# in the middle of code, or iclass patterns that never occur.
# A stronger signal: count of valid CALL/JUMP whose target lands in 0xc0..0xda range.
top=a>>28
# call: iclass 0x5 (J), jump also 0x5. Let's just measure entropy-free proxy:
# fraction of words that are exactly 0x00000000 (padding/garbage in code = bad)
PAGES=n//1024
print("pages:",PAGES)
for pg in range(0, min(PAGES, 400)):
    seg=a[pg*1024:(pg+1)*1024]
    zeros=int((seg==0).sum())
    allf=int((seg==0xffffffff).sum())
    # immext words have iclass 0x0 with bits pattern 0000 fixed: 0x0??????? high nibble 0
    # crude 'looks like code' = fraction with top nibble in {5,6,7,8,9,a,b,c,e,f,1,2,3}
    tn=seg>>28
    codey=int(np.isin(tn,[1,2,3,5,6,7,8,9,0xa,0xb,0xc,0xe,0xf]).sum())
    if pg in range(330,342) or pg<3 or pg%50==0:
        print(f"page {pg:4d} va {0xd8000000+pg*0x1000:08x}: zeros={zeros:4d} allf={allf:3d} codey={codey}/1024")
