#!/usr/bin/env python3
# Decompress CLADE page-by-page, each page = 1024 output words, with the
# NEXT page starting at the next 32-bit-word boundary of the compressed stream.
# Record the comp word-offset of each page. Then extract the page containing
# a target vaddr and disassemble.
import sys, struct
sys.path.insert(0,'/tmp/q6zip')
from unclade import BitStreamReader, CladeDecompressor, decodewords

raw=open('/tmp/clade/modem.b26','rb').read()
DICTBASE=0x2444000
COMP_END=DICTBASE  # comp data ends where dict begins (approx)
dicts=[list(decodewords(raw[DICTBASE+i*0x2000:DICTBASE+(i+1)*0x2000])) for i in range(3)]
C=CladeDecompressor(dicts)

REGION_BASE=0xd8000000
PAGE_WORDS=1024

def decode_page(words, start_word, skipfirst):
    """Decode 1024 output words starting at compressed word index start_word.
    Returns (out_words, next_word_index, ok)."""
    bits=BitStreamReader(words)
    # fast-forward reader to start_word
    bits.pos=start_word-1
    bits.bitpos=32
    out=[]
    if skipfirst:
        bits.get(1)
    try:
        while len(out)<PAGE_WORDS:
            code=bits.get(2)
            if code<3:
                idx=bits.get(11)
                missing=bits.get(len(C.missingbits[code]))
                out.append(C.reconstructword(dicts[code][idx],C.missingbits[code],missing))
            else:
                out.append(bits.get(32))
    except EOFError:
        return out, None, False
    # next page: round up to next word boundary
    consumed_word = bits.pos + (1 if bits.bitpos>0 and bits.bitpos<32 else 0)
    # if exactly at word boundary (bitpos==32 means just finished a word)
    if bits.bitpos>=32:
        next_word=bits.pos+1
    else:
        next_word=bits.pos+1  # current partial word is consumed; next page word-aligned
    return out, next_word, True

def main():
    target=int(sys.argv[1],0) if len(sys.argv)>1 else 0xd8150ed8
    target_page=(target-REGION_BASE)//0x1000
    words=list(decodewords(raw[0:COMP_END]))
    sw=0
    skipfirst=True
    pages=[]
    for pg in range(target_page+2):
        out,nw,ok=decode_page(words, sw, skipfirst)
        if not ok:
            print(f"page {pg}: EOF at compword {sw}"); break
        pages.append((pg, sw, nw))
        if pg==target_page:
            data=struct.pack('<%dL'%len(out), *out)
            open('/tmp/modemre/clade_page_target.bin','wb').write(data)
            print(f"page {pg} vaddr {REGION_BASE+pg*0x1000:08x} compword {sw} (byte {sw*4:x}) -> {len(out)} words")
        sw=nw
        skipfirst=True  # each page skips its own first bit? test both
    print("first 8 pages compword starts:", [(p, s) for p,s,n in pages[:8]])

main()
