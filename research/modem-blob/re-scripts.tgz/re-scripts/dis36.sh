#!/bin/bash
# dis36.sh <vaddr_hex> <len_hex> -- disassemble from clade_dec_36m.bin (base 0xd8000000)
VA=$1
LEN=$2
BASE=0xd8000000
BIN=/tmp/modemre/clade_dec_36m.bin
python3 - "$VA" "$LEN" "$BASE" "$BIN" <<'PY'
import sys
va=int(sys.argv[1],0); ln=int(sys.argv[2],0); base=int(sys.argv[3],0); binf=sys.argv[4]
off=va-base
data=open(binf,'rb').read()
end=off+ln
if off<0 or end>len(data):
    sys.stderr.write("RANGE OUT OF 36MB BIN len=%d off=%d\n"%(len(data),off)); sys.exit(2)
open('/tmp/_dis36.bin','wb').write(data[off:end])
PY
if [ $? -ne 0 ]; then exit 2; fi
python3 /tmp/modemre/mkelf.py /tmp/_dis36.bin $VA /tmp/_dis36.elf >/dev/null
llvm-objdump-18 -d --triple=hexagon --mcpu=hexagonv66 /tmp/_dis36.elf | sed '1,6d'
