#!/usr/bin/env python3
import struct,subprocess,sys
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack('<I',data[i:i+4])[0] for i in range(0,N-3,4)]
sys.path.insert(0,'/tmp/modemre')
from mkelf import make_elf

# find ALL immext words that carry 0xcbf4f740 aligned base (0cbf53dd) OR any base whose
# combination with a store to 0xcbf4f740 is possible. We already have the 3dd list.
# For each 3dd site, disassemble 4 packets and look for a store whose target resolves to 0xcbf4f740.
def dis(va,n=6):
    off=va-BASE
    make_elf(data[off:off+n*4],va,'/tmp/_x.elf')
    out=subprocess.check_output(['llvm-objdump-18','-d','--triple=hexagon','--mcpu=hexagonv66','/tmp/_x.elf']).decode()
    return "\n".join(out.splitlines()[7:])

IMMEXT=0x0cbf53dd
sites=[BASE+i*4 for i,w in enumerate(words) if w==IMMEXT]
for va in sites:
    d=dis(va,4)
    if '0xcbf4f740)' in d and ('=' in d):
        # store or load to exact gate
        print("==== %08x ===="%va)
        print(d)
        print()
