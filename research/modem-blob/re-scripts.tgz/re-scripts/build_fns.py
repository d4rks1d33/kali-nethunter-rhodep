#!/usr/bin/env python3
# Build a function boundary table from the disasm index by detecting prologues, then compute
# sound call-graph reachability scanning each function's FULL extent [start, next_start).
import re, bisect, pickle
LINES={};ORDER=[]
for ln in open('/tmp/modemre/_idx.txt'):
    m=re.match(r'([0-9a-f]{8}):',ln)
    if m:
        a=int(m.group(1),16)
        if a not in LINES: LINES[a]=ln;ORDER.append(a)
ORDER.sort()

# Prologue detection: a packet that contains 'allocframe(' AND is (typically) preceded by a
# stack-check call in the same packet, OR any allocframe that opens a frame. We treat every
# 'allocframe(' line as a function start candidate (Hexagon frames open functions). We also add
# leaf functions: lines that are the target of a call but have no allocframe — handled separately.
starts=set()
for a in ORDER:
    if 'allocframe(' in LINES[a]:
        # the function starts at the beginning of the packet. The stack-check 'call 0xd8829xxx' or
        # 'call 0xd814e6ac' is one packet earlier (4 bytes). Use a-4 if that line is such a call.
        prev=a-4
        if prev in LINES and re.search(r'call 0x(d8829[0-9a-f]+|d814e6ac)', LINES[prev]):
            starts.add(prev)
        else:
            starts.add(a)
S=sorted(starts)
pickle.dump((LINES,ORDER,S), open('/tmp/modemre/_fns.pkl','wb'))
print("num prologues:", len(S))
print("sample:", [hex(x) for x in S[:5]])
