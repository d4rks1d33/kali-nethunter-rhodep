#!/usr/bin/env python3
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack('<I',data[i:i+4])[0] for i in range(0,N-3,4)]

IMMEXT=0x0cbf53dd  # immext(#0xcbf4f740)

# absolute store encodings (from earlier): 
#   memb(##addr)=r0 -> 0x4800c000 (reg in some field)
#   memw(##addr)=r0 -> 0x4880c000
# absolute store immediate: memb(##addr)=#imm ?
# Let's just, for every IMMEXT site, decode the paired instr and flag stores.
def classify(w):
    top=(w>>24)&0xff
    # 0x48 = S2 absolute store family (memX(##)=Rt)
    # 0x3c = store immediate to [Rs+#u]=#S (memb(r+#)=#imm)
    # 0x49 = load absolute
    # 0x9f = load absolute conditional
    # 0xaf = conditional store absolute memb(##)=Rt (if(!p) ...)
    return top

hits=[]
for i,w in enumerate(words):
    if w==IMMEXT:
        va=BASE+i*4
        nxt=words[i+1] if i+1<len(words) else 0
        nxt2=words[i+2] if i+2<len(words) else 0
        hits.append((va,nxt,nxt2))

for va,nxt,nxt2 in hits:
    t=classify(nxt); t2=classify(nxt2)
    tag=""
    if t in (0x48,0xaf,0x3c): tag="<<STORE(paired)"
    if t2 in (0x48,0xaf,0x3c): tag+=" STORE(next2)"
    print("%08x paired=%08x(%02x) next2=%08x(%02x) %s"%(va,nxt,t,nxt2,t2,tag))
