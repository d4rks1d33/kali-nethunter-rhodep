#!/usr/bin/env python3
# Trace upward from a function start: find callers, map each to its enclosing function, repeat,
# until we reach a known wrapper/dispatcher or hit depth limit. Print the call tree.
import subprocess, re, sys, struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_full.bin','rb').read()
DIS='/tmp/modemre/dis.sh'

def val_imm(w):
    b_hi=(w>>16)&0x1ff; b_lo=(w>>1)&0x1fff
    imm=(b_hi<<13)|b_lo
    if imm&(1<<21): imm-=(1<<22)
    return imm<<2
def callers(target):
    res=[]
    for off in range(0,len(data)-4,4):
        w=struct.unpack('<I',data[off:off+4])[0]
        op7=(w>>25)&0x7f
        va=BASE+off
        if op7==0b0101101 and va+val_imm(w)==target: res.append(va)
        if op7==0b0101100 and va+val_imm(w)==target: res.append(('J',va))
    return res
def dis(va,ln): return subprocess.run([DIS,hex(va),hex(ln)],capture_output=True,text=True).stdout
def fn_start(va, back=0x600):
    txt=dis(va-back, back+0x10); starts=[]
    for ln in txt.splitlines():
        m=re.match(r'\s*([0-9a-f]+):',ln)
        if not m: continue
        addr=int(m.group(1),16)
        if addr>va: break
        if 'allocframe' in ln: starts.append(addr)
    return starts[-1] if starts else None

WRAPPERS={0xd86fcf84:'slot0',0xd827176c:'slot1/err',0xd86fd0f4:'0x1002',0xd86fd230:'0x1003',
 0xd86fd328:'0x1004',0xd86fd474:'0x1005',0xd8271c94:'0x1006',0xd86fdb88:'0x1007',
 0xd86fd5c8:'0x1008',0xd86fd80c:'0x1009',0xd86fda68:'0x100a',0xd86fe120:'0x100b',
 0xd86fe1e4:'0x100c',0xd86fde80:'0x100d',0xd86fe0a4:'0x100e',0xd86fdf94:'0x100f',
 0xd82722c4:'0x1010',0xd8271b64:'0x1011',0xd8271bcc:'0x1012',0xd8271774:'0x1013err',
 0xd86fe300:'0x1014',0xd86fe558:'0x1015',0xd86fe60c:'0x1016',0xd86fe7e0:'0x1017',
 0xd82714b4:'DISPATCH_10xx'}

def trace(start, depth=0, maxd=10, seen=None):
    if seen is None: seen=set()
    if start in seen or depth>maxd: return
    seen.add(start)
    tag=WRAPPERS.get(start,'')
    print('  '*depth+f"{hex(start)} {tag}")
    if tag: return
    cs=callers(start)
    if not cs:
        print('  '*(depth+1)+"(no static callers -> runtime/callr bound)")
        return
    parents=set()
    for c in cs:
        cva=c[1] if isinstance(c,tuple) else c
        fs=fn_start(cva)
        if fs: parents.add(fs)
        else: print('  '*(depth+1)+f"caller {hex(cva)} (no fn start)")
    for p in sorted(parents):
        trace(p, depth+1, maxd, seen)

if __name__=='__main__':
    trace(int(sys.argv[1],0))
