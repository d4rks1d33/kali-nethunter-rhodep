#!/usr/bin/env python3
# Scan the 10MB decompressed code for 32-bit little-endian occurrences of a target value.
# Reports file offset and vaddr. Useful for finding immext-encoded constants / pointer refs.
import sys,struct
base=0xd8000000
data=open('/tmp/modemre/clade_dec_full.bin','rb').read()
targets=[int(x,0) for x in sys.argv[1:]]
for t in targets:
    tb=struct.pack('<I',t & 0xffffffff)
    print(f"=== target 0x{t:08x} ===")
    idx=0
    hits=0
    while True:
        i=data.find(tb,idx)
        if i<0: break
        va=base+i
        aligned = (i%4==0)
        print(f"  off=0x{i:06x} va=0x{va:08x} aligned={aligned}")
        idx=i+1
        hits+=1
        if hits>200:
            print("  ... (truncated)")
            break
    if hits==0:
        print("  (none)")
