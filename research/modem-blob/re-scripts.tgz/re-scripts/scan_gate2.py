#!/usr/bin/env python3
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)

# immext words that carry a base reaching 0xcbf4f740 with offset in [0,0x40)
# base -> low6 offset needed to reach 0xcbf4f740
targets = {
 0x0cbf53dd: 0x00,  # base 0xcbf4f740
 0x0cbf53dc: 0x40,  # base 0xcbf4f700 + 0x40
 0x0cbf53db: 0x80,  # base 0xcbf4f6c0 + 0x80 (too big for memb? memb offset up to?)
 0x0cbf53da: 0xc0,  # base 0xcbf4f680
 0x0cbf53c0: 0x740, # gp/base 0xcbf4f000 + 0x740
}

words=[struct.unpack('<I',data[i:i+4])[0] for i in range(0,N-3,4)]

hits=[]
for i,w in enumerate(words):
    if w in targets:
        va=BASE+i*4
        # print this word and next 2 words (the paired instruction + following)
        ctx=[words[i+k] for k in range(0,4) if i+k<len(words)]
        hits.append((va,w,ctx))

print("total immext hits:",len(hits))
for va,w,ctx in hits:
    print("%08x immext=%08x next=%s"%(va,w," ".join("%08x"%c for c in ctx[1:])))
