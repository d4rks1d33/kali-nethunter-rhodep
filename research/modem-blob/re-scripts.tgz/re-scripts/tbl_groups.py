import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va, seg_of
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]
    n=d.find(b'\x00')
    if n<0: n=maxlen
    try: return d[:n].decode('ascii')
    except: return None
def is_name_ptr(v):
    if v is None or not is_valid_va(v): return False
    s=cstr(v,64)
    if not s: return False
    if len(s)<2 or len(s)>40: return False
    return all(c.isupper() or c.isdigit() or c in '_ ' for c in s)

# Escanear ampliamente desde 0xc906c260 hasta donde empiece la tabla de handlers (0xc906ceb0)
# Marcar grupos: un grupo empieza tras UNASSIGNED, y 0x00000000 separa.
start=0xc906c260
end=0xc906cf00
va=start
idx_in_group=0
group_no=0
out=[]
while va<end:
    v=u32(va)
    s=cstr(v) if is_valid_va(v) else None
    if v==0:
        out.append((va,None,"---ZERO---",group_no,idx_in_group))
        # zero could be group separator
    elif s=='UNASSIGNED':
        group_no+=1
        idx_in_group=0
        out.append((va,v,"UNASSIGNED (grp %d start)"%group_no,group_no,0))
    elif is_name_ptr(v):
        out.append((va,v,s,group_no,idx_in_group))
        idx_in_group+=1
    else:
        out.append((va,v,"<%08x non-name>"%v,group_no,idx_in_group))
    va+=4
for va,v,s,g,ix in out:
    print("0x%08x  g%02d[%3d]  %s"%(va,g,ix,s))
