#!/usr/bin/env python3
# SOUND forward reachability: only static call/jump edges + an explicit resolved-callr edge table.
# No blanket immediate heuristic (avoids false positives).
import subprocess, re, sys
DIS='/tmp/modemre/dis.sh'
LO,HI=0xd8000000,0xd8a00000
SETTER=0xd8279264; GETTER=0xd827923c; APPLY=0xd8273b2c
EXECS={0xd826d7b0,0xd826d9b4,0xd826d3e4,0xd826d67c,0xd826db54,0xd826e090,0xd8272cd8,
       0xd8292298,0xd826e204,0xd826e458}

# Explicit resolved callr edges (verified from disasm):
CALLR_EDGES={
 0xd8272cd8:{0xd826d3e4,0xd8292298},  # r5 = 0xd826d3e4 / 0xd8292298 then callr r5 (verified)
}

BLACK={
 0xd814e6ac,0xd8829a00,0xd8829688,0xd8829698,0xd8829924,0xd8829a04,
 0xd80d77a8,0xd80d8998,0xd80d8988,0xd80d8990,0xd8041828,
 0xc0913a54,0xc0913ad8,
}
# Return/dealloc trampolines: a jump to any of these terminates the function (epilogue), and must
# NOT be treated as a call edge.
RET_TRAMP={0xd8829698,0xd8829688,0xd8829a00,0xd8829924,0xc0913b74,0xc0913a54,0xc0913ad8,
           0xc0913b6c,0xc0913bd8,0xd8829a04}
def is_ret_tramp(t): 
    return t in RET_TRAMP or 0xc0913a00<=t<0xc0913c00
fn_cache={}
def fn_body(va, cap=0x400):
    if va in fn_cache: return fn_cache[va]
    o=subprocess.run([DIS,hex(va),hex(cap)],capture_output=True,text=True).stdout
    out=[]; ended=False
    for ln in o.splitlines():
        m=re.match(r'\s*([0-9a-f]+):',ln)
        if not m: out.append((None,ln)); continue
        addr=int(m.group(1),16); out.append((addr,ln))
        if 'dealloc_return' in ln or re.search(r'jumpr r31',ln): ended=True
        # a jump to a return trampoline is an epilogue -> end of function
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            if is_ret_tramp(int(j,16)): ended=True
        if ended and '}' in ln: break
    fn_cache[va]=out; return out
def callees(va):
    cs=set()
    for addr,ln in fn_body(va):
        for c in re.findall(r'call (0x[0-9a-f]+)',ln): cs.add(int(c,16))
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            jv=int(j,16)
            if is_ret_tramp(jv): continue
            if LO<=jv<HI and (jv<va-0x20 or jv>va+0x400): cs.add(jv)
    cs|=CALLR_EDGES.get(va,set())
    return cs
def touches(va):
    ld=st=reg=False
    for addr,ln in fn_body(va):
        if 'ca79c494' in ln:
            if re.search(r'memw\(##0xca79c494\)\s*=',ln): st=True
            elif 'memw(##0xca79c494)' in ln: ld=True
        if 'ca6e3228' in ln: reg=True
    return ld,st,reg
def bfs(root, maxd=12, cap=4000):
    seen=set(); fr={root}; d=0; path={root:None}; hit={}
    while fr and d<maxd and len(seen)<cap:
        nx=set()
        for x in fr:
            if x in seen or len(seen)>=cap: continue
            seen.add(x)
            cs=callees(x)
            for t in list(EXECS)+[SETTER,GETTER,APPLY]:
                if t in cs and t not in hit: hit[t]=x
            ld,st,reg=touches(x)
            if ld: hit.setdefault('LOAD',x)
            if st: hit.setdefault('STORE',x)
            if reg: hit.setdefault('REGION',x)
            for c in cs:
                if c in BLACK: continue
                if LO<=c<HI and c not in seen: path.setdefault(c,x); nx.add(c)
        fr=nx-seen; d+=1
    return seen,hit,path
def chn(path,n):
    c=[]
    while n is not None: c.append(n); n=path.get(n)
    return list(reversed(c))
if __name__=='__main__':
    root=int(sys.argv[1],0)
    seen,hit,path=bfs(root)
    getter=(GETTER in hit) or ('LOAD' in hit)
    setter=(SETTER in hit) or ('STORE' in hit)
    ex=any(e in hit for e in EXECS)
    region='REGION' in hit
    print(f"root={hex(root)} scanned={len(seen)}")
    print(f"  GETTER(deref)={getter}  SETTER(store)={setter}  exec={ex}  region={region}")
    for lbl,key in [('SETTER',SETTER),('GETTER',GETTER),('APPLY',APPLY),('STORE','STORE'),('LOAD','LOAD')]:
        if key in hit:
            c=chn(path,hit[key])+([key] if not isinstance(key,str) else [])
            print(f"    {lbl}: {' -> '.join(hex(z) for z in c)}")
    for e in sorted(EXECS):
        if e in hit:
            c=chn(path,hit[e])+[e]; print(f"    exec {hex(e)}: {' -> '.join(hex(z) for z in c)}")
