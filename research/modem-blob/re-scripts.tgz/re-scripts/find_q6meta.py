#!/usr/bin/env python3
# Look for q6zip metadata: a run of monotonic increasing pointers (the page ptr list)
# whose values point into a compressed data region. Scan each candidate segment.
import struct, os
base="/tmp/modemre"
cands=[("modem.b25",0xcbf4f000),("modem.b26",0xcc000000),("modem.b28",0xce59a000),
       ("modem.b29",0xce5b1000),("modem.b23",0xc8b6a000)]
for fn,va in cands:
    p=os.path.join(base,fn)
    if not os.path.exists(p): continue
    d=open(p,"rb").read()
    n=len(d)//4
    w=struct.unpack_from("<%dL"%n,d,0)
    print(f"=== {fn} va={va:08x} size={len(d):08x} nwords={n} ===")
    # find longest run of monotonic-increasing 32-bit values (candidate ptr list)
    best=(0,0)  # (length,startidx)
    i=0
    while i<n-1:
        j=i
        while j+1<n and w[j+1]>=w[j] and (w[j+1]-w[j])<0x10000:
            j+=1
        if j-i>best[0]:
            best=(j-i,i)
        i=j+1
    L,s=best
    if L>50:
        print(f"  longest monotonic run: len={L} at idx {s} (va {va+s*4:08x})")
        print(f"    first vals: "+" ".join("%08x"%x for x in w[s:s+6]))
        print(f"    last  vals: "+" ".join("%08x"%x for x in w[s+L-5:s+L+1]))
