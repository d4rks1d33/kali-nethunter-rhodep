#!/usr/bin/env python3
# Track reg = ##struct (0xcb8dbeb0), follow copies (r=r), and find stores at +0x18 (byte/half/word).
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack_from('<I',data,i)[0] for i in range(0,N-3,4)]
NW=len(words)

def immext_val(w):
    if (w>>28)!=0: return None
    return (((((w>>16)&0xFFF)<<14)|(w&0x3FFF))<<6) & 0xffffffff
def top(w): return (w>>24)&0xff

# store [Rs+#off] families:
#  0xa1 : S2_storerX_io  memX(Rs+#s11)=Rt   Rs=[20:16], Rt=[12:8], off in [13:0] & type
#  0x3c : S4_storeirX_io memX(Rs+#u6)=#S    Rs=[20:16], off=[13:8]? 
# We compute the +off. For byte store memb(Rs+#s11)=Rt the offset field is the raw signed imm.
# The exact bitfield differs; let's just decode via llvm later. Here: flag any 0xa1/0x3c/0xa0/0xa3
# whose base reg == our tracked reg, and record the raw word; we'll disassemble to confirm off.

# Find setters (reg <- ##struct) via immext in struct range + 0x78/0x2b/0x68/0x7e/0x7c
setters=[]
for i,w in enumerate(words):
    v=immext_val(w)
    if v is None: continue
    if not (0xcb8dbe80<=v<=0xcb8dbec0): continue
    n1=words[i+1] if i+1<NW else 0
    t=top(n1)
    if t in (0x78,0x68,0x2b,0x7e,0x7c):
        reg=n1&0x1f
        setters.append((i+1,reg,v,BASE+i*4))

STORE_TOPS={0xa1,0x3c,0xa0,0xa3,0xaf,0xab}
hits=[]
for si,reg,v,setva in setters:
    liveregs={reg}
    for j in range(si+1, min(si+80,NW)):
        w=words[j]; t=top(w)
        base=(w>>16)&0x1f
        dst=w&0x1f
        if t in STORE_TOPS and base in liveregs:
            hits.append((setva,v,tuple(liveregs),BASE+j*4,w,t))
        # propagate reg copy: A2_tfr r=r  (0x70 top, s2? ) form '70604010' r16=r0 earlier
        if t==0x70:
            src=(w>>16)&0x1f
            if src in liveregs: liveregs.add(dst)
            elif dst in liveregs and src not in liveregs: liveregs.discard(dst)
        elif t in (0x78,0x2b,0x68,0x7e,0x7c) and dst in liveregs:
            liveregs.discard(dst)
# dedupe
seen=set(); out=[]
for h in hits:
    if h[3] in seen: continue
    seen.add(h[3]); out.append(h)
print("candidate stores on struct-base reg (window 80, incl. copies):")
for setva,v,regs,va,w,t in out:
    print("  setbase@%08x(=%08x) STORE@%08x word=%08x top=%02x base=r%d"%(setva,v,va,w,t,(w>>16)&0x1f))
print("total:",len(out))
