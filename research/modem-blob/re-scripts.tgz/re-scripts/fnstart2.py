#!/usr/bin/env python3
import struct,sys
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
def w(off): return struct.unpack('<I',data[off:off+4])[0]
def is_term(ww):
    # jumpr r31
    if ww in (0x529fc000,0x529f4000): return True
    # dealloc_return standalone 0x961ec01e
    if ww==0x961ec01e: return True
    # duplex low-slot deallocframe/dealloc_return: check parse bits & subinsn
    # dealloc_return duplex: high nibble pattern '3e..1f..' e.g 0x3e041f40,0x3e041f00,0x3e2c1f..
    top=ww&0xff000000
    if (ww&0x0000ff00)==0x00001f00 and (ww>>28)==0x3: return True  # ...1f.. with 3e class => dealloc_return duplex
    # deallocframe duplex ending: 0x901ec01e etc (deallocframe)
    if ww==0x901ec01e: return True
    if (ww&0xffff)==0xc01e and (ww>>24)==0x90: return True
    return False
def fnstart(va):
    off=va-BASE
    lim=max(0,off-0x4000)
    for o in range(off-4,lim,-4):
        if is_term(w(o)):
            return BASE+o+4
    return None
for a in sys.argv[1:]:
    print(a,'->',hex(fnstart(int(a,0))) if fnstart(int(a,0)) else None)
