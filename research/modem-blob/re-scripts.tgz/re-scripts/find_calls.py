#!/usr/bin/env python3
# Find Hexagon call/jump instructions targeting a given address.
# call: 0101 101i iiii iiii PP-i iiii iiii iiii  (opcode 0x5A.., J2_call)
#   sign-extended 24-bit (in units of 4 bytes? no, bytes) offset.
# Rather than decode by hand, disassemble sliding windows would be slow.
# Approach: decode call/jump immediate from the 32-bit word directly.
import sys,struct
base=0xd8000000
data=open('/tmp/modemre/clade_dec_full.bin','rb').read()
targets=[int(x,0) for x in sys.argv[1:]]
tset=set(targets)

def decode_branch(word, pc):
    op = word >> 24
    # J2_call = 0x5a / 0x5b (top byte 0101101x). J2_jump = 0x58/0x59.
    top = (word >> 25) & 0x7f  # 7 bits
    # call: bits 31-25 = 0101101 = 0x5a>>1? 0x5a=01011010 ->7bit top=0101101=0x2d
    # jump: 0x58=01011000 ->7bit=0101100=0x2c
    # Extract 22-bit imm scattered: Hexagon J2_call imm is bits [24:16]||[13:1] with :2 scaling? 
    # Use known-good empirical decode below.
    return None

# Empirical: from dispatcher we saw '8c ff ff 5b'=0x5bffff8c -> call 0xd8150e08 at pc 0xd8150ef0.
# 0xd8150e08 - 0xd8150ef0 = -0xe8. word=0x5bffff8c.
# Let's derive the imm field for call (class 0x5).
def call_off(word):
    if (word>>28)!=0x5: return None
    b = (word>>25)&0x7  # 3 bits: 101 for call (0x5) vs 100 jump(0x4)
    # bits: word = 0101 1SSi iiii iiii iiPP iiii iiii iiii  (S in {call=1,jump=0} approx)
    # 24 bit signed? Let's extract per Hexagon manual J2_call:
    #  Encoding: 0 1 0 1 1 0 1 i  i i i i i i i i  P P i i i i i i  i i i i i i i i
    # imm bits: [24:16]=word[24:16]? messy. Do bit gather.
    # Field positions (from LLVM): immediate occupies bits 0-13 and 16-24, value<<2.
    i1 = (word >> 16) & 0x1FF      # 9 bits -> imm[15:7]? 
    i2 = (word >> 1) & 0x1FFF      # 13 bits -> imm[12:0]? overlaps PP
    return None
PY_PLACEHOLDER=True
