#!/usr/bin/env python3
# Find Hexagon immext+transfer that materializes a 32-bit constant.
# immext encodes bits [31:6] of the constant (the 26-bit extension covers high bits),
# the paired instruction supplies low 6 bits. We brute-force by disassembling candidate
# windows. Simpler approach: scan for the immext word whose payload matches const>>6,
# then check the following/paired insn. But robust: just disassemble whole bin once and grep.
import sys,struct
base=0xd8000000
data=open('/tmp/modemre/clade_dec_full.bin','rb').read()
# immext instruction: opcode bits. Encoding: 0000 iiii iiii iiii iiii iiii iiii ii00
# The 32-bit word for immext(#imm) where imm&0x3f==0: word = 0x00000000 | ((imm>>6)&0x3fffff)<<... 
# Hexagon immext (const extender) word format:
#   bits[31:28]=0b0000, bits[27:16]=imm[31:20]?? -- messy. Use llvm to be safe.
# Strategy: for each aligned word that is an immext (top nibble 0x0), decode its 26-bit
# payload and print if high bits match any target.
targets=[int(x,0) for x in sys.argv[1:]]
# immext word: 0000 mmmm mmmm mmmm mmmm mmmm mmmm mm-- , the 26-bit field is bits scattered:
# Actual encoding: word & 0xF0000000 == 0 ; extended value high26 = ((word>>16)&0xFFF)<<14 | ((word>>0)&0x3FFF)
def immext_val(word):
    if (word & 0xF0000000)!=0: return None
    hi = (word>>16)&0x0FFF
    lo = word & 0x3FFF
    val26 = (hi<<14)|lo
    return (val26<<6)&0xFFFFFFC0
for i in range(0,len(data)-4,4):
    w=struct.unpack('<I',data[i:i+4])[0]
    v=immext_val(w)
    if v is None: continue
    for t in targets:
        if (v & 0xFFFFFFC0) == (t & 0xFFFFFFC0):
            va=base+i
            print(f"immext@va=0x{va:08x} off=0x{i:06x} ext=0x{v:08x} matches 0x{t:08x}")
