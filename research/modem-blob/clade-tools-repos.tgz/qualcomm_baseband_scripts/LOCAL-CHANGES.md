# LOCAL CHANGES — do NOT re-clone from upstream, use THIS copy

This is a working copy of
https://github.com/mzakocs/qualcomm_baseband_scripts (pinned at commit
`1bd9198`) with LOCAL additions that upstream does not have. Re-cloning from
GitHub would give you a tree without our SM6375 harness and without the
already-built extractor.

## What we added (not upstream)

`git status` shows these as untracked (they are ours, not in upstream):

- **`clade_extractor_sm6375.c`** — our harness for THIS chip (SM6375 / Moto G82
  5G). Derived from the repo's `clade_extractor_pixel_5.c`, adjusted for our
  segment layout: `.clade.comp` = `modem.b26` at offset 0, and the three CLADE
  dictionaries at `modem.b26` offsets 0x2444000 / 0x2446000 / 0x2448000.
- **`clade_api.h`** — the libclade.so ABI header used to compile it.
- **`clade_extractor_sm6375`** — the already-built x86-64 binary. It links
  against `libclade.so` (also in this repo). On an aarch64 host it must run under
  `qemu-x86_64-static`.

## Why libclade.so matters

`libclade.so` here is the REAL Qualcomm CLADE codec (x86-64) with the exception
words implemented — that is what the pure-Python `unclade_exc.py` (in the sibling
repo) could not fully do. Running our harness against it produced the HW-accurate
decompression (0.14% invalid over 1M instructions), i.e. `clade_dec_full.bin` in
`../../clade-re-preserve.tgz`.

## How to run it (reproduce the decompression)

    tar xzf ../../modem-blob-rhodep.tgz   # get modem.b26 etc.
    qemu-x86_64-static ./clade_extractor_sm6375 <args>   # see the .c for args

Kept 2026-09-24.
