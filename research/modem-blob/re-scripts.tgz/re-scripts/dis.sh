#!/bin/bash
# dis.sh <vaddr_hex> <len_hex>  -- disassemble a range from clade_dec_full.bin (base 0xd8000000)
# If vaddr not in the 10MB already extracted, re-extract via clade.
VA=$1
LEN=$2
BASE=0xd8000000
BIN=/tmp/modemre/clade_dec_full.bin
python3 - "$VA" "$LEN" "$BASE" "$BIN" <<'PY'
import sys,struct
va=int(sys.argv[1],0); ln=int(sys.argv[2],0); base=int(sys.argv[3],0); binf=sys.argv[4]
off=va-base
data=open(binf,'rb').read()
end=off+ln
if off<0 or end>len(data):
    sys.stderr.write("RANGE OUT OF 10MB BIN; use extract\n"); sys.exit(2)
code=data[off:end]
open('/tmp/_dis.bin','wb').write(code)
PY
if [ $? -ne 0 ]; then exit 2; fi
python3 /tmp/modemre/mkelf.py /tmp/_dis.bin $VA /tmp/_dis.elf >/dev/null
llvm-objdump-18 -d --triple=hexagon --mcpu=hexagonv66 /tmp/_dis.elf | sed '1,6d'
