#!/usr/bin/env python3
import struct,json,array
d=open('/tmp/modemre/modem_full.elf','rb').read()
phs=json.load(open('/tmp/modemre/phs.json'))
def f2v(fo):
    for off,va,fsz,msz,fl in phs:
        if off<=fo<off+fsz: return va+(fo-off)
    return None
n=len(d)//4
w=array.array('I'); w.frombytes(d[:n*4])
# candidate q6zip header: npages small, version small, dict1[0]==0
# combined dict size = 2^a+2^b. common: 0x400+0x4000=0x4400 words.
cands=[]
for i in range(n-4):
    npages=w[i]&0xffff
    ver=(w[i]>>16)&0xffff
    if not (200<=npages<=20000): continue
    if ver>0x20: continue
    if w[i+1]!=0: continue  # dict1[0] should be 0
    # check that ~0x4400 words later there is a monotonic ptr list
    # dict occupies 0x4400 words typically
    pl=i+1+0x4400
    if pl+50>=n: continue
    # verify next ~20 words look like increasing pointers
    ok=True
    base=w[pl]
    if not (0xc0000000<=base<0xe0000000): 
        continue
    for k in range(1,20):
        if not (w[pl+k]>=w[pl+k-1] and 0<=(w[pl+k]-w[pl+k-1])<0x4000):
            ok=False;break
    if ok:
        cands.append((i,npages,ver,base))
for i,npages,ver,base in cands[:20]:
    print('@va %08x: npages=%d ver=%d  ptr0=%08x'%(f2v(i*4),npages,ver,base))
print('total cands',len(cands))
