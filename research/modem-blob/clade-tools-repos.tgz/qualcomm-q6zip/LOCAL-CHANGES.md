# LOCAL CHANGES — do NOT re-clone from upstream, use THIS copy

This is a working copy of https://github.com/nlitsme/qualcomm-q6zip
(pinned at commit `ecf58b7`) with a LOCAL addition that upstream does not have.
Re-cloning from GitHub would give you an incomplete/different tree that does not
decode this modem correctly.

## What we added (not upstream): `unclade_exc.py`

`unclade_exc.py` is our patched CLADE decoder. `git status` shows it as
untracked — it is not in upstream.

### Why
The upstream `unclade.py` mis-decodes the CLADE 2-bit code `0b11`. It reads it as
an inline 32-bit literal (`bits.get(32)`), but on this firmware `0b11` is a
**zero-bit EXCEPTION marker**: it consumes no stream bits and the real word comes
from the `.clade.exception_*` sections. The wrong 32-bit read desynchronises the
bitstream at the *first* exception of every page, which corrupts every word after
it (~26% of all words, appearing as a uniform error rate).

### The fix
`unclade_exc.py` treats code `0b11` as a 0-bit marker (emitting a visible
`0xE0C0DExx` placeholder for the exception word). That removes all
post-exception drift and makes every non-exception word correct (~83% overall).
The remaining ~17% are the exception words themselves, which need the
`.clade.exception_*` sections applied — we did NOT source those in Python;
instead the 100% result came from the real `libclade.so` in the sibling repo
`qualcomm_baseband_scripts`. So:

- `unclade_exc.py` here = the corrected pure-Python decoder (good enough to prove
  the format and read most of a page);
- for the fully-correct decompression used in the project, use `libclade.so` +
  the `clade_extractor_sm6375` harness in `../qualcomm_baseband_scripts`.

Kept 2026-09-24.
