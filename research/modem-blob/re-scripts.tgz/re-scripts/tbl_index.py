import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va, seg_of
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]
    n=d.find(b'\x00')
    if n<0: n=maxlen
    try: return d[:n].decode('ascii')
    except: return None
def is_name_ptr(v):
    if v is None or not is_valid_va(v): return False
    s=cstr(v,64)
    if not s: return False
    if len(s)<2 or len(s)>40: return False
    return all(c.isupper() or c.isdigit() or c in '_ ' for c in s)

# El array parece indexado. Empecemos en 0xc906c260 (name UNASSIGNED-ish?) 
# Miremos region 0xc906c240..0xc906c294 crudo
for va in range(0xc906c230, 0xc906c298,4):
    v=u32(va)
    s=cstr(v) if is_valid_va(v) else None
    print("0x%08x: 0x%08x %s"%(va,v, ("'"+s+"'") if s else ""))
