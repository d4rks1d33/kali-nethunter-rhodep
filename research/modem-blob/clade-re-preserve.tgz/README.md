# rhodep modem CLADE decompression + FTM RE — preserved work

This is the reusable output of decompressing the Moto G82 5G (rhodep, SM6375)
modem firmware and reverse-engineering the FTM RF-test protocol, up to the point
where IQ capture is one diag-handshake detail away. Kept so none of it has to be
redone.

Build: MPSS.HI.4.3.4-00494-MANNAR_GEN_PACK-1.24452.133

## What's here

- `clade_dec_full.bin` (10 MB) — **the decompressed modem code**, HW-accurate via
  the real `libclade.so`. Base VA 0xd8000000 (file offset 0 = VA 0xd8000000).
  0.14% invalid over 1M instructions; the FTM dispatcher page is clean. This is
  the expensive artifact — regenerating it needs libclade.so + qemu-x86_64.
  Disassemble a range with:
    off = vaddr - 0xd8000000
    llvm-objdump-18 --triple=hexagon -D <slice of clade_dec_full.bin>

- `clade-toolchain/` — everything to reproduce the decompression:
  - `libclade.so` — the real Qualcomm CLADE codec (x86-64), from
    github.com/mzakocs/qualcomm_baseband_scripts.
  - `clade_extractor_sm6375.c` / `.h` / the built `clade_extractor_sm6375` —
    the harness that feeds b26 (.clade.comp @ off 0, dicts @ 0x2444000/0x2446000/
    0x2448000) to libclade.so. Runs under qemu-x86_64-static.
  - `cladetool.cpp` — nlitsme's cladelib harness (reference).
  - `unclade_exc.py` — the pure-Python decoder with the exception-marker fix
    (~83% correct; libclade is the 100% path).
  - `qbs-README.md` — notes from the baseband-scripts repo.

- `findings/` — all the RE reports (also mirrored in the git repo under
  `docs/modem-diag-wip/blob-analysis/`). Key ones: `clade_final.md`,
  `iq_sequence.md`, `iq_final_values.md`, `diag_response_routing.md`.

## The source firmware

The modem blob itself is next to this file: `modem-blob-rhodep.tgz`
(modem.mdt + modem.b00..b31). The runtime RAM dump is
`mssdump-runtime.elf.gz` (data only, no code). Their README is in this folder.

## Where the work stands

FTM protocol fully decoded from `clade_dec_full.bin`:
- packet: `4b 0b 14 00 5a 03 <handle> 00 00 27 00 <sub_command> <num_tlv> <TLVs>`
- TECH_ENTER sub_command = 0x0d; TECH field_id 2 = u32, LTE value = 1
- IQ/RADIO_CONFIG field-ids extracted (see iq_sequence.md)
- the 0x14 gate = per-tech state byte @0xca7897b0

Last open step: the subsys command **response** drains out the DIAG_DATA channel
and is `allow_flow`-gated; our diag handshake sets real_time=1 but not the exact
Tx-mode/stream_id the drain checks, so TECH_ENTER runs but its response is not
delivered. Fix = replay the real diag control handshake to get `allow_flow=1`
(confirm via the F3 string `diagcomm_io_transmit: allow_flow=1`), then the
tech-enter -> RADIO_CONFIG -> IQ_CAPTURE sequence (already worked out byte-for-
byte) will return samples. See `findings/diag_response_routing.md`.
