#!/usr/bin/env python3
# Search all segments for the dlpager range markers.
# We look for sequences of words that look like: decomp_start, decomp_end, comp_start, comp_end
# where decomp_start is in 0xd8xxxxxx region and comp_start is in 0xcc..0xce (file-backed).
import struct, os
base="/tmp/modemre"
PH = [
 (20,"modem.b20",0xc1a50000),(21,"modem.b21",0xc3553000),(23,"modem.b23",0xc8b6a000),
 (25,"modem.b25",0xcbf4f000),(26,"modem.b26",0xcc000000),(27,"modem.b27",0xce480000),
 (28,"modem.b28",0xce59a000),(29,"modem.b29",0xce5b1000),
]
def scan(fn,va):
    p=os.path.join(base,fn)
    d=open(p,"rb").read()
    n=len(d)//4
    w=struct.unpack_from("<%dL"%n,d,0)
    hits=[]
    for i in range(n-3):
        a,b,c,e=w[i],w[i+1],w[i+2],w[i+3]
        # decomp region 0xd8xxxxxx, comp region 0xc8..0xce
        if 0xd8000000<=a<0xd9000000 and 0xd8000000<=b<0xd9000000 and a<b:
            if 0xc0000000<=c<0xd0000000 and 0xc0000000<=e<0xd0000000 and c<e:
                hits.append((va+i*4, a,b,c,e))
    return hits
for idx,fn,va in PH:
    if not os.path.exists(os.path.join(base,fn)): continue
    h=scan(fn,va)
    for va_at,a,b,c,e in h:
        print(f"{fn} @va {va_at:08x}: decomp {a:08x}-{b:08x}  comp {c:08x}-{e:08x}")
