#!/usr/bin/env python3
# Fast Hexagon packet-parse validity scorer (no external tools).
# Hexagon: each 32-bit word has "parse bits" [15:14]:
#   0b11 (3): end of packet (or single-word packet / last in packet)
#   0b00 (0): duplex (end of packet, 2 sub-insns) -- also end
#   0b01 (1): not end, continue
#   0b10 (2): not end, continue
# A packet is 1..4 words. Validity heuristic: parse the word stream into packets;
# a good stream has packets of length 1..4 with proper end bits, and immext
# (iclass 0x0, i.e. top 4 bits 0000 and bits[15:14]!=00 handled) followed by
# an instruction. We score fraction of words that form well-terminated packets
# of length<=4.
import struct

def parse_bits(w):
    return (w>>14)&3

def score_words(words):
    n=len(words); i=0; ok=0; bad=0; plen=0
    while i<n:
        pb=parse_bits(words[i])
        plen+=1
        if pb==3 or pb==0:  # end of packet
            if 1<=plen<=4:
                ok+=plen
            else:
                bad+=plen
            plen=0
        else:
            if plen>4:
                bad+=1; plen=0  # runaway, resync
        i+=1
    total=ok+bad if (ok+bad)>0 else 1
    return ok/ (ok+bad+plen)

if __name__=='__main__':
    import sys
    d=open(sys.argv[1],'rb').read()
    words=list(struct.unpack('<%dL'%(len(d)//4), d[:len(d)//4*4]))
    print('score', score_words(words))
