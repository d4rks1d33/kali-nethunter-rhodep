#!/usr/bin/env python3
# Scan all segments for 3 consecutive 0x2000-byte dictionaries matching CLADE
# validation OR-signatures: {0x3fffffff, 0x007fffff, 0x0001ffff}
import struct, glob, os

EXPECT = [0x3fffffff, 0x007fffff, 0x0001ffff]

def orblock(d, off, n):
    v = 0
    for i in range(off, off+n, 4):
        v |= struct.unpack_from('<L', d, i)[0]
    return v

files = sorted(glob.glob('/tmp/clade/modem.b*'))
DICT = 0x2000
for f in files:
    d = open(f, 'rb').read()
    if len(d) < 3*DICT:
        continue
    # slide over the file at word granularity is too slow for big files;
    # step at 4-byte but only where plausible. Use 0x1000 alignment first, then refine.
    n = len(d)
    # Try all 4-byte aligned starts but cap for huge files by 0x800 steps for a coarse pass
    step = 4 if n < 2_000_000 else 0x40
    hit = False
    for off in range(0, n - 3*DICT + 1, step):
        o1 = orblock(d, off, DICT)
        if o1 != EXPECT[0]:
            continue
        o2 = orblock(d, off+DICT, DICT)
        o3 = orblock(d, off+2*DICT, DICT)
        if o2 == EXPECT[1] and o3 == EXPECT[2]:
            print(f"HIT {os.path.basename(f)} @ file_off 0x{off:x}  (ors: {o1:08x} {o2:08x} {o3:08x})")
            hit = True
    if not hit and step > 4:
        # refine near-misses: scan first dict signature only at 4-byte
        for off in range(0, n - DICT + 1, 4):
            if orblock(d, off, DICT) == EXPECT[0]:
                # check next two
                if off + 3*DICT <= n:
                    o2 = orblock(d, off+DICT, DICT)
                    o3 = orblock(d, off+2*DICT, DICT)
                    if o2 == EXPECT[1] and o3 == EXPECT[2]:
                        print(f"HIT(refine) {os.path.basename(f)} @ 0x{off:x}")
print("done")
