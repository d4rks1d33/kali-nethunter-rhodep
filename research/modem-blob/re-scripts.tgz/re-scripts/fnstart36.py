#!/usr/bin/env python3
# Heuristic: find function start <= va by scanning backward for a prologue boundary.
# A prologue is typically 'allocframe' preceded by dealloc_return/jumpr r31, OR a call to stack-check.
import struct,sys
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
def w(off): return struct.unpack('<I',data[off:off+4])[0]
va=int(sys.argv[1],0)
off=va-BASE
# scan backward up to 0x2000 for allocframe (encoding: bits.. 'a09dc0' pattern or ebf41c) 
# Simpler: find previous 'jumpr r31'(529fc000/529f4000) or dealloc_return(961ec01e) then next instr region.
lim=max(0,off-0x3000)
prev_end=None
for o in range(off, lim, -4):
    ww=w(o)
    # dealloc_return 0x961ec01e ; jumpr r31 0x529fc000/0x529f4000 ; deallocframe+jump variants
    if ww in (0x961ec01e,0x529fc000,0x529f4000):
        prev_end=o
        break
    # 3e041f40 = r17:16=memd; dealloc_return combos also end funcs
if prev_end is not None:
    print("prev terminator @", hex(BASE+prev_end))
    print("candidate fn start @", hex(BASE+prev_end+4))
else:
    print("no terminator found within window")
