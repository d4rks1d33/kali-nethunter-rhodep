import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
va=0xc906cea0
for _ in range(60):
    a=u32(va); b=u32(va+4)
    sa=cstr(a) if is_valid_va(a) else None
    print("0x%08x: 0x%08x 0x%08x  %s"%(va,a,b, ("'"+sa+"'") if sa else ""))
    va+=8
