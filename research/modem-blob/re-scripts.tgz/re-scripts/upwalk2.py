#!/usr/bin/env python3
import struct,sys,collections
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
def w(off): return struct.unpack('<I',data[off:off+4])[0]
def val_imm(ww):
    b_hi=(ww>>16)&0x1ff; b_lo=(ww>>1)&0x1fff
    imm=(b_hi<<13)|b_lo
    if imm&(1<<21): imm-=(1<<22)
    return imm<<2
# precompute edges: map target->list of (kind,site)
edges=collections.defaultdict(list)
for off in range(0,N-4,4):
    ww=w(off); op7=(ww>>25)&0x7f
    if op7==0b0101101:
        edges[BASE+off+val_imm(ww)].append(('C',BASE+off))
    elif op7==0b0101100:
        edges[BASE+off+val_imm(ww)].append(('J',BASE+off))
def is_term(ww):
    if ww in (0x529fc000,0x529f4000,0x961ec01e,0x901ec01e): return True
    if (ww&0x0000ff00)==0x00001f00 and (ww>>28)==0x3: return True
    if (ww&0xffff)==0xc01e and (ww>>24)==0x90: return True
    return False
def is_nop(ww): return ww==0x7f00c000
def fnstart(va):
    off=va-BASE
    lim=max(0,off-0x4000)
    for o in range(off-4,lim,-4):
        if is_term(w(o)):
            s=o+4
            while s<off and is_nop(w(s)): s+=4
            return BASE+s
    return None
import pickle
open('/tmp/modemre/_edges36.pkl','wb').write(pickle.dumps(dict(edges)))
roots=[int(x,0) for x in sys.argv[1:]]
seen=set(); q=collections.deque()
for r in roots:
    fs=fnstart(r) or r; q.append((fs,0)); seen.add(fs)
while q:
    fn,d=q.popleft()
    cs=edges.get(fn,[])
    tag="<<VTABLE/ROOT (no static callers)>>" if not cs else ""
    print("  "*d+f"FN {hex(fn)} d={d} {tag} sites={[(t,hex(v)) for t,v in cs][:10]}")
    if d>=8: continue
    for t,site in cs:
        pfn=fnstart(site)
        if pfn and pfn not in seen:
            seen.add(pfn); q.append((pfn,d+1))
