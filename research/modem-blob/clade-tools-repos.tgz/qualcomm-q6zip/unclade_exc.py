#!/usr/bin/env python3
"""
unclade_exc.py - CLADE decoder with the EXCEPTION-WORD fix.

Key correction over nlitsme/qualcomm-q6zip unclade.py:
    The 2-bit code value 0b11 ("code 3") is NOT an inline 32-bit literal.
    It is an EXCEPTION MARKER that consumes ZERO additional stream bits.
    The real 32-bit word for that position lives OUTSIDE the bit-packed
    stream, in the .clade.exception_high / .clade.exception_low_large /
    .clade.exception_low_small sections, consumed in output order.

    unclade.py's `bits.get(32)` on code 3 desynchronises the bitstream at
    the first exception of every page, corrupting every subsequent word
    (~26% of all words). Treating code 3 as a 0-bit marker keeps the
    stream perfectly aligned across the whole image (verified to page 336+,
    no drift) and makes every NON-exception word correct.

Remaining gap for a 100% reconstruction:
    1. The exception words themselves (~17% of words) must be pulled from
       the .clade.exception_* sections. Their exact location/ordering was
       not resolved statically (see clade_exceptions.md).
    2. A residual ~4% of dict-decoded words still produce invalid packets,
       indicating one more un-modelled encoder feature (likely a repeat/
       run sub-code). Not resolved.

Author of the fix: RE pass (exception-marker discovery).
Original unclade.py by Willem Hengeveld.
"""
import struct, sys
sys.path.insert(0, '/tmp/q6zip')
from unclade import BitStreamReader, decodewords

MB = [
    [1, 15],                                                  # code0: dict0 + 2 missing
    [1, 2, 4, 5, 6, 7, 8, 9, 16],                             # code1: dict1 + 9 missing
    [0, 1, 2, 4, 5, 7, 8, 9, 10, 15, 16, 17, 18, 19, 20],     # code2: dict2 + 15 missing
]

def reconstruct(dw, bp, cb):
    for bitnr in bp:
        h = (dw & ~((1 << bitnr) - 1)) << 1
        bit = (cb & 1) << bitnr
        l = dw & ((1 << bitnr) - 1)
        dw = h | bit | l
        cb >>= 1
    return dw

def load_dicts(path, dictofs):
    f = open(path, 'rb'); f.seek(dictofs); dd = f.read(0x6000)
    return [list(decodewords(dd[i*0x2000:(i+1)*0x2000])) for i in range(3)]

def decode(comp_words, dicts, nwords, exc_words=None):
    """
    exc_words: optional list of exception words (applied in output order).
               If None, exceptions are filled with a visible 0xE0C0DExx marker.
    Returns (out_words, exception_positions).
    """
    b = BitStreamReader(comp_words); b.get(1)   # CLADE skips the first bit
    out = []; excpos = []; ei = 0
    for i in range(nwords):
        try:
            code = b.get(2)
        except EOFError:
            break
        if code < 3:
            idx = b.get(11)
            missing = b.get(len(MB[code]))
            out.append(reconstruct(dicts[code][idx], MB[code], missing))
        else:
            # EXCEPTION MARKER: 0 stream bits.
            excpos.append(i)
            if exc_words is not None and ei < len(exc_words):
                out.append(exc_words[ei])
            else:
                out.append(0xE0C0DE00 | (ei & 0xff))
            ei += 1
    return out, excpos

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('file')
    ap.add_argument('-o', '--offset', type=lambda x: int(x, 0), default=0)
    ap.add_argument('-n', '--nwords', type=lambda x: int(x, 0), default=340*1024)
    ap.add_argument('--dictofs', type=lambda x: int(x, 0), default=0x2444000)
    ap.add_argument('--output', default='/tmp/modemre/clade_dec_full.bin')
    a = ap.parse_args()
    dicts = load_dicts(a.file, a.dictofs)
    f = open(a.file, 'rb'); f.seek(a.offset)
    comp = f.read(a.dictofs - a.offset)
    words = list(decodewords(comp))
    out, excpos = decode(words, dicts, a.nwords)
    open(a.output, 'wb').write(struct.pack('<%dL' % len(out), *out))
    print('wrote %s: %d words, %d exceptions (%.1f%%)' %
          (a.output, len(out), len(excpos), 100*len(excpos)/len(out) if out else 0))

if __name__ == '__main__':
    main()
