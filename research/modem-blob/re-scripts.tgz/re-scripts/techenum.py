import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, SEGS, va_to_off, u32, is_valid_va
import struct
def cstr(va, maxlen=40):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
# TECH_MODE string @0xc414b75f ; SUB_TECH @0xc414b737. These are field NAMES.
# The enum VALUE tables would be separate. Search for arrays of ptrs to tech value strings
# like "GSM","WCDMA","LTE","NR5G","TDSCDMA","CDMA","LTE_CA" near each other.
# Find pointers to short tech strings
techs={}
import re
rx=re.compile(b'^(GSM|WCDMA|LTE|NR5G|TDSCDMA|CDMA1X|CDMA|EVDO|GNSS|WLAN|NB1|CATM|LTE_M)\\x00')
from vmap import off_to_va
for m in re.finditer(rx, FULL if False else b''):  # placeholder
    pass
# simpler: scan for exact tech strings
for name in [b'GSM',b'WCDMA',b'LTE',b'NR5G',b'TDSCDMA',b'CDMA1X',b'1X',b'EVDO',b'WLAN']:
    idx=0
    hits=[]
    while True:
        p=FULL.find(name+b'\x00',idx)
        if p<0: break
        va=off_to_va(p)
        if va: hits.append(va)
        idx=p+1
    techs[name.decode()]=hits[:6]
for k,v in techs.items():
    print("%-8s: %s"%(k, [hex(x) for x in v]))
