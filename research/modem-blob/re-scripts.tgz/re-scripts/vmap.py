"""vaddr<->file mapping helpers over the reassembled ELF (modem_full.elf)."""
from elftools.elf.elffile import ELFFile
_e=ELFFile(open('/tmp/modemre/modem_full.elf','rb'))
SEGS=[]
for i,s in enumerate(_e.iter_segments()):
    h=s.header
    SEGS.append((i,h.p_offset,h.p_vaddr,h.p_paddr,h.p_filesz,h.p_memsz,h.p_flags))
FULL=open('/tmp/modemre/modem_full.elf','rb').read()

def va_to_off(va):
    for i,off,vaddr,pa,fsz,msz,fl in SEGS:
        if fsz and vaddr<=va<vaddr+fsz:
            return off+(va-vaddr)
    return None
def off_to_va(off):
    for i,o,vaddr,pa,fsz,msz,fl in SEGS:
        if fsz and o<=off<o+fsz:
            return vaddr+(off-o)
    return None
def read_va(va,n):
    o=va_to_off(va)
    if o is None: return None
    return FULL[o:o+n]
import struct
def u16(va): 
    d=read_va(va,2); return struct.unpack('<H',d)[0] if d and len(d)==2 else None
def u32(va):
    d=read_va(va,4); return struct.unpack('<I',d)[0] if d and len(d)==4 else None
def is_code_va(va):
    # executable segments
    for i,off,vaddr,pa,fsz,msz,fl in SEGS:
        if (fl&1) and vaddr<=va<vaddr+msz: return True
    return False
def is_valid_va(va):
    for i,off,vaddr,pa,fsz,msz,fl in SEGS:
        if vaddr<=va<vaddr+msz: return True
    return False
def seg_of(va):
    for i,off,vaddr,pa,fsz,msz,fl in SEGS:
        if vaddr<=va<vaddr+msz: return i
    return None
CODE_RANGES=[(vaddr,vaddr+msz) for i,off,vaddr,pa,fsz,msz,fl in SEGS if (fl&1) and fsz]
if __name__=='__main__':
    for i,off,vaddr,pa,fsz,msz,fl in SEGS:
        f=('R'if fl&4 else'-')+('W'if fl&2 else'-')+('E'if fl&1 else'-')
        print("seg%2d off=0x%08x va=0x%08x fsz=0x%08x %s"%(i,off,vaddr,fsz,f))
    print("CODE_RANGES", [(hex(a),hex(b)) for a,b in CODE_RANGES])
