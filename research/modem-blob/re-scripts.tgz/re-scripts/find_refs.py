#!/usr/bin/env python3
# Find call AND jump refs to a target VA. Hexagon PC-relative:
#  J2_call : opcode bits [31:25] = 0101 101  -> top byte 0x5a/0x5b/0x5c/0x5d depending on imm bits.
#            Actually J2_call = 0b0101101 in [31:25]. imm is bits [24:16]|[13:1], <<2, signext(22).
#  J2_jump : opcode bits [31:25] = 0101 100  -> imm same layout.
import struct, sys
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_full.bin','rb').read()

def val_imm(w):
    b_hi=(w>>16)&0x1ff; b_lo=(w>>1)&0x1fff
    imm=(b_hi<<13)|b_lo
    if imm&(1<<21): imm-=(1<<22)
    return imm<<2

def decode(target):
    calls=[]; jumps=[]
    for off in range(0,len(data)-4,4):
        w=struct.unpack('<I',data[off:off+4])[0]
        op7=(w>>25)&0x7f
        va=BASE+off
        if op7==0b0101101:   # J2_call
            if va+val_imm(w)==target: calls.append(va)
        elif op7==0b0101100: # J2_jump
            if va+val_imm(w)==target: jumps.append(va)
    return calls,jumps

if __name__=='__main__':
    tgt=int(sys.argv[1],0)
    c,j=decode(tgt)
    print("CALLS:",[hex(x) for x in c])
    print("JUMPS:",[hex(x) for x in j])
