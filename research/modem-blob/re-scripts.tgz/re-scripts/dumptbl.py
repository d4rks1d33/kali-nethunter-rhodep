import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va, seg_of
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
# Find the real start by scanning backwards from 0xc3555b7c for 16-byte records
start=0xc3555b7c
# back up
p=start
while p>0xc3555000:
    a=u32(p-16)
    if a and is_valid_va(a):
        p-=16
    else:
        break
tstart=p
print("table start ~0x%08x"%tstart)
va=tstart
for k in range(60):
    w=[u32(va+4*j) for j in range(4)]
    s0=cstr(w[0]) if is_valid_va(w[0]) else None
    print("[%2d] 0x%08x: %08x %08x %08x %08x  %s"%(k,va,w[0],w[1],w[2],w[3], ("'"+s0+"'") if s0 else ""))
    va+=16
