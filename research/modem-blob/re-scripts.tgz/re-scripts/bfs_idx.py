#!/usr/bin/env python3
# Fast sound reachability using pre-dumped disasm index _idx.txt.
import re, sys
LO,HI=0xd8000000,0xd8a00000
SETTER=0xd8279264; GETTER=0xd827923c; APPLY=0xd8273b2c
EXECS={0xd826d7b0,0xd826d9b4,0xd826d3e4,0xd826d67c,0xd826db54,0xd826e090,0xd8272cd8,
       0xd8292298,0xd826e204,0xd826e458}
CALLR_EDGES={0xd8272cd8:{0xd826d3e4,0xd8292298}}
BLACK={0xd814e6ac,0xd8829a00,0xd8829688,0xd8829698,0xd8829924,0xd8829a04,
 0xd80d77a8,0xd80d8998,0xd80d8988,0xd80d8990,0xd8041828,0xc0913a54,0xc0913ad8}
RET_TRAMP={0xd8829698,0xd8829688,0xd8829a00,0xd8829924,0xc0913b74,0xc0913a54,0xc0913ad8,
           0xc0913b6c,0xc0913bd8,0xd8829a04}
def is_ret(t): return t in RET_TRAMP or 0xc0913a00<=t<0xc0913c00

# Load index: map addr -> line
LINES={}
ORDER=[]
for ln in open('/tmp/modemre/_idx.txt'):
    m=re.match(r'([0-9a-f]{8}):',ln)
    if m:
        a=int(m.group(1),16)
        if a not in LINES:
            LINES[a]=ln; ORDER.append(a)
ORDER.sort()
import bisect
def body(va, cap=0x600):
    i=bisect.bisect_left(ORDER,va)
    out=[]; ended=False; end=va+cap
    while i<len(ORDER):
        a=ORDER[i]
        if a>=end: break
        ln=LINES[a]; out.append((a,ln))
        if 'dealloc_return' in ln or re.search(r'jumpr r31',ln): ended=True
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            if is_ret(int(j,16)): ended=True
        if ended and '}' in ln: break
        i+=1
    return out
fc={}
def callees(va):
    if va in fc: return fc[va]
    cs=set()
    for a,ln in body(va):
        for c in re.findall(r'call (0x[0-9a-f]+)',ln): cs.add(int(c,16))
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            jv=int(j,16)
            if is_ret(jv): continue
            if LO<=jv<HI and (jv<va-0x20 or jv>va+0x600): cs.add(jv)
    cs|=CALLR_EDGES.get(va,set())
    fc[va]=cs; return cs
def touches(va):
    ld=st=reg=False
    for a,ln in body(va):
        if 'ca79c494' in ln:
            if re.search(r'memw\(##0xca79c494\)\s*=',ln): st=True
            elif 'memw(##0xca79c494)' in ln: ld=True
        if 'ca6e3228' in ln: reg=True
    return ld,st,reg
def bfs(root, maxd=20):
    seen=set(); fr={root}; d=0; path={root:None}; hit={}
    while fr and d<maxd:
        nx=set()
        for x in fr:
            if x in seen: continue
            seen.add(x)
            cs=callees(x)
            for t in list(EXECS)+[SETTER,GETTER,APPLY]:
                if t in cs and t not in hit: hit[t]=x
            ld,st,reg=touches(x)
            if ld: hit.setdefault('LOAD',x)
            if st: hit.setdefault('STORE',x)
            if reg: hit.setdefault('REGION',x)
            for c in cs:
                if c in BLACK: continue
                if LO<=c<HI and c not in seen: path.setdefault(c,x); nx.add(c)
        fr=nx-seen; d+=1
    return seen,hit,path
def chn(path,n):
    c=[]
    while n is not None: c.append(n); n=path.get(n)
    return list(reversed(c))
if __name__=='__main__':
    root=int(sys.argv[1],0)
    seen,hit,path=bfs(root)
    getter=(GETTER in hit) or ('LOAD' in hit)
    setter=(SETTER in hit) or ('STORE' in hit)
    ex=any(e in hit for e in EXECS); region='REGION' in hit
    print(f"root={hex(root)} scanned={len(seen)} G={getter} S={setter} exec={ex} region={region}")
    if '-v' in sys.argv:
        for lbl,key in [('SETTER',SETTER),('GETTER',GETTER),('APPLY',APPLY)]:
            if key in hit:
                print(f"    {lbl}: {' -> '.join(hex(z) for z in chn(path,hit[key])+[key])}")
        if 'LOAD' in hit: print(f"    LOAD@: {hex(hit['LOAD'])}")
        if 'REGION' in hit: print(f"    REGION@: {hex(hit['REGION'])}")
