# RE scripts — SM6375 modem FTM/RFTEST static-analysis toolkit

Preserved from `/tmp/modemre/` (the working dir for the modem RE sessions of
2026-09-23..25). These are the scripts that produced the findings in
`nethunter-rhodep-repo/docs/modem-diag-wip/blob-analysis/`. The large binaries
they operate on are preserved separately:

- `clade_dec_full.bin` (10 MB, HW-decompressed Hexagon code, VA base 0xd8000000)
  and `unclade_exc.py` are in `clade-re-preserve.tgz`.
- The raw firmware (`modem.bNN`) is in `modem-blob-rhodep.tgz`.
- The clade decompression tool repos are in `clade-tools-repos.tgz`.

To use these scripts, extract `clade_dec_full.bin` next to them (or into
`/tmp/modemre/`) and have `llvm-objdump-18` + a Hexagon triple available.

## Core toolkit (the load-bearing ones)

- `dis.sh <va-hex> <len-hex>` — disassemble a range from `clade_dec_full.bin`
  (base 0xd8000000). Depends on `mkelf.py`. This is THE workhorse; every finding
  cites VAs disassembled with it. Example: `dis.sh 0xd8272684 0x80`.
- `mkelf.py <blob> <vaddr> <out.elf>` — wrap a raw code blob into a minimal
  Hexagon ELF so `llvm-objdump-18 --triple=hexagon --mcpu=hexagonv66` can decode it.
- `find_refs.py` / `find_callers.py` / `find_calls.py` / `xref.py` — find call/jump
  xrefs to a target VA (Hexagon PC-relative J2_call/J2_jump immediate decoding).
- `build_fns.py` — build a function-boundary table (`_fns.pkl`) from prologue
  detection over the disasm index, used for sound reachability.
- `reach.py` / `bfs*.py` — forward call-graph reachability using function extents
  `[start, next_start)`. `bfs5.py` is the sound version (static edges only + an
  explicit resolved-callr edge table; no blanket immediate heuristic).
- `resolve_callr.py` — for a function, resolve `callr` targets by the last
  `= ##imm` assignment to the target register before the callr.
- `check_resolver.py` — per-handler: does its call-graph reach the resolver
  0xd8272684 / the setter 0xd8279264, and list unresolved `callr` in the set.
- `scan_ptr_access.py` — scan the image for immext(#0xca79c480)+memw touching the
  active-carrier pointer 0xca79c494 (the NULL-deref SSR cause).
- `up_trace.py` — trace callers upward until reaching a known wrapper/dispatcher.
- `vmap.py` — VA <-> file-offset mapping for the segments.

## clade decompression helpers (superseded by libclade.so, kept for reference)

`clade_*.py`, `scan_*.py`, `find_clade_dicts*.py`, `validate_linear.py`,
`clade_extractor_sm6375.c` + `clade_api.h`. The HW-accurate path is `libclade.so`
(in clade-tools-repos.tgz); these were the reverse-engineering steps.

## FTM/RFTEST table + TLV extractors

`tbl_*.py`, `diagtbl*.py`, `find_cmdtbl.py`, `handlertbl.py`, `seltbl.py`,
`techtbl.py`, `techenum.py`, `grouphdr.py`, `gen_final_tlv.py`, `gen_split.py`,
`iqfmt.py`, `rxtune_ctx.py`, `packet_disasm.py` — parse the FTM selector tables,
the RFTEST TLV group/field tables, and build candidate packets.

## findings-txt/

Raw text dumps referenced by the `.md` reports (strings, selector tables, TLV id
lists). The narrative `.md` reports themselves live in the repo under
`docs/modem-diag-wip/blob-analysis/`.

## Key result (see the repo roadmap for the full story)

The RFTEST wire protocol is fully mapped: `4b 0b | 27 00 | sub_command(2) |
tlv_count(2) | body@8 | command_id@0x0a | params@0x0f..0x11 | TLVs@0x12`, where
command_id (byte 10) is the real command selector (runtime table @0xca79a850) and
sub_command picks a wrapper. Registration order gives command_id RADIO_CONFIG=0,
RX_MEASURE=1, IQ_CAPTURE=5, COMMAND_CAPABILITY=0x0b. Live, every RFTEST command
still SSRs (NULL deref of active-carrier ptr 0xca79c494); static RE exhausted
because the 0x10xx handlers use runtime callr dispatch that BFS cannot follow.

## on-device-scripts/ (added session 7, 2026-09-26)

Self-contained bring-up drivers that run ON THE PHONE and log to /tmp/iqrun/, so
we stop fighting SSH glitches. Copy to the phone and run with setsid.

- `rhodep-iq-memshare-run.sh` - full memshare + IQ path: preflight, load
  rhodep_memassign (reserved 0x8ab00000, dual-VMID), start memshare-daemon,
  restart remoteproc0, watch dmesg, diag TECH_ENTER->RADIO_CONFIG->IQ_CAPTURE,
  read /dev/rhodep_memshare. Toggles DO_MODEM_RESTART / DO_DIAG.
- `rhodep-diag-probe.sh` - validate the DIAG handshake in isolation.
  MODE=kick (no restart, keep RF state) or MODE=restart (crash-restart, 100%
  reliable handshake). CMD=<hex> or RAWSEQ=<comma hex>. Logs to /tmp/iqrun/probe.log.
- `rhodep-iq-cleanboot.sh` - publish the diag server, then a CLEAN remoteproc0
  stop/start so the modem re-boots (RF healthy, connected==0) and does its
  modem-first handshake with us, then fire the IQ sequence.

NOTE (session 7 finding): the memshare path is NOT the IQ sample channel - samples
come back inline over the DIAG FETCH response (paginated). The memshare module +
char device are correct infra but off the IQ critical path. The deepest blocker is
entering RF cal mode (gate 0xcbf4f740==2), whose trigger is in resident modem code
outside the MBN. See findings/{memshare_request_flow,iq_delivery_channel,
cal_entry_sequence}.md and the repo's docs/modem-diag-wip/NEXT-STEPS-IQ.md.

## Update (session 8, 2026-09-26) — cal-mode fully mapped; live dump blocked

on-device-scripts/ now also has rhodep-ftm-coredump.sh (async coredump capture) and
rhodep-peek-gates.sh (read the gate globals via the mpeek module). kernel-modules/
has rhodep_mpeek.c (per-page modem-DDR peek via SCM assign) and rhodep_memassign.c.

The RF cal-mode entry chain is now 100% mapped byte-exact (see findings/:
cal_trigger_chain, ftm_phase_byte, routing_byte_wire, tech_enter_callback,
scenario_field, gate_globals_phys, dump_targets). The blocker is confirmed:
- config-apply (RFTEST 0x10xx, wire[0x0f]=wire[0x10]=0) SSRs live anyway - depends
  on internal RF state set by resident modem code (the factory-tool cal flow).
- reading live modem RAM to RE that resident code is BLOCKED: SCM reassign of the
  modem's active pages returns -22 EINVAL (TZ), and remoteproc coredump is empty in
  mainline (q6v5 doesn't vault memory; inline hangs SSH, enabled gives 0 bytes).
Remaining dump path = QDL/EDL ramdump. See docs/modem-diag-wip/NEXT-STEPS-IQ.md.
