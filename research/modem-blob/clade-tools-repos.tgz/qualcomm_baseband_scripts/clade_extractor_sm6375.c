/* CLADE extractor adapted for SM6375 (Moto G82 5G) MPSS.HI.4.3.4
 *
 * Strategy: libclade.so does ALL the real CLADE work (dict + exception words,
 * HW-accurate). We only need to feed it the firmware memory it asks for.
 *
 * client_lookup() is a UNIVERSAL VA->bytes mapper: whatever virtual address
 * libclade requests (comp stream, dicts, exception sections), we resolve it
 * against the loaded modem.b* segments (by p_vaddr / filesz) and return the
 * real bytes. This is robust to whatever internal addresses clade_init derives.
 *
 * We build a synthetic contiguous "region" so that:
 *   region            -> .clade.comp   (b26 off 0,        VA 0xcc000000)
 *   region+0x4000000  -> exc_high      (candidate section)
 * and dicts[] -> the 3 dicts at b26 off 0x2444000 (VA 0xce444000).
 *
 * Because clade_init OVERWRITES pd_params.comp/exc_hi from `region`
 * (comp=region, exc_hi=region+0x4000000), we set region so those derived
 * addresses land on real, mapped firmware bytes via the universal mapper.
 */
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "clade_api.h"

/* ---- firmware segment table (p_vaddr, file, filesz) ---- */
typedef struct { uint64_t vaddr; const char *path; uint64_t filesz; uint8_t *buf; } seg_t;

static seg_t segs[] = {
    { 0xc0800000ULL, "modem.b02", 0x00002930, 0 },
    { 0xa44f9000ULL, "modem.b03", 0x00002460, 0 },
    { 0xc0900000ULL, "modem.b04", 0x0003bd40, 0 },
    { 0xc0980000ULL, "modem.b05", 0x0002c190, 0 },
    { 0xc09ad000ULL, "modem.b06", 0x0003e4a0, 0 },
    { 0xc09ec000ULL, "modem.b07", 0x0000e3b0, 0 },
    { 0xc09fb000ULL, "modem.b08", 0x0002380c, 0 },
    { 0xc0a1f000ULL, "modem.b09", 0x00060064, 0 },
    { 0xc0a80000ULL, "modem.b10", 0x0029ab14, 0 },
    { 0xc0d20000ULL, "modem.b11", 0x00009140, 0 },
    { 0xc0d30000ULL, "modem.b12", 0x00006000, 0 },
    { 0xc0d36000ULL, "modem.b13", 0x0031f1b0, 0 },
    { 0xc1080000ULL, "modem.b14", 0x00040000, 0 },
    { 0xc10c0000ULL, "modem.b15", 0x0039c000, 0 },
    { 0xc145d000ULL, "modem.b17", 0x0023aeb8, 0 },
    { 0xc16c0000ULL, "modem.b18", 0x000a9cb0, 0 },
    { 0xc1780000ULL, "modem.b19", 0x002d0000, 0 },
    { 0xc1a50000ULL, "modem.b20", 0x0096e988, 0 },
    { 0xc3553000ULL, "modem.b21", 0x00d315f4, 0 },
    { 0xc8b6a000ULL, "modem.b23", 0x005cdd97, 0 },
    { 0xcbf4f000ULL, "modem.b25", 0x00019900, 0 },
    { 0xcc000000ULL, "modem.b26", 0x0244a040, 0 },   /* .clade.comp + .clade.dict */
    { 0xce480000ULL, "modem.b27", 0x0011922f, 0 },   /* exc candidate */
    { 0xce59a000ULL, "modem.b28", 0x00016000, 0 },
    { 0xce5b1000ULL, "modem.b29", 0x00001064, 0 },
};
static const int NSEG = sizeof(segs)/sizeof(segs[0]);
static const char *g_fwdir = "/tmp/clade";

static void load_segs(void) {
    char p[512];
    for (int i = 0; i < NSEG; i++) {
        snprintf(p, sizeof(p), "%s/%s", g_fwdir, segs[i].path);
        FILE *f = fopen(p, "rb");
        if (!f) { fprintf(stderr, "cannot open %s\n", p); exit(2); }
        segs[i].buf = (uint8_t*)malloc(segs[i].filesz);
        size_t got = fread(segs[i].buf, 1, segs[i].filesz, f);
        (void)got;
        fclose(f);
    }
}

/* If libclade asks for a small offset (base pd+0x00 == 0), it means an offset
 * into the compressed stream. We redirect those to the comp section base. */
static uint64_t g_comp_base_va = 0xcc000000ULL;   /* .clade.comp VA */
static uint64_t g_comp_len     = 0x2444000ULL;

/* resolve a VA to a host pointer, copying `len` bytes into dst.
 * returns 1 if fully resolved, 0 otherwise (zero-fills the rest). */
static int resolve_va(uint64_t va, uint8_t *dst, uint64_t len) {
    /* small addresses => offset into compressed stream */
    if (va < g_comp_len) va += g_comp_base_va;
    uint64_t done = 0;
    while (done < len) {
        uint64_t cur = va + done;
        int hit = 0;
        for (int i = 0; i < NSEG; i++) {
            if (cur >= segs[i].vaddr && cur < segs[i].vaddr + segs[i].filesz) {
                uint64_t off = cur - segs[i].vaddr;
                uint64_t avail = segs[i].filesz - off;
                uint64_t chunk = (len - done < avail) ? (len - done) : avail;
                memcpy(dst + done, segs[i].buf + off, chunk);
                done += chunk;
                hit = 1;
                break;
            }
        }
        if (!hit) {
            /* zero-fill one byte and continue (unmapped) */
            dst[done] = 0;
            done += 1;
        }
    }
    return 1;
}

/* ---------- clade client callbacks ---------- */
clade_memblock_t* client_alloc(clade_memblock_t *request, clade_memblock_t *previous, void *mem) {
    (void)mem;
    clade_memblock_t *return_block;
    clade_memblock_t *request_temp = request;
    do {
        return_block = (clade_memblock_t*)calloc(1, sizeof(clade_memblock_t));
        return_block->id[0] = 0;
        return_block->wordsize = 1;
        return_block->len = 0;
        return_block->addr = 0;
        return_block->data = 0;
        return_block->next = 0;
        return_block->prev = 0;
        if (previous) {
            previous->prev->next = return_block;
            return_block->prev = previous->prev;
            previous->prev = return_block;
            return_block->next = previous;
        } else {
            return_block->prev = return_block;
            return_block->next = return_block;
            previous = return_block;
        }
        return_block->wordsize = request_temp->wordsize;
        return_block->addr = request_temp->addr;
        return_block->len = request_temp->len;
        return_block->data = (uint64_t)(uintptr_t)malloc(request_temp->len * request_temp->wordsize);
        request_temp = request_temp->next;
    } while (request_temp != request);
    return previous;
}

static int g_dbg_lookup = 0;
clade_memblock_t* client_lookup(clade_memblock_t *request, void *mem) {
    (void)mem;
    clade_memblock_t *request_temp = request;
    do {
        uint64_t n = (uint64_t)request_temp->len * (uint64_t)request_temp->wordsize;
        request_temp->data = (uint64_t)(uintptr_t)malloc(n ? n : 1);
        resolve_va(request_temp->addr, (uint8_t*)(uintptr_t)request_temp->data, n);
        if (g_dbg_lookup) {
            uint8_t *d = (uint8_t*)(uintptr_t)request_temp->data;
            fprintf(stderr, "[lookup] addr=0x%llx len=%llu ws=%u first=%02x%02x%02x%02x\n",
                (unsigned long long)request_temp->addr, (unsigned long long)n,
                request_temp->wordsize, n>0?d[0]:0, n>1?d[1]:0, n>2?d[2]:0, n>3?d[3]:0);
        }
        request_temp = request_temp->next;
    } while (request_temp != request);
    return request;
}

int client_free(clade_memblock_t *request) {
    (void)request;
    return 1;
}

int main(int argc, char **argv) {
    if (argc < 4) {
        printf("usage: %s <out_file> <req_vaddr_hex> <req_len_hex> [region_hex] [dict_va_hex] [fwdir]\n", argv[0]);
        printf("  default region = 0xcc000000 (.clade.comp), dict_va = 0xce444000\n");
        return 1;
    }
    char *out_file = argv[1];
    uint64_t req_va  = strtoull(argv[2], NULL, 16);
    uint64_t req_len = strtoull(argv[3], NULL, 16);
    uint64_t region  = (argc > 4) ? strtoull(argv[4], NULL, 16) : 0xcc000000ULL;
    uint64_t dict_va = (argc > 5) ? strtoull(argv[5], NULL, 16) : 0xce444000ULL;
    if (argc > 6) g_fwdir = argv[6];

    load_segs();

    printf("Decompressing CLADE: req_va=0x%llx len=0x%llx region=0x%llx dict_va=0x%llx\n",
           (unsigned long long)req_va, (unsigned long long)req_len,
           (unsigned long long)region, (unsigned long long)dict_va);

    clade_create_trace_file("stdout");
    if (getenv("CLADE_TRACE")) clade_set_trace((int)strtoul(getenv("CLADE_TRACE"), NULL, 0));
    if (getenv("DBG_LOOKUP")) g_dbg_lookup = 1;

    /* libclade dereferences config.dicts[] DIRECTLY (not via client_lookup),
     * so these must be REAL host pointers to the dictionary bytes.
     * Resolve dict_va from firmware into a host buffer. */
    uint8_t *dictbuf = (uint8_t*)malloc(3 * 0x2000);
    resolve_va(dict_va, dictbuf, 3 * 0x2000);
    uint64_t clade_dict_ptrs[3];
    clade_dict_ptrs[0] = (uint64_t)(uintptr_t)(dictbuf + 0*0x2000);
    clade_dict_ptrs[1] = (uint64_t)(uintptr_t)(dictbuf + 1*0x2000);
    clade_dict_ptrs[2] = (uint64_t)(uintptr_t)(dictbuf + 2*0x2000);

    static clade_pd_params_t pd;
    memset(&pd, 0, sizeof(pd));
    pd.comp   = region;
    pd.exc_hi = region + 0x4000000ULL;

    static clade_config_t config;
    memset(&config, 0, sizeof(config));
    config.region    = region;
    config.num_pds   = 1;
    config.num_dicts = 3;
    config.dict_len  = 0x2000;
    config.pd_params = &pd;
    config.dicts     = (uint32_t **)clade_dict_ptrs;

    int rc = clade_init(&config);
    printf("clade_init rc=%d error=%u  (pd.comp=0x%llx pd.exc_hi=0x%llx comp_len=0x%x exc_len=0x%x)\n",
           rc, config.error,
           (unsigned long long)pd.comp, (unsigned long long)pd.exc_hi,
           pd.comp_len, pd.exc_hi_len);

    clade_memblock_t request;
    memset(&request, 0, sizeof(request));
    request.addr = req_va;
    request.data = 0;
    request.wordsize = 1;
    request.len = (uint32_t)req_len;
    request.next = &request;
    request.prev = &request;

    clade_memblock_t *read_block =
        clade_read(&request, NULL, client_alloc, client_lookup, client_free);

    printf("clade_read returned %p, config.error=%u\n", (void*)read_block, config.error);
    if (!read_block) {
        printf("clade_read FAILED\n");
        return 3;
    }

    /* concatenate all result blocks in order */
    FILE *f = fopen(out_file, "wb");
    clade_memblock_t *b = read_block;
    uint64_t total = 0;
    do {
        uint64_t n = (uint64_t)b->len * (uint64_t)b->wordsize;
        if (b->data && n) {
            fwrite((void*)(uintptr_t)b->data, 1, n, f);
            total += n;
        }
        b = b->next;
    } while (b != read_block);
    fclose(f);
    printf("Wrote 0x%llx bytes to %s\n", (unsigned long long)total, out_file);
    printf("Done!\n");
    return 0;
}
