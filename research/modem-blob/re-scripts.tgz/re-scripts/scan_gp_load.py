#!/usr/bin/env python3
import struct,subprocess,sys
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack('<I',data[i:i+4])[0] for i in range(0,N-3,4)]
sys.path.insert(0,'/tmp/modemre')
from mkelf import make_elf

# gp load memub(gp+#0x740): 0x49236?02 (from 49236802 r2). mask reg nibble bits[11:8]
def is_gp_load(w):
    return (w & 0xFFFFF0FF)==0x49236002  # memub
def is_gp_load_b(w):
    return (w & 0xFFFFF0FF)==0x49036000  # memb signed? check

loads=[]
for i,w in enumerate(words):
    if is_gp_load(w) or is_gp_load_b(w):
        loads.append(BASE+i*4)
print("gp+0x740 loads:",len(loads))
def dis(va,n=4):
    off=va-BASE
    make_elf(data[off:off+n*4],va,'/tmp/_l.elf')
    out=subprocess.check_output(['llvm-objdump-18','-d','--triple=hexagon','--mcpu=hexagonv66','/tmp/_l.elf']).decode()
    return "\n".join(out.splitlines()[7:])
for va in loads:
    print("==== %08x ===="%va)
    print(dis(va,4))
    print()
