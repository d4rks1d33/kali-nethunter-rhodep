#!/usr/bin/env python3
# Find the function start (prologue) at-or-before a VA by scanning backward for the standard
# Hexagon prologue: a packet containing allocframe(...) (usually with call 0xd814e6ac stack-check)
# or a leaf whose previous instruction is dealloc_return/jumpr r31.
import subprocess, re, sys
DIS='/tmp/modemre/dis.sh'
def dis(va,ln): 
    return subprocess.run([DIS,hex(va),hex(ln)],capture_output=True,text=True).stdout
def find_start(va, back=0x400):
    txt=dis(va-back, back+0x10)
    lines=txt.splitlines()
    starts=[]
    prev_terminal=True  # start of window counts as after-terminal
    for ln in lines:
        m=re.match(r'\s*([0-9a-f]+):',ln)
        if not m: 
            continue
        addr=int(m.group(1),16)
        if addr>va: break
        if 'allocframe' in ln:
            starts.append(addr)
    return starts[-1] if starts else None
if __name__=='__main__':
    va=int(sys.argv[1],0)
    print(hex(find_start(va)) if find_start(va) else "NOTFOUND")
