#!/usr/bin/env python3
# For each handler: does its sound call-graph reach the resolver 0xd8272684? Also list any 'callr'
# occurrences (unresolved indirect calls) in the reachable set, and whether it reaches setter 0xd8279264.
import re, sys, bisect
LO,HI=0xd8000000,0xd8a00000
RESOLVER=0xd8272684; SETTER=0xd8279264; GETTER=0xd827923c
CALLR_EDGES={0xd8272cd8:{0xd826d3e4,0xd8292298}}
BLACK={0xd814e6ac,0xd8829a00,0xd8829688,0xd8829698,0xd8829924,0xd8829a04,
 0xd80d77a8,0xd80d8998,0xd80d8988,0xd80d8990,0xd8041828,0xc0913a54,0xc0913ad8}
RET_TRAMP={0xd8829698,0xd8829688,0xd8829a00,0xd8829924,0xc0913b74,0xc0913a54,0xc0913ad8,0xc0913b6c,0xc0913bd8,0xd8829a04}
def is_ret(t): return t in RET_TRAMP or 0xc0913a00<=t<0xc0913c00
LINES={};ORDER=[]
for ln in open('/tmp/modemre/_idx.txt'):
    m=re.match(r'([0-9a-f]{8}):',ln)
    if m:
        a=int(m.group(1),16)
        if a not in LINES: LINES[a]=ln;ORDER.append(a)
ORDER.sort()
def body(va,cap=0x600):
    i=bisect.bisect_left(ORDER,va);out=[];ended=False;end=va+cap
    while i<len(ORDER):
        a=ORDER[i]
        if a>=end:break
        ln=LINES[a];out.append((a,ln))
        if 'dealloc_return' in ln or re.search(r'jumpr r31',ln):ended=True
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            if is_ret(int(j,16)):ended=True
        if ended and '}' in ln:break
        i+=1
    return out
fc={}
def callees(va):
    if va in fc:return fc[va]
    cs=set();callr=False
    for a,ln in body(va):
        for c in re.findall(r'call (0x[0-9a-f]+)',ln):cs.add(int(c,16))
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            jv=int(j,16)
            if is_ret(jv):continue
            if LO<=jv<HI and (jv<va-0x20 or jv>va+0x600):cs.add(jv)
        if 'callr' in ln:callr=True
    cs|=CALLR_EDGES.get(va,set())
    fc[va]=(cs,callr);return fc[va]
def bfs(root,maxd=25):
    seen=set();fr={root};d=0;hit={};callr_fns=set()
    while fr and d<maxd:
        nx=set()
        for x in fr:
            if x in seen:continue
            seen.add(x);cs,callr=callees(x)
            if callr and x not in CALLR_EDGES: callr_fns.add(x)
            for t in (RESOLVER,SETTER,GETTER):
                if t in cs:hit[t]=x
            for c in cs:
                if c in BLACK:continue
                if LO<=c<HI and c not in seen:nx.add(c)
        fr=nx-seen;d+=1
    return seen,hit,callr_fns
if __name__=='__main__':
    va=int(sys.argv[1],0)
    seen,hit,callr_fns=bfs(va)
    print(f"{hex(va)}: resolver={RESOLVER in hit} setter={SETTER in hit} getter={GETTER in hit} "
          f"scanned={len(seen)} unresolved_callr_fns={len(callr_fns)}")
    if '-c' in sys.argv:
        for f in sorted(callr_fns)[:40]: print("   callr in",hex(f))
