import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]
    n=d.find(b'\x00')
    if n<0: n=maxlen
    try: return d[:n].decode('ascii')
    except: return None
def is_name_ptr(v):
    if v is None or not is_valid_va(v): return False
    s=cstr(v,64)
    if not s: return False
    if len(s)<2 or len(s)>40: return False
    return all(c.isupper() or c.isdigit() or c in '_ ' for c in s)

start=0xc906c268
end=0xc906cea0
va=start
groups=[]  # list of (start_va, [names])
cur=None
curstart=None
while va<end:
    v=u32(va)
    s=cstr(v) if is_valid_va(v) else None
    if v==0:
        if cur is not None:
            groups.append((curstart,cur))
            cur=None
        va+=4
        continue
    if s=='UNASSIGNED':
        if cur is not None:
            groups.append((curstart,cur))
        cur=['UNASSIGNED']
        curstart=va
    elif is_name_ptr(v):
        if cur is None:
            cur=[]; curstart=va
        cur.append(s)
    else:
        # non-name in middle: end group
        if cur is not None:
            groups.append((curstart,cur)); cur=None
    va+=4
if cur is not None:
    groups.append((curstart,cur))

print("TOTAL GROUPS:", len(groups))
for gi,(gs,names) in enumerate(groups):
    print("\n=== GROUP %d @ 0x%08x  (%d fields) ==="%(gi,gs,len(names)))
    for i,n in enumerate(names):
        print("  [%3d] %s"%(i,n))
