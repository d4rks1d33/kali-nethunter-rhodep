import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
def is_name_ptr(v):
    if v is None or not is_valid_va(v): return False
    s=cstr(v,64)
    if not s: return False
    if len(s)<2 or len(s)>40: return False
    return all(c.isupper() or c.isdigit() or c in '_ ' for c in s)
def read_group(base):
    # read until next UNASSIGNED (excluded) or zero
    names=[]; va=base
    first=True
    while True:
        v=u32(va)
        if v==0: break
        if not is_name_ptr(v): break
        s=cstr(v)
        if s=='UNASSIGNED' and not first:
            break
        names.append((va,s)); va+=4; first=False
    return names

# Group 13 = RADIO_CONFIG / RX_TUNE ; Group 14 = RX_MEASURE / IQ_CAPTURE
g13=read_group(0xc906c630)
g14=read_group(0xc906c720)

with open('/tmp/modemre/findings/rftest_tlv_RX_TUNE_ids.txt','w') as f:
    f.write("FTM RF-TEST : RADIO_CONFIG / RX_TUNE  TLV field-id table (FACT)\n")
    f.write("Source: char* array @ 0xc906c630 (seg23). field_id = array index.\n")
    f.write("Module: ftm_rf_test_radio_config.c ; log tag [FTM.RFTEST][RADIO_CONFIG]\n")
    f.write("Related: RX_TUNE_CMD string @0xc379794c.\n\n")
    f.write("field_id  name                        ptr_va\n")
    for i,(va,s) in enumerate(g13):
        f.write("  %-3d     %-27s 0x%08x\n"%(i,s,va))
    f.write("\nTotal: %d fields (0..%d)\n"%(len(g13),len(g13)-1))

with open('/tmp/modemre/findings/rftest_tlv_IQ_CAPTURE_ids.txt','w') as f:
    f.write("FTM RF-TEST : RX_MEASURE / IQ_CAPTURE  TLV field-id table (FACT)\n")
    f.write("Source: char* array @ 0xc906c720 (seg23). field_id = array index.\n")
    f.write("Module: ftm_rf_test_rx_measure.c / ftm_rf_test_iq_capture.c\n")
    f.write("Log tag [FTM.RFTEST][RX_MEASURE] and [FTM.RFTEST][IQ_CAPTURE]\n\n")
    f.write("field_id  name                                  ptr_va\n")
    for i,(va,s) in enumerate(g14):
        f.write("  %-3d     %-37s 0x%08x\n"%(i,s,va))
    f.write("\nTotal: %d fields (0..%d)\n"%(len(g14),len(g14)-1))
    f.write("\nKey IQ-capture fields:\n")
    for i,(va,s) in enumerate(g14):
        if s in ('FETCH_IQ','NUM_OF_SAMPLES','IQ_DATA_FORMAT','SAMP_FREQ',
                 'IQ_CAPTURE_TYPE','NUM_OF_CAPTURES','RX_CARRIER','RX_MODE',
                 'RX_AGC','SENSITIVITY','OVERRIDE_LNA','RX_GAIN_CTL_TYPE'):
            f.write("  id=%-3d %s\n"%(i,s))
print("g13:",len(g13),"g14:",len(g14))
print(open('/tmp/modemre/findings/rftest_tlv_RX_TUNE_ids.txt').read())
