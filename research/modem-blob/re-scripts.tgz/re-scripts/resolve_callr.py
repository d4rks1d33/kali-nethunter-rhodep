#!/usr/bin/env python3
# For a function, find callr sites and try to resolve the target register's immediate within the
# function (last '= ##imm' assignment to that register before the callr). Reports resolved targets.
import re, bisect, pickle, sys
LINES,ORDER,S = pickle.load(open('/tmp/modemre/_fns.pkl','rb'))
def fn_range(va):
    i=bisect.bisect_right(S,va)-1
    if i>=0 and S[i]==va:
        nxt=S[i+1] if i+1<len(S) else va+0x800
        return va,min(nxt,va+0x2000)
    return va,va+0x120
def resolve(va):
    lo,hi=fn_range(va)
    i=bisect.bisect_left(ORDER,lo)
    regval={}  # reg -> last imm
    targets=set(); unresolved=0
    while i<len(ORDER):
        a=ORDER[i]
        if a>=hi: break
        ln=LINES[a]
        # track rN = ##imm
        for reg,hx in re.findall(r'(r\d+) = ##(-?0x[0-9a-f]+)', ln):
            v=int(hx,16)
            if v<0: v&=0xffffffff
            regval[reg]=v
        # also rN = rM (copy) - approximate
        for dst,src in re.findall(r'(r\d+) = (r\d+)\b', ln):
            if src in regval: regval[dst]=regval[src]
        m=re.search(r'callr (r\d+)', ln)
        if m:
            reg=m.group(1)
            if reg in regval: targets.add(regval[reg])
            else: unresolved+=1
        i+=1
    return targets, unresolved
if __name__=='__main__':
    va=int(sys.argv[1],0)
    t,u=resolve(va)
    print(f"{hex(va)}: resolved={[hex(x) for x in sorted(t)]} unresolved={u}")
