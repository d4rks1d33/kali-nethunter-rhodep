#!/usr/bin/env python3
# Find where r=##0xcb8dbeb0 (or ##0xcb8dbe.. that resolves to the struct) is loaded into a reg,
# then look for a store memX(rReg+#off)=Rt within a window that targets +0x18 (or nearby).
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack_from('<I',data,i)[0] for i in range(0,N-3,4)]
NW=len(words)

def immext_val(w):
    if (w>>28)!=0: return None
    return (((((w>>16)&0xFFF)<<14)|(w&0x3FFF))<<6) & 0xffffffff

def top(w): return (w>>24)&0xff

# Step 1: identify all sites where a register is set to a value in struct range via immext+tfr.
# tfrsi form A2_tfrsi: 0x78 top. reg dst field bits [4:0]? For '78004610' -> r16.
#   Encoding r=##S16: word 0x78 ... dst in bits[4:0]. immext supplies high, low 16 in word.
# combine imm A2_combineii etc use 0x2b. We saw '2b0a2831' => r18=##0xcb8dbeb0;r1=#3.
# Let's just record: for each immext in struct range, decode dst reg of next insn if it's a
# register-setting form (0x78 tfrsi, 0x2b combine/immediate, 0x68 too), and the full value.

# effective value = immext | (low bits from paired insn). For tfrsi low16 = word & 0xffff (signed?).
# For 0x78: bits: r=##imm. low part = ((w>>5)&0x3ff)<<? ... simpler: value = immext_high | low
# Actually for extended immediates, low 6 bits come from the immediate field low bits and the
# rest from immext. The effective const = immext_value | (imm_field & 0x3f). We only need the reg.

def dst_reg(w):
    return w & 0x1f

setters=[]  # (idx, reg, approx_val)
for i,w in enumerate(words):
    v=immext_val(w)
    if v is None: continue
    if not (0xcb8dbe80<=v<=0xcb8dbf00): continue
    n1=words[i+1] if i+1<NW else 0
    t=top(n1)
    if t in (0x78,0x68,0x2b,0x7e,0x7c):
        reg=dst_reg(n1)
        setters.append((i+1, reg, v, BASE+i*4))

# Step 2: for each setter, scan forward up to 40 insns for a store memX(reg+#off)=Rt or =#imm
# store reg form top 0xa1: memX(Rs+#s11)=Rt. Rs in bits[20:16].
# store imm form top 0x3c: memX(Rs+#u6)=#S. Rs in bits[20:16].
def store_base(w): return (w>>16)&0x1f

def store_off(w):
    t=top(w)
    if t==0xa1:
        # S2_storerX_io: memX(Rs+#s11)=Rt. offset scaled by size. bits[13:0]... 
        # We'll extract a rough offset: bits[13:0] with sign; scale unknown. Just report raw fields.
        off = (w & 0x7ff)  # low 11-ish
        return off
    if t==0x3c:
        return (w>>7)&0x3f
    return None

print("=== register set to struct base, followed by store on same reg (window 40) ===")
found=[]
for si,reg,v,setva in setters:
    for j in range(si+1, min(si+41,NW)):
        w=words[j]; t=top(w)
        if t in (0xa1,0x3c,0xa0):
            if store_base(w)==reg:
                va=BASE+j*4
                found.append((setva,v,reg,va,w,t))
                break
        # stop if reg reloaded
        if t in (0x78,0x68,0x2b) and dst_reg(w)==reg:
            break
for setva,v,reg,va,w,t in found:
    print("setbase@%08x (=%08x r%d) -> STORE@%08x word=%08x top=%02x base=r%d"%(
        setva,v,reg,va,w,t,(w>>16)&0x1f))
print("total store sites:",len(found))
