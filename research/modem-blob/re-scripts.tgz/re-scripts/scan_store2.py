#!/usr/bin/env python3
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack('<I',data[i:i+4])[0] for i in range(0,N-3,4)]
W=len(words)

# memb(rX+#0)=#2 : 0x3c??c002  (mask: 0xFF00FFFF == 0x3c00c002)
def is_memb_imm2(w): return (w & 0xFF00FFFF)==0x3c00c002
# what reg? bits [23:16]. For r2 -> 0x02, r16->0x10, r0->0x00
def store_reg(w): return (w>>16)&0xff

IMMEXT=0x0cbf53dd
# address-load r?=##0xcbf4f740 : from d81bd7c0: 28022800 -> combine? Actually r2=##0xcbf4f740;r0=#0
# generic absolute set via immext+r=##imm. We just look for IMMEXT within 3 packets before a memb=#2.

# collect all immext(0xcbf4f740) sites (word index)
immext_idx=set(i for i,w in enumerate(words) if w==IMMEXT)

hits=[]
for i,w in enumerate(words):
    if is_memb_imm2(w):
        va=BASE+i*4
        # check preceding 4 words for the gate immext
        near=[j for j in range(max(0,i-5),i) if j in immext_idx]
        hits.append((va,store_reg(w),bool(near),near))

print("total memb(rX)=#2 stores:",len(hits))
near_hits=[h for h in hits if h[2]]
print("with gate-immext nearby:",len(near_hits))
for va,reg,n,near in near_hits:
    print("  %08x reg=%02x immext_at=%s"%(va,reg,[hex(BASE+j*4) for j in near]))
