import sys, struct
sys.path.insert(0,'/tmp/q6zip')
import ELF

elf=ELF.read(open('/tmp/modemre/modem_full.elf','rb'))
fh=open('/tmp/modemre/modem_full.elf','rb')
segs=[s for s in elf.pgm if (s.type<=1 and s.filesize>0)]

# Define candidate "target ranges" that a page-pointer table might point into.
# These are the compressed backing store ranges. We test several.
target_ranges = [
    ('seg26', 0xcc000000, 0xce48a000),
    ('seg21', 0xc3553000, 0xd0000000),
    ('d8win', 0xd8000000, 0xd9000000),
    ('d4win', 0xd4400000, 0xd6539000),
    ('any_c', 0xc0000000, 0xd0000000),
]

def scan(lo, hi, name, minlen=200, maxdelta=0x8000):
    results=[]
    for s in segs:
        fh.seek(s.fileoffset); data=fh.read(s.filesize)
        n=len(data)//4
        words=struct.unpack_from('<%dL'%n, data, 0)
        i=0
        while i < n-minlen:
            # try to start a monotonic run at i where words in range
            if not (lo <= words[i] < hi):
                i+=1; continue
            j=i+1
            prev=words[i]
            while j<n:
                w=words[j]
                if lo <= w < hi and prev <= w and (w-prev) < maxdelta:
                    prev=w; j+=1
                else:
                    break
            runlen=j-i
            if runlen>=minlen:
                va=s.vaddr+i*4
                results.append((name, va, runlen, words[i], words[j-1]))
                i=j
            else:
                i+=1
    return results

allres=[]
for name,lo,hi in target_ranges:
    r=scan(lo,hi,name)
    allres+=r

allres.sort(key=lambda x:-x[2])
print("top monotonic pointer-table candidates (range,va,len,first,last):")
for name,va,runlen,first,last in allres[:40]:
    print("  %-6s @%08x len=%5d [%08x..%08x] span=%08x"%(name,va,runlen,first,last,last-first))
