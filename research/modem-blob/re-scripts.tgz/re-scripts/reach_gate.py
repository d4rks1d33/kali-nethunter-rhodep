#!/usr/bin/env python3
# Function-bounded reachability toward the RF-cal gates from a root, using _fns.pkl.
import re, bisect, pickle, sys
LINES,ORDER,S = pickle.load(open('/tmp/modemre/_fns.pkl','rb'))
LO,HI=0xd8000000,0xdb000000
BLACK={0xd814e6ac,0xd8829a00,0xd8829688,0xd8829698,0xd8829924,0xd8829a04,
 0xd80d77a8,0xd80d8998,0xd80d8988,0xd80d8990,0xd80dec28,0xd8153650,0xd8242f98,
 0xd824a148,0xd824a134,0xd824a30c,0xd824a624,0xd824a75c,0xd824f5f8,0xd80d1750,
 0xd8157900,0xd81578f8,0xd8062414,0xd8069ec8,0xd806af1c}
RET_TRAMP={0xd8829698,0xd8829688,0xd8829a00,0xd8829924,0xc0913b74,0xc0913a54,0xc0913ad8,0xc0913b6c,0xc0913bd8,0xd8829a04}
def is_ret(t): return t in RET_TRAMP or 0xc0913a00<=t<0xc0913c00
def fn_range(va):
    i=bisect.bisect_right(S,va)-1
    if i>=0 and S[i]==va:
        nxt = S[i+1] if i+1<len(S) else va+0x800
        return va, min(nxt, va+0x2000)
    return va, va+0x200
# gate signature strings to detect in a function body
GATE_PATTS=[
 ('gateA_740', re.compile(r'gp\+#0x740|0xcbf4f740')),
 ('gateB_7000',re.compile(r'gp\+#0x7000|0xcbf56000')),
 ('carrier_494',re.compile(r'0xca79c494')),
 ('table_733d10',re.compile(r'0xca733d10')),
]
fc={}
def analyze(va):
    if va in fc: return fc[va]
    lo,hi=fn_range(va)
    i=bisect.bisect_left(ORDER,lo)
    cs=set(); callr=False; gates=set()
    is_leaf = not (bisect.bisect_right(S,va)-1>=0 and S[bisect.bisect_right(S,va)-1]==va)
    while i<len(ORDER):
        a=ORDER[i]
        if a>=hi: break
        ln=LINES[a]
        for c in re.findall(r'call (0x[0-9a-f]+)',ln): cs.add(int(c,16))
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            jv=int(j,16)
            if is_ret(jv): continue
            if LO<=jv<HI and not(lo<=jv<hi): cs.add(jv)
        if 'callr' in ln: callr=True
        for nm,p in GATE_PATTS:
            if p.search(ln): gates.add((nm,a))
        i+=1
    fc[va]=(cs,callr,gates); return fc[va]
def bfs(root,maxnodes=8000):
    seen=set(); fr=[root]; parent={root:None}
    callr_fns=set(); gate_hits=[]
    while fr:
        x=fr.pop()
        if x in seen: continue
        seen.add(x)
        if len(seen)>maxnodes: break
        cs,callr,gates=analyze(x)
        if callr: callr_fns.add(x)
        for g in gates: gate_hits.append((g,x))
        for c in cs:
            if c in BLACK: continue
            if LO<=c<HI and c not in seen and c not in parent:
                parent[c]=x; fr.append(c)
    return seen,parent,callr_fns,gate_hits
def chn(parent,n):
    c=[]
    while n is not None:c.append(n);n=parent.get(n)
    return list(reversed(c))
if __name__=='__main__':
    root=int(sys.argv[1],0)
    seen,parent,callr_fns,gate_hits=bfs(root)
    print("root",hex(root),"scanned",len(seen),"functions")
    print("callr-bearing functions in subtree:",len(callr_fns))
    if gate_hits:
        for (nm,a),fn in gate_hits:
            print("  GATE %s at %s in fn %s"%(nm,hex(a),hex(fn)))
            print("    path:"," -> ".join(hex(z) for z in chn(parent,fn)))
    else:
        print("  NO gate/table reference reachable")
    if '-c' in sys.argv:
        for f in sorted(callr_fns):
            print("  callr@",hex(f)," path:"," -> ".join(hex(z) for z in chn(parent,f)))
