#!/usr/bin/env python3
# Brute-force the compressed START offset for the page containing the FTM
# dispatcher. For each candidate comp bit-offset, decompress 1024 words and
# score how "clean" the Hexagon disassembly is (few unknowns). The correct
# page start yields the cleanest code.
import sys, struct, subprocess, os
sys.path.insert(0,'/tmp/q6zip')
from unclade import BitStreamReader, CladeDecompressor, decodewords

raw=open('/tmp/clade/modem.b26','rb').read()
DICTBASE=0x2444000
dicts=[list(decodewords(raw[DICTBASE+i*0x2000:DICTBASE+(i+1)*0x2000])) for i in range(3)]
C=CladeDecompressor(dicts)
words=list(decodewords(raw[0:DICTBASE]))

def decode_at(start_word, start_bit, skipfirst, nwords=1024):
    bits=BitStreamReader(words)
    bits.pos=start_word-1; bits.bitpos=32
    if start_bit:
        # consume start_word fully then start_bit bits
        pass
    bits.pos=start_word; bits.bitpos=start_bit
    bits.value=words[start_word] if start_word<len(words) else 0
    out=[]
    try:
        if skipfirst: bits.get(1)
        while len(out)<nwords:
            code=bits.get(2)
            if code<3:
                idx=bits.get(11); missing=bits.get(len(C.missingbits[code]))
                out.append(C.reconstructword(dicts[code][idx],C.missingbits[code],missing))
            else:
                out.append(bits.get(32))
    except (EOFError,IndexError):
        return None
    return out

def score(outwords):
    data=struct.pack('<%dL'%len(outwords),*outwords)
    open('/tmp/bp.bin','wb').write(data)
    subprocess.run(['python3','/tmp/modemre/mkelf.py','/tmp/bp.bin','0xd8150000','/tmp/bp.elf'],stdout=subprocess.DEVNULL)
    r=subprocess.run(['llvm-objdump-18','--triple=hexagon','-d','/tmp/bp.elf'],capture_output=True,text=True)
    return r.stdout.count('unknown'), r.stdout

# linear estimate for page 336 start was compword ~243215 (byte 0xed83c) but that
# assumed word-align. Try a window of comp WORD offsets around the linear byte
# estimate 0x150e00-ish scaled. Actually search broadly near byte 0xe0000..0x100000.
best=(9999,None)
lo=0xe0000//4; hi=0x110000//4
for sw in range(lo,hi):
    for sb in (0,):
        o=decode_at(sw, sb, True)
        if o is None: continue
        # quick prefilter: does it look codey? skip heavy scoring unless prefilter passes
        # cheap: count zero words
        z=o.count(0)
        if z>20: continue
        u,_=score(o)
        if u<best[0]:
            best=(u,sw,sb)
            print('new best unknowns=%d at compword %d (byte 0x%x) skip=%s'%(u,sw,sw*4,sb))
        if u<40: 
            print('GOOD candidate compword',sw); 
print('best',best)
