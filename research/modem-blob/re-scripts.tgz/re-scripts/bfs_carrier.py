#!/usr/bin/env python3
# BFS the call-graph of each handler and detect touches of 0xca79c494 (load or store),
# the setter 0xd8279264, the per-carrier execs, and 0xca6e3228.
import subprocess, re, sys

DIS = '/tmp/modemre/dis.sh'
CODE_LO, CODE_HI = 0xd8000000, 0xd8a00000  # code window (10MB image)

# Targets of interest
TARGET_PTR = 0xca79c494      # active-carrier context pointer
SETTER     = 0xd8279264      # writes memw(0xca79c494)=r0
GETTER     = 0xd827923c      # returns memw(0xca79c494) (deref)
PERCARRIER_REGION = 0xca6e3228

cache_dis = {}
cache_calls = {}

def dis(va, ln=0x200):
    key = (va, ln)
    if key in cache_dis:
        return cache_dis[key]
    o = subprocess.run([DIS, hex(va), hex(ln)], capture_output=True, text=True)
    txt = o.stdout
    cache_dis[key] = txt
    return txt

def analyze_fn(va, maxlen=0x400):
    """Return (calls:set, touches_ptr_load:bool, touches_ptr_store:bool, has_getter_call:bool,
    has_setter:bool, touches_region:bool, has_callr:bool). Scan until we hit the next allocframe
    (heuristic function end) or maxlen."""
    txt = dis(va, maxlen)
    calls = set()
    touch_load = touch_store = has_getter = has_setter = touch_region = has_callr = False
    lines = txt.splitlines()
    started = False
    for i, ln in enumerate(lines):
        m = re.match(r'\s*([0-9a-f]+):', ln)
        if not m:
            continue
        addr = int(m.group(1), 16)
        # stop at a new allocframe after we've moved past the prologue (heuristic function boundary)
        if 'allocframe' in ln and addr != va and addr > va + 4:
            # a new allocframe far from start likely means next function; but only stop if it's
            # after a dealloc_return/jumpr pattern. Keep it simple: don't stop, rely on maxlen +
            # call boundary. We'll trust explicit call targets instead.
            pass
        # direct calls
        for c in re.findall(r'call (0x[0-9a-f]+)', ln):
            calls.add(int(c, 16))
        if 'callr' in ln:
            has_callr = True
        # detect immext + memw referencing the ptr, or immediate ##0xca79c494
        if 'ca79c494' in ln:
            if re.search(r'memw\(##0xca79c494\)\s*=', ln):
                touch_store = True
            elif re.search(r'=\s*memw\(##0xca79c494\)', ln):
                touch_load = True
            else:
                # immext or add; treat as reference
                touch_load = True
        if 'ca6e3228' in ln:
            touch_region = True
    if GETTER in calls:
        has_getter = True
    if SETTER in calls:
        has_setter = True
    return dict(calls=calls, touch_load=touch_load, touch_store=touch_store,
                has_getter=has_getter, has_setter=has_setter, touch_region=touch_region,
                has_callr=has_callr)

def bfs(root, maxdepth=8, fnlen=0x400):
    seen = set()
    frontier = {root}
    depth = 0
    hit_getter_fns = set()     # functions that call GETTER (deref of 0xca79c494)
    hit_load_fns = set()       # functions that load 0xca79c494 directly
    hit_store_fns = set()      # functions that store 0xca79c494
    hit_setter_fns = set()     # functions that call SETTER
    hit_region_fns = set()
    reached_setter = False
    reached_getter = False
    path_to = {root: None}
    while frontier and depth < maxdepth:
        nxt = set()
        for fn in frontier:
            if fn in seen:
                continue
            seen.add(fn)
            info = analyze_fn(fn, fnlen)
            if info['has_getter'] or fn == GETTER:
                hit_getter_fns.add(fn); reached_getter = True
            if info['touch_load']:
                hit_load_fns.add(fn); reached_getter = True
            if info['touch_store']:
                hit_store_fns.add(fn)
            if info['has_setter'] or fn == SETTER:
                hit_setter_fns.add(fn); reached_setter = True
            if info['touch_region']:
                hit_region_fns.add(fn)
            for c in info['calls']:
                if CODE_LO <= c < CODE_HI and c not in seen:
                    if c not in path_to:
                        path_to[c] = fn
                    nxt.add(c)
        frontier = nxt - seen
        depth += 1
    return dict(seen=seen, reached_getter=reached_getter, reached_setter=reached_setter,
                getter_fns=hit_getter_fns, load_fns=hit_load_fns, store_fns=hit_store_fns,
                setter_fns=hit_setter_fns, region_fns=hit_region_fns, path_to=path_to)

def trace_path(path_to, target):
    chain = []
    cur = target
    while cur is not None:
        chain.append(cur)
        cur = path_to.get(cur)
    return list(reversed(chain))

# The 24 handlers via stubs. From stub table, but stubs are trampolines: stub -> {callr r2} with
# r2 = ##<handler>. We already know handlers from prior report; but let's derive handler from each
# stub by reading the r2 = ##... in the stub (or the dispatcher default for slot0).
STUBS = [0xd8271630,0xd827176c,0xd8271548,0xd8271558,0xd8271568,0xd8271578,0xd827170c,0xd82715b0,
         0xd8271588,0xd8271598,0xd82715a4,0xd82715f8,0xd8271604,0xd8271610,0xd82715bc,0xd82715c8,
         0xd8271718,0xd8271724,0xd8271730,0xd82715d4,0xd82715e0,0xd82715ec,0xd827161c,0xd8271628]

def handler_from_stub(stub, slot):
    txt = dis(stub, 0x40)
    # find r2 = ##0x...   (handler preload)
    m = re.search(r'r2 = ##(0x[0-9a-f]+)', txt)
    if m:
        return int(m.group(1),16)
    # slot0 default preloaded in dispatcher; slot1/error stubs jump to error handler
    return None

HANDLERS = {}
for slot, stub in enumerate(STUBS):
    HANDLERS[slot] = handler_from_stub(stub, slot)

# Known overrides from prior FACT report (dispatcher preloads default for slot0)
KNOWN = {
 0:0xd86fcf84, 1:0xd827176c, 2:0xd86fd0f4, 3:0xd86fd230, 4:0xd86fd328, 5:0xd86fd474,
 6:0xd8271c94, 7:0xd86fdb88, 8:0xd86fd5c8, 9:0xd86fd80c, 10:0xd86fda68, 11:0xd86fe120,
 12:0xd86fe1e4, 13:0xd86fde80, 14:0xd86fe0a4, 15:0xd86fdf94, 16:0xd82722c4, 17:0xd8271b64,
 18:0xd8271bcc, 19:0xd8271774, 20:0xd86fe300, 21:0xd86fe558, 22:0xd86fe60c, 23:0xd86fe7e0,
}

if __name__ == '__main__':
    print("slot sub_cmd handler   stub_derived  reach_getter reach_setter  #fns")
    results = {}
    for slot in range(24):
        h = HANDLERS.get(slot)
        kh = KNOWN.get(slot)
        use = kh if kh else h
        sub = 0x1000 + slot
        if use is None:
            print(f"{slot:2d}  0x{sub:04x}  ????????   stub={h}  (no handler)")
            continue
        r = bfs(use, maxdepth=7, fnlen=0x400)
        results[slot] = (use, r)
        print(f"{slot:2d}  0x{sub:04x}  0x{use:08x} stub=0x{h:08x} " if h else f"{slot:2d}  0x{sub:04x}  0x{use:08x} stub=None      ",
              f"  getter={r['reached_getter']!s:5} setter={r['reached_setter']!s:5}  fns={len(r['seen'])}")
    import pickle
    pickle.dump({s:(u, {k:v for k,v in r.items() if k!='path_to'}) for s,(u,r) in results.items()},
                open('/tmp/modemre/bfs_results.pkl','wb'))
