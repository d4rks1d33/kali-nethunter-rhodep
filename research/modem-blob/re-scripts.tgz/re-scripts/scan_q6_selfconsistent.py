import sys, struct
sys.path.insert(0,'/tmp/q6zip')

# Search a raw blob for a self-consistent q6zip RX header at ANY 4-byte offset.
# Layout: [npages:u16][ver:u16][dict1: D1 words][dict2: D2 words][ptrs: npages words][data]
# Constraints for validity:
#  - npages in [500, 40000]
#  - dict combined size = 2^a + 2^b (two set bits), e.g. 0x400+0x4000=0x4400
#  - ptrs monotonic non-decreasing, values are VAddrs in a plausible range, and
#    ptrs[0] == elfbase + datastart (self consistent): ptrs increase by small deltas.

def find(fname, seg_vaddr):
    data=open(fname,'rb').read()
    n=len(data)//4
    words=struct.unpack('<%dL'%n, data, ) if False else None
    # read incrementally
    import array
    w=array.array('I')
    w.frombytes(data[:n*4])
    dictcombos=[]
    for a in range(8,16):
        for b in range(8,16):
            if a!=b:
                dictcombos.append((1<<a)+(1<<b))
    dictcombos=sorted(set(dictcombos))
    hits=[]
    for off in range(0, min(n, 0x400000)):  # scan first 4M words of positions
        npages = w[off] & 0xffff
        ver = (w[off]>>16)&0xffff
        if not (500 <= npages <= 40000):
            continue
        for dsz in dictcombos:
            # dict1[0] should be 0 (first dict word usually zero)
            base=off+1
            if base>=n: continue
            if w[base]!=0:  # dict1[0]==0 heuristic
                continue
            ptrstart=base+dsz
            if ptrstart+npages>=n: continue
            p0=w[ptrstart]
            # check monotonic for first 64 entries with small deltas
            ok=True
            prev=p0
            for k in range(1,64):
                cur=w[ptrstart+k]
                if not (prev<=cur and (cur-prev)<0x1000):
                    ok=False; break
                prev=cur
            if ok and p0>0x10000:
                hits.append((off, dsz, npages, ver, p0))
    return hits

for fn,va in [('/tmp/modemre2/modem.b26',0xcc000000)]:
    print('scanning',fn)
    h=find(fn,va)
    print('hits:',len(h))
    for off,dsz,npages,ver,p0 in h[:20]:
        print('  wordoff=%d fileoff=0x%x npages=%d ver=0x%04x dictsz=0x%x p0=%08x'%(off,off*4,npages,ver,dsz,p0))
