#!/usr/bin/env python3
import numpy as np, glob, os

# CLADE dict masks. dict_i words must all fit within mask_i.
# From cladetool.cpp: OR of all words == {0x3fffffff, 0x007fffff, 0x0001ffff}
MASKS = [0x3fffffff, 0x007fffff, 0x0001ffff]
DICTW = 0x2000 // 4  # words per dict

files = sorted(glob.glob('/tmp/clade/modem.b*'))
for f in files:
    raw = open(f, 'rb').read()
    nw = len(raw)//4
    if nw < 3*DICTW:
        continue
    a = np.frombuffer(raw[:nw*4], dtype='<u4')
    # For each candidate start (word aligned), we want:
    #   OR over a[s:s+DICTW]  == MASKS[0]
    #   OR over a[s+DICTW:s+2*DICTW] == MASKS[1]
    #   OR over a[s+2*DICTW:s+3*DICTW] == MASKS[2]
    # Compute rolling OR is hard; instead compute per-word "fits in mask" and
    # a coarse OR via a sliding window using bincount-like reductions.
    # Cheap proxy: a word belongs to dict_i only if (word & ~MASK_i)==0.
    # Find windows of DICTW where all words fit mask0, immediately followed by
    # DICTW fitting mask1, then DICTW fitting mask2.
    fit0 = (a & ~np.uint32(MASKS[0])) == 0
    fit1 = (a & ~np.uint32(MASKS[1])) == 0
    fit2 = (a & ~np.uint32(MASKS[2])) == 0
    # prefix sums of "fits" to test all-fit over windows quickly
    def allfit_windows(fit):
        # cumulative count of fits
        c = np.concatenate(([0], np.cumsum(fit.astype(np.int64))))
        # window [s, s+DICTW) all fit if c[s+DICTW]-c[s]==DICTW
        s = np.arange(0, len(fit)-DICTW+1)
        return (c[s+DICTW]-c[s]) == DICTW
    w0 = allfit_windows(fit0)
    w1 = allfit_windows(fit1)
    w2 = allfit_windows(fit2)
    # candidate start s: w0[s] and w1[s+DICTW] and w2[s+2*DICTW]
    maxs = len(a) - 3*DICTW
    s = np.arange(0, maxs+1)
    ok = w0[s] & w1[s+DICTW] & w2[s+2*DICTW]
    idx = np.nonzero(ok)[0]
    for si in idx:
        # verify exact OR
        o0 = int(np.bitwise_or.reduce(a[si:si+DICTW]))
        o1 = int(np.bitwise_or.reduce(a[si+DICTW:si+2*DICTW]))
        o2 = int(np.bitwise_or.reduce(a[si+2*DICTW:si+3*DICTW]))
        tag = "EXACT" if (o0==MASKS[0] and o1==MASKS[1] and o2==MASKS[2]) else "loose"
        print(f"{tag} {os.path.basename(f)} word_off {si} file_off 0x{si*4:x} ors={o0:08x},{o1:08x},{o2:08x}")
print("done")
