#!/usr/bin/env python3
# Packet-aware Hexagon disassembly: split the word stream into packets using
# parse bits [15:14] (0b11 or 0b00 => last word of packet), then emit each
# packet as a separate section so llvm-objdump groups correctly. This removes
# linear-sync artifacts and reveals whether the decompressed code is valid.
import sys, struct, subprocess

def parse_packets(words):
    packets=[]; cur=[]
    for w in words:
        cur.append(w)
        pb=(w>>14)&3
        if pb==3 or pb==0:   # end of packet
            packets.append(cur); cur=[]
        elif len(cur)>=4:
            packets.append(cur); cur=[]  # safety
    if cur: packets.append(cur)
    return packets

def disas(words, vaddr):
    data=struct.pack('<%dL'%len(words),*words)
    open('/tmp/pd.bin','wb').write(data)
    subprocess.run(['python3','/tmp/modemre/mkelf.py','/tmp/pd.bin',hex(vaddr),'/tmp/pd.elf'],stdout=subprocess.DEVNULL)
    r=subprocess.run(['llvm-objdump-18','--triple=hexagon','--mcpu=hexagonv66','-d','/tmp/pd.elf'],capture_output=True,text=True)
    return r.stdout

if __name__=='__main__':
    fn=sys.argv[1]; vaddr=int(sys.argv[2],0)
    d=open(fn,'rb').read()
    words=list(struct.unpack('<%dL'%(len(d)//4),d[:len(d)//4*4]))
    print(disas(words,vaddr))
