import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii')
    except:return None
# region before table start 0xc906c268: dump 0xc906c000 .. 0xc906c268
for va in range(0xc906bf00,0xc906c26c,4):
    v=u32(va); s=cstr(v) if is_valid_va(v) else None
    print("0x%08x: 0x%08x %s"%(va,v,"'"+s+"'" if s else ""))
