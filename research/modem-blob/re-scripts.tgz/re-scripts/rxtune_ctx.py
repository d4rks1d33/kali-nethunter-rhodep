import sys, struct
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, SEGS, va_to_off, off_to_va, u32, is_valid_va
def cstr(va, maxlen=60):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
# dump the RX_TUNE_CMD string cluster (these are an enum of RFLM cmd names)
print("=== RFLM command name cluster around 0xc3797900 ===")
o=va_to_off(0xc3797940)
d=FULL[o:o+400]
# print as null-sep strings
s=d.split(b'\x00')
va=0xc3797940
for tok in s[:40]:
    if tok:
        pva=off_to_va(FULL.find(tok, va_to_off(0xc3797940)))
    print("  %r"%tok.decode('ascii','replace'))
print("\n=== find ptr array to RX_TUNE_CMD (0xc379794c) => the RFLM cmd id table ===")
for i,off,va,pa,fsz,msz,fl in SEGS:
    if not fsz: continue
    data=FULL[off:off+fsz]
    p=0
    while True:
        p=data.find(struct.pack('<I',0xc379794c),p)
        if p<0: break
        print("  ptr@0x%08x (seg%d)"%(va+p,i))
        p+=4
