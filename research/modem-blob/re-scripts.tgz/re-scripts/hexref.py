"""Find code references to a 32-bit constant (vaddr) in Hexagon code segments.
Hexagon loads 32-bit immediates via immext(##) + a base instr. The full 32-bit
value appears split: low bits in the instruction, high bits in the immext.
Simplest robust approach: disassemble code segs once, then grep for the hex value
in the rendered ## immediates. We'll use llvm-objdump per segment with vaddr mapping."""
import sys, subprocess, os
sys.path.insert(0,'/tmp/modemre')
from vmap import SEGS, FULL

CODE_SEGS=[10,13,12,2,30,8,9,4,5]  # executable, prioritize main code b10,b13

def dis_segment(segidx, out):
    i,off,vaddr,pa,fsz,msz,fl=[s for s in SEGS if s[0]==segidx][0]
    raw=FULL[off:off+fsz]
    tmp='/tmp/modemre/_seg%d.bin'%segidx
    open(tmp,'wb').write(raw)
    # llvm-objdump raw binary disassemble with hexagon, set start address
    cmd=['llvm-objdump-18','-D','--triple=hexagon','-b','binary','-m','hexagon',
         '--adjust-vma=0x%x'%vaddr, tmp]
    r=subprocess.run(cmd,capture_output=True,text=True)
    open(out,'w').write(r.stdout)
    return out

if __name__=='__main__':
    seg=int(sys.argv[1])
    out=sys.argv[2] if len(sys.argv)>2 else '/tmp/modemre/_dis_seg%d.txt'%seg
    dis_segment(seg,out)
    print("wrote",out, os.path.getsize(out),"bytes")
