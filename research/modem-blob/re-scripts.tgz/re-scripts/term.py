def is_term(ww):
    if ww in (0x529fc000,0x529f4000): return True          # jumpr r31
    lo=ww&0xffff
    if lo==0xc01e and (ww>>24) in (0x96,0x90): return True # standalone dealloc_return/deallocframe
    # dealloc_return duplex: low subinsn encodes SA1 dealloc_return; observed suffixes 1f40/1f00/3f40/3fc0
    suf=ww&0x0000ffc0
    if suf in (0x1f40,0x1f00,0x3f40,0x3fc0): 
        # guard: high bits look like duplex/jump class (0x3e.., 0x48.., 0x16.., 0x1c.., 0x2*, 0x29..)
        return True
    return False
