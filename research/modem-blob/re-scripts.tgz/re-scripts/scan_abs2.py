#!/usr/bin/env python3
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack('<I',data[i:i+4])[0] for i in range(0,N-3,4)]

IMMEXT=0x0cbf53dd
immext_idx=[i for i,w in enumerate(words) if w==IMMEXT]

# For each immext(0xcbf4f740), decode the paired + following few for ANY store touching gate.
# absolute memb store memb(##)=Rt : 0x4800c0?? (reg). conditional 0xaf... memh 0x48A0.., memw 0x4880..
# We saw d81bd7c8: memb(r2+#0)=#0 after r2=##0xcbf4f740 (28022800).
# Let's just dump each immext site's next 6 words disasm to inspect the ones we haven't.
import subprocess,sys
sys.path.insert(0,'/tmp/modemre')
from mkelf import make_elf
def dis(va,n=7):
    off=va-BASE
    make_elf(data[off:off+n*4],va,'/tmp/_a.elf')
    out=subprocess.check_output(['llvm-objdump-18','-d','--triple=hexagon','--mcpu=hexagonv66','/tmp/_a.elf']).decode()
    return "\n".join(out.splitlines()[7:])

# focus: sites where a #2 or combine with 2 appears
for i in immext_idx:
    va=BASE+i*4
    ctx=words[i:i+6]
    # look for a '2' loaded (r=#2 -> 78004?42 pattern? or mux with 2)
    d=dis(va,6)
    if ' = #0x2' in d or '#0x2,' in d or ',#0x2' in d or 'combine(#0,#0x2' in d or '#0x2 ;' in d:
        print("==== %08x (has #2) ===="%va)
        print(d); print()
