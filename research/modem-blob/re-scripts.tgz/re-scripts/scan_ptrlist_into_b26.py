#!/usr/bin/env python3
# Scan whole ELF for a long monotonic-increasing list of 32-bit values that
# fall within the b26 vaddr range 0xcc000000..0xce480000 (the compressed data).
# That list is the q6zip page pointer table.
import struct, json
d=open('/tmp/modemre/modem_full.elf','rb').read()
phs=json.load(open('/tmp/modemre/phs.json'))
def f2v(fo):
    for off,va,fsz,msz,fl in phs:
        if off<=fo<off+fsz: return va+(fo-off)
    return None
LO=0xcc000000; HI=0xce480000
n=len(d)//4
# iterate over word-aligned regions
import array
w=array.array('I')
w.frombytes(d[:n*4])
i=0
runs=[]
while i<n-1:
    if LO<=w[i]<HI:
        j=i
        while j+1<n and LO<=w[j+1]<HI and w[j+1]>=w[j]:
            j+=1
        if j-i>200:
            runs.append((i,j-i))
        i=j+1
    else:
        i+=1
runs.sort(key=lambda x:-x[1])
for idx,L in runs[:15]:
    fo=idx*4
    print(f"run len={L} fileofs={fo:08x} vaddr={f2v(fo):08x}  first={w[idx]:08x} last={w[idx+L-1]:08x}")
