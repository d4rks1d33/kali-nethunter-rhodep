#!/usr/bin/env python3
# Definitive q6zip header search: find P where
#   npages=word[P]&0xffff in [500,20000], ver=(word[P]>>16) small,
#   word[P+1]==0 (dict1[0]),
#   and for SOME dictsize D in {0x4400,0x8400,0x4100,...}:
#     ptrs start at P+1+D, and ptrs[0] == vaddr(P+1+D+npages)  (self-consistent, points right after ptrlist)
import struct,json,array
d=open('/tmp/modemre/modem_full.elf','rb').read()
phs=json.load(open('/tmp/modemre/phs.json'))
def f2v(fo):
    for off,va,fsz,msz,fl in phs:
        if off<=fo<off+fsz: return va+(fo-off)
    return None
n=len(d)//4
w=array.array('I'); w.frombytes(d[:n*4])
dictsizes=[0x400+0x4000,0x400+0x8000,0x800+0x4000,0x100+0x4000,0x200+0x4000,
           0x400+0x2000,0x800+0x8000,0x1000+0x4000,0x400+0x1000]
hits=[]
for i in range(n-4):
    npages=w[i]&0xffff
    ver=(w[i]>>16)&0xffff
    if not (500<=npages<=20000): continue
    if ver>0x30: continue
    if w[i+1]!=0: continue
    for D in dictsizes:
        pl=i+1+D
        if pl+npages>=n: continue
        ptr0=w[pl]
        # datastart offset in bytes from segment... tool: elfbase=ptrs[0]-datastart
        # self-consistency: ptr0 should be a vaddr slightly above the header vaddr
        hva=f2v(i*4)
        if hva is None: continue
        # expected first-chunk vaddr = hva + (1+D+npages)*4  (approx, if ptrs are vaddrs)
        exp=hva+(1+D+npages)*4
        if abs(ptr0-exp)<0x40:
            hits.append((f2v(i*4),npages,ver,D,ptr0,exp))
for h in hits[:30]:
    print('hdr@%08x npages=%d ver=%d dict=%#x ptr0=%08x exp=%08x'%h)
print('total',len(hits))
