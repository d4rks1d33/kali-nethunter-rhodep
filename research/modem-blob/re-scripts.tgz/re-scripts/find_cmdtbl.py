import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, SEGS, va_to_off, u32, is_valid_va, seg_of
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
# module string VAs of interest (the second cluster used by code = 0xc37c0xxx)
targets={
0xc37c0359:'radio_config',0xc37c040b:'command_capability',0xc37c05c7:'rx_measure',
0xc37c06a2:'wait_trigger',0xc37c0771:'msim_config',0xc37c080f:'tx_control',
0xc37c0930:'iq_capture',0xc37c0dfb:'tx_measure',0xc3569621:'control',
0xc3569637:'radio_config1',0xc3569652:'rx_measure1',0xc356966b:'wait_trigger1',
0xc3569686:'iq_capture1',0xc356969f:'tx_measure1',0xc356a44e:'multi_tech_rf_test'}
tset=set(targets)
for i,off,vaddr,pa,fsz,msz,fl in SEGS:
    if not fsz: continue
    data=FULL[off:off+fsz]
    for p in range(0,len(data)-4,4):
        v=struct.unpack('<I',data[p:p+4])[0]
        if v in tset:
            va=vaddr+p
            print("ptr@0x%08x (seg%d) -> %s (0x%08x)"%(va,i,targets[v],v))
