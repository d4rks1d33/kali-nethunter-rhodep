import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]
    n=d.find(b'\x00')
    if n<0: n=maxlen
    try: return d[:n].decode('ascii')
    except: return repr(d[:n])
for va in [0xc37be79d,0xc37be7a8,0xc37be7b3,0xc37befa4,0xc37befad,0xc37befba,0xc37befc7,0xc37befd6,0xc37befda,0xc37befdf,0xc37befeb,0xc37beff5,0xc37befff,0xc391dc40,0xc391dc7d,0xc3929868,0xc37be7be,0xc37be7e4,0xc37be7a8]:
    print("0x%08x: '%s'"%(va,cstr(va)))
