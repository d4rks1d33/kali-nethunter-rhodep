#!/usr/bin/env python3
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)

# immext for 0xca733d00 : from disasm 'f4 4c a7 0c' little-endian => 0x0ca74cf4
# immext encodes bits[31:14] of the constant. 0xca733d00>>6 = 0x32a8f4c... let's just match observed word.
# The observed immext word for immext(#0xca733d40) in the file was 0f804cf5? no that's f8033d40.
# For ca733d00 the immext word is 0x0ca74cf4 (bytes f4 4c a7 0c).
IMMEXT_CA733 = 0x0ca74cf4

def op_top(w): return (w>>24)&0xff

# Find every site using this immext, decode paired + next words
sites=[]
for i in range(0,N-3,4):
    w=struct.unpack('<I',data[i:i+4])[0]
    if w==IMMEXT_CA733:
        va=BASE+i
        nxts=[struct.unpack('<I',data[i+4*(k+1):i+4*(k+1)+4])[0] for k in range(3) if i+4*(k+1)+4<=N]
        sites.append((va,nxts))

print("Total immext(#0xca733d00) sites:", len(sites))
print("="*70)
# Classify. Store families in Hexagon:
#  0x48 : S2_storeXX_io absolute? Actually memX(##U)=Rt uses different top.
#  Store to reg+imm computed: S4_storeri_ur (memw(Rs+Rt<<#u)=Rt) etc.
#  Key store opcode groups (top nibble 0xa = store class NV/reg? ) Let me just print raw + heuristic.
STORE_TOPS={0x48:'st_abs',0xaf:'st_abs_cond',0x3c:'st_imm',0xa1:'st_io',0xa9:'st_io_new',0xab:'st_reg',0x9d:'ld_reg_asl',0x9e:'ld',0x99:'ld'}
for va,nxts in sites:
    line=f"{va:08x}: immext"
    for k,w in enumerate(nxts):
        t=op_top(w)
        tag=STORE_TOPS.get(t,'')
        line+=f"  +{4*(k+1)}={w:08x}({t:02x}{('/'+tag) if tag else ''})"
    print(line)
