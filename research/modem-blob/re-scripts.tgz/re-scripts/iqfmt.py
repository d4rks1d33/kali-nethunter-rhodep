import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va
def cstr(va, maxlen=120):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
for va in [0xc37c08f4,0xc37c0949,0xc37c098e,0xc37c09c4]:
    print("0x%08x: %r"%(va,cstr(va)))
