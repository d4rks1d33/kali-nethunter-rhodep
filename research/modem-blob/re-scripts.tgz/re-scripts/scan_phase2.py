#!/usr/bin/env python3
# Robust: find any immext whose value lands anywhere in 0xcb8dbe80..0xcb8dbf00,
# then decode the paired instruction to compute the ACTUAL effective address and
# whether it is a store. Handle A2_tfrsi(r=##), abs store/load, [Rs+#u] forms.
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack_from('<I',data,i)[0] for i in range(0,N-3,4)]
NW=len(words)

def immext_val(w):
    if (w>>28)!=0: return None
    return (((((w>>16)&0xFFF)<<14)|(w&0x3FFF))<<6) & 0xffffffff

LO=0xcb8dbe80; HI=0xcb8dbf40

# absolute store family: opcode bits [31:24]=0x48 -> S2_storerX_io absolute (memX(##U)=Rt)
#   the low 6 bits of the address are in field bits, combined with immext.
# We'll flag any paired insn with top in store set, but focus on ABS forms 0x48 (store) 
# vs 0x49 (load). Distinguish store vs load: bit 21? Actually 0x48=store,0x49=load in this class.
# store-imm to [Rs+#u]: class 0x3c (memX(Rs+#u)=#S) 
# reg store [Rs+#s]: 0xa1 (memX(Rs+#)=Rt), 0xa0 store-imm

def top(w): return (w>>24)&0xff

results=[]
for i,w in enumerate(words):
    v=immext_val(w)
    if v is None: continue
    if not (LO<=v<=HI): continue
    va=BASE+i*4
    n1=words[i+1] if i+1<NW else 0
    t1=top(n1)
    # classify
    is_store=False; kind=''
    if t1==0x48:  # abs store family memX(##)=Rt  (could also be some loads under 0x49)
        is_store=True; kind='ABS-store memX(##)=Rt'
    elif t1==0xaf:
        is_store=True; kind='ABS-cond-store'
    elif t1==0x3c or t1==0x3d or t1==0x3e:
        is_store=True; kind='store-imm memX(Rs+#u)=#S'
    elif t1==0xa1:
        is_store=True; kind='store memX(Rs+#s)=Rt'
    elif t1==0xa0:
        is_store=True; kind='store-imm memX(Rs+#u)=#S(a0)'
    elif t1==0x78:
        kind='r=##imm (tfrsi/transfer)'  # ptr load into reg
    elif t1==0x2b:
        kind='r=##imm; r?=#imm (A2_combine/immediate)'
    elif t1==0x49:
        kind='ABS-load memX(##)=... (load)'
    elif t1==0x91 or t1==0x92:
        kind='load memX(Rs+#)'
    else:
        kind='top=%02x'%t1
    results.append((va,v,n1,is_store,kind))

print("=== all immext into 0xcb8dbe80..0xcb8dbf40, with STORES flagged ===")
for va,v,n1,is_store,kind in results:
    mark=' <<<< STORE' if is_store else ''
    print("%08x immext=%08x | +4:%08x  %s%s"%(va,v,n1,kind,mark))
print("\ntotal=%d  stores=%d"%(len(results),sum(1 for r in results if r[3])))
