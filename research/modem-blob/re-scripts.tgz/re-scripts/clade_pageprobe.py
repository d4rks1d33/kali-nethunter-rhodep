#!/usr/bin/env python3
# Instrument the CLADE decompressor to report, for a given start comp-offset,
# how many INPUT bits/words are consumed to produce exactly 1024 output words
# (one 4KB decompressed page). This tells us the compressed size of page 0,
# and lets us test if page boundaries are word-aligned.
import sys, struct
sys.path.insert(0,'/tmp/q6zip')
from unclade import BitStreamReader, CladeDecompressor, decodewords

raw=open('/tmp/clade/modem.b26','rb').read()
DICTBASE=0x2444000
dicts=[list(decodewords(raw[DICTBASE+i*0x2000:DICTBASE+(i+1)*0x2000])) for i in range(3)]

def decode_n_words(comp_bytes, nwords, skipfirst=True):
    words=list(decodewords(comp_bytes))
    bits=BitStreamReader(words)
    C=CladeDecompressor(dicts)
    out=[]
    if skipfirst:
        bits.get(1)
    while len(out)<nwords:
        code=bits.get(2)
        if code<3:
            idx=bits.get(11)
            missing=bits.get(len(C.missingbits[code]))
            dictword=dicts[code][idx]
            result=C.reconstructword(dictword,C.missingbits[code],missing)
        else:
            result=bits.get(32)
        out.append(result)
    # bits consumed: pos words fully + partial
    consumed_bits = bits.pos*32 + bits.bitpos
    return out, consumed_bits

comp=raw[0:0x20000]
for npg in [1,2,3]:
    out,cb=decode_n_words(comp, 1024*npg)
    print(f"{npg} page(s): {1024*npg} words out, consumed {cb} bits = {cb/8:.1f} bytes = {cb//32} input words, bit%32={cb%32}")
