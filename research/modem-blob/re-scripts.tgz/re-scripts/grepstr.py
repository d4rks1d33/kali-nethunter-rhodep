import sys, re
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, off_to_va
pats=sys.argv[1:]
rx=re.compile(b'[ -~]{4,}')
for m in rx.finditer(FULL):
    s=m.group()
    for p in pats:
        if p.encode() in s:
            va=off_to_va(m.start())
            print("0x%s | %s"%(("%08x"%va) if va else "????????", s.decode('ascii','replace')))
            break
