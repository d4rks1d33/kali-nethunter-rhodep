#!/usr/bin/env python3
# Scan 36MB image for references to 0xcbf4f740 (the RF-cal gate).
# Approach 1: immext encoding of upper bits. Hexagon A2/immext puts const[31:6] into
#   the 26-bit field of a 0x0000???? word. We'll compute the exact immext word for
#   the aligned upper constant, then look for nearby memb/memw stores.
# Approach 2: gp-relative store. gp = 0xcbf4f000, offset 0x740. memb(gp+#0x740)=Rt.
import struct, sys

BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)

def immext_word(const):
    # immext carries const[31:6]; encoding: 0x00000000 | (imm26 layout)
    # Hexagon immext (A2_immext) 32-bit: 0 0 0 0  b b b b b b b b  b b b b  b b b b b b b b b b b b b b
    # Actually format: 1000 (?) - let's derive from a known-good sample instead.
    return None

# Derive immext encoding from a known packet we already saw:
# d82712d8: 0d 66 80 0f  immext(#0xf8098340)
# word little-endian 0x0f80660d, const=0xf8098340
# Let's reverse: we want a function const->word.
sample_word=0x0f80660d
sample_const=0xf8098340
# immext field = const>>6
sf = sample_const>>6   # 0x3e02618d0? compute
# The immext instruction opcode top bits are '0000' per LLVM (I_class=0). Layout:
#  bits[31:28]=0b0000 ; imm[31:14] in bits [27:16]??? Let's brute force the bit mapping
# We'll brute: find permutation such that packing sample_const gives sample_word.
# Known: A2_immext encoding (from Hexagon V6X manual):
#   0 0 0 0 [imm 26 bits placed as: imm[25:20] in [21:16]? ] -- messy.
# Simplest robust approach: for each candidate 4-byte word in file that is an immext
# (top nibble 0x0 in the raw 0x0??????? sense is NOT reliable). Instead decode via llvm.
# So: brute force by generating immext for our const using llvm-mc is overkill.
# Instead: reverse-engineer mapping from the sample.

def bits(x,n): return [(x>>i)&1 for i in range(n)]

# The immext imm is 26 bits (const>>6). In the 32-bit word, opcode is fixed and 26 bits are imm.
# Fixed bits (opcode) = word with imm zeroed. imm bits scattered. We can find the scatter by
# comparing two samples. Grab a second known immext:
# d82712c0: 13 40 00 00 immext(#0x4c0) -> word 0x00004013, const 0x4c0
s2_word=0x00004013
s2_const=0x4c0
# imm1 = sample_const>>6, imm2 = s2_const>>6
imm1=sample_const>>6
imm2=s2_const>>6
# XOR of words tells which bits changed; XOR of imm tells which imm-bits changed.
wx = sample_word ^ s2_word
ix = imm1 ^ imm2
print("word xor=%08x imm xor=%07x"%(wx,ix))
# Build mapping bit-position-in-word -> bit-position-in-imm by using more samples.
