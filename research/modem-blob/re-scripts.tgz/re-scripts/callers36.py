#!/usr/bin/env python3
# Find call/jump refs to a target VA scanning the FULL 36MB decompressed image.
import struct, sys
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
def val_imm(w):
    b_hi=(w>>16)&0x1ff; b_lo=(w>>1)&0x1fff
    imm=(b_hi<<13)|b_lo
    if imm&(1<<21): imm-=(1<<22)
    return imm<<2
tgt=int(sys.argv[1],0)
calls=[]; jumps=[]
for off in range(0,len(data)-4,4):
    w=struct.unpack('<I',data[off:off+4])[0]
    op7=(w>>25)&0x7f
    va=BASE+off
    if op7==0b0101101:
        if va+val_imm(w)==tgt: calls.append(va)
    elif op7==0b0101100:
        if va+val_imm(w)==tgt: jumps.append(va)
print("TARGET",hex(tgt))
print("CALLS:",[hex(x) for x in calls])
print("JUMPS:",[hex(x) for x in jumps])
