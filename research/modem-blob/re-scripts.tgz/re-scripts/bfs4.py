#!/usr/bin/env python3
# Bounded, blacklisted forward reachability. Reports whether root reaches GETTER (deref of
# 0xca79c494), SETTER (store), the per-carrier region 0xca6e3228, or the named exec funcs.
import subprocess, re, sys
DIS='/tmp/modemre/dis.sh'
LO,HI=0xd8000000,0xd8a00000
SETTER=0xd8279264; GETTER=0xd827923c; APPLY=0xd8273b2c
EXECS={0xd826d7b0,0xd826d9b4,0xd826d3e4,0xd826d67c,0xd826db54,0xd826e090,0xd8272cd8}

# Broad blacklist of shared/hub helpers that explode the graph and are NOT command logic.
BLACK={
 0xd814e6ac,0xd8829a00,0xd8829688,0xd8829698,
 0xd80d77a8,0xd80d8998,0xd80d8988,0xd80d8990,0xd8041828,
 0xd814d768,0xd8049f24,   # memcpy/mem helpers reached via guard
 0xd805eef0,0xd8057dd0,   # generic
 0xc0913a54,0xc0913ad8,
}

fn_cache={}
def fn_body(va, cap=0x400):
    if va in fn_cache: return fn_cache[va]
    o=subprocess.run([DIS,hex(va),hex(cap)],capture_output=True,text=True).stdout
    out=[]; ended=False
    for ln in o.splitlines():
        m=re.match(r'\s*([0-9a-f]+):',ln)
        if not m: out.append((None,ln)); continue
        addr=int(m.group(1),16); out.append((addr,ln))
        if 'dealloc_return' in ln or re.search(r'jumpr r31',ln): ended=True
        if ended and '}' in ln: break
    fn_cache[va]=out; return out
def callees(va):
    cs=set(); has_callr=False; imms=set()
    for addr,ln in fn_body(va):
        for c in re.findall(r'call (0x[0-9a-f]+)',ln): cs.add(int(c,16))
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            jv=int(j,16)
            if LO<=jv<HI and (jv<va-0x40 or jv>va+0x400): cs.add(jv)
        if 'callr' in ln: has_callr=True
        # capture 32-bit immediates loaded into registers (potential callr targets)
        for hx in re.findall(r'= ##(-?0x[0-9a-f]+)', ln):
            v=int(hx,16)
            if v<0: v&=0xffffffff
            if LO<=v<HI: imms.add(v)
    # if this fn does an indirect call, its register immediates are candidate targets
    if has_callr:
        cs|=imms
    return cs
def touches(va):
    ld=st=reg=False
    for addr,ln in fn_body(va):
        if 'ca79c494' in ln:
            if re.search(r'memw\(##0xca79c494\)\s*=',ln): st=True
            elif 'memw(##0xca79c494)' in ln: ld=True
        if 'ca6e3228' in ln: reg=True
    return ld,st,reg
def bfs(root, maxd=5, cap=1200):
    seen=set(); fr={root}; d=0; path={root:None}; hit={}
    while fr and d<maxd and len(seen)<cap:
        nx=set()
        for x in fr:
            if x in seen or len(seen)>=cap: continue
            seen.add(x)
            cs=callees(x)
            for t in list(EXECS)+[SETTER,GETTER,APPLY]:
                if t in cs and t not in hit: hit[t]=x
            ld,st,reg=touches(x)
            if ld: hit.setdefault('LOAD_'+hex(x),x)
            if st: hit.setdefault('STORE_'+hex(x),x)
            if reg: hit.setdefault('REGION_'+hex(x),x)
            for c in cs:
                if c in BLACK: continue
                if LO<=c<HI and c not in seen: path.setdefault(c,x); nx.add(c)
        fr=nx-seen; d+=1
    return seen,hit,path
def ch(path,n):
    c=[]
    while n is not None: c.append(n); n=path.get(n)
    return list(reversed(c))
if __name__=='__main__':
    root=int(sys.argv[1],0)
    md=int(sys.argv[2]) if len(sys.argv)>2 else 5
    seen,hit,path=bfs(root,maxd=md)
    getter=(GETTER in hit) or any(k.startswith('LOAD') for k in hit if isinstance(k,str))
    setter=(SETTER in hit) or any(k.startswith('STORE') for k in hit if isinstance(k,str))
    exec=any(e in hit for e in EXECS)
    region=any(isinstance(k,str) and k.startswith('REGION') for k in hit)
    print(f"root={hex(root)} scanned={len(seen)} depth<={md}")
    print(f"  reaches GETTER(deref 0xca79c494)={getter}  SETTER(store)={setter}  exec={exec}  region0xca6e3228={region}")
    for t in [SETTER,GETTER,APPLY]+sorted(EXECS):
        if t in hit:
            c=ch(path,hit[t])+[t]
            print(f"    -> {hex(t)}: {' -> '.join(hex(z) for z in c)}")
