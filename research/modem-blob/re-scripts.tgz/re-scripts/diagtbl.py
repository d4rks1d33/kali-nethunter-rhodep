import sys, struct
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, u16, is_valid_va, seg_of
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
def dump(tbl,count,name):
    print("\n=== %s @ 0x%08x count=%d ==="%(name,tbl,count))
    for i in range(count):
        va=tbl+12*i
        lo=u16(va);hi=u16(va+2);h=u32(va+4)
        extra=u32(va+8)
        print("[%2d] cmd=[0x%04x..0x%04x] handler=0x%08x extra=0x%08x %s"%(i,lo,hi,h,extra, "seg%s"%seg_of(h) if is_valid_va(h) else "(runtime)"))
dump(0xc379d848,18,"FTM_0x0B tbl_A")
dump(0xc379ee88,25,"FTM_0x0B tbl_B")
