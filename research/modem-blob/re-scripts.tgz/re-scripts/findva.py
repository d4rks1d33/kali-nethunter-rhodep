import sys, re
# Find code refs to a target vaddr in a disassembly dump.
# Hexagon: immext(#HI) where HI = target & 0xffffffc0 (top 26 bits <<6), 
# then next instr adds low 6 bits. We search for immext with HI matching, 
# and also direct ##0x... full-value memw/combine.
def find(dump, target):
    hi = target & 0xffffffc0
    results=[]
    lines=dump.splitlines()
    # direct full-value forms: ##0xTARGET
    tgt_s = "0x%x"%target
    for idx,l in enumerate(lines):
        if ("##%s"%tgt_s in l.replace("0X","0x")) or ("#%s"%tgt_s in l and 'immext' not in l):
            results.append((idx,l,'direct'))
    # immext + low
    hi_s="0x%x"%hi
    for idx,l in enumerate(lines):
        if 'immext(#%s)'%hi_s in l:
            # look at next 1-2 lines for low add
            ctx=lines[idx:idx+3]
            results.append((idx,l,'immext_hi'))
    return results

if __name__=='__main__':
    dumpfile=sys.argv[1]; target=int(sys.argv[2],16)
    dump=open(dumpfile).read()
    res=find(dump,target)
    print("target 0x%x hi=0x%x : %d hits"%(target,target&0xffffffc0,len(res)))
    lines=dump.splitlines()
    for idx,l,kind in res[:40]:
        # print addr context
        print("--- %s @ line %d"%(kind,idx))
        for j in range(max(0,idx-1),min(len(lines),idx+3)):
            print("   ",lines[j])
