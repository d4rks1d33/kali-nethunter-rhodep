#!/usr/bin/env python3
# Forward BFS from a root; report if it reaches the SETTER (0xd8279264), the GETTER (0xd827923c),
# or the carrier-apply fn (0xd8273b2c). Uses correct call/jump decode.
import subprocess, re, sys
DIS='/tmp/modemre/dis.sh'
LO,HI=0xd8000000,0xd8a00000
SETTER=0xd8279264; GETTER=0xd827923c; APPLY=0xd8273b2c
cache={}
def calls_of(va, ln=0x500):
    if va in cache: return cache[va]
    o=subprocess.run([DIS,hex(va),hex(ln)],capture_output=True,text=True).stdout
    cs=set(int(x,16) for x in re.findall(r'call (0x[0-9a-f]+)',o))
    js=set(int(x,16) for x in re.findall(r'jump (0x[0-9a-f]+)',o))
    # only include jumps that look like tail calls (to a function prologue far away) - keep in-range
    cache[va]=(cs,js,o)
    return cache[va]
def bfs(root, targets, maxd=8, ln=0x400):
    seen=set(); fr={root}; d=0; hit={}
    path={root:None}
    while fr and d<maxd:
        nx=set()
        for x in fr:
            if x in seen: continue
            seen.add(x)
            cs,js,o=calls_of(x,ln)
            for t in targets:
                if t in cs:
                    hit.setdefault(t,(x,path.get(x)))
            for c in cs:
                if LO<=c<HI and c not in seen:
                    path.setdefault(c,x); nx.add(c)
        fr=nx-seen; d+=1
    return seen,hit,path
if __name__=='__main__':
    root=int(sys.argv[1],0)
    ln=int(sys.argv[2],0) if len(sys.argv)>2 else 0x400
    seen,hit,path=bfs(root,{SETTER,GETTER,APPLY},maxd=8,ln=ln)
    print(f"root={hex(root)} scanned={len(seen)}")
    for t,name in [(SETTER,'SETTER 0xd8279264'),(GETTER,'GETTER 0xd827923c'),(APPLY,'APPLY 0xd8273b2c')]:
        if t in hit:
            caller=hit[t][0]
            # reconstruct path
            chain=[]; cur=caller
            while cur is not None: chain.append(cur); cur=path.get(cur)
            chain=list(reversed(chain))+[t]
            print(f"  REACHES {name}: via {' -> '.join(hex(c) for c in chain)}")
        else:
            print(f"  does NOT reach {name}")
