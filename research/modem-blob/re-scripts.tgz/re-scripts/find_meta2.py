#!/usr/bin/env python3
# Look for the CLADE metadata: an array where consecutive entries increase by
# a "compressed page size" (hundreds to few thousand bytes), spanning 0..0x2444000.
# Real per-page offset tables have deltas typically 0x100..0x2000 (a 4KB page
# compresses to <=4KB). Search across all files for the LONGEST such run.
import numpy as np, glob, os

MAXV = 0x2450000
files = sorted(glob.glob('/tmp/clade/modem.b*'))
results=[]
for f in files:
    raw=open(f,'rb').read()
    a=np.frombuffer(raw[:len(raw)//4*4],dtype='<u4').astype(np.int64)
    n=len(a)
    if n<300: continue
    i=0
    while i<n-1:
        if a[i] > MAXV or a[i] < 0:
            i+=1; continue
        j=i+1
        while j<n:
            d=a[j]-a[j-1]
            if a[j]>MAXV or d<=0 or d>0x4000:
                break
            j+=1
        L=j-i
        if L>=500:
            results.append((L,os.path.basename(f),i*4,int(a[i]),int(a[j-1]),(int(a[j-1])-int(a[i]))//max(1,L)))
        i=j
results.sort(reverse=True)
for L,fn,fo,v0,vN,avgd in results[:25]:
    print(f"{fn} foff 0x{fo:x} len {L} first={v0:x} last={vN:x} avgdelta={avgd}")
print("runs:",len(results))
