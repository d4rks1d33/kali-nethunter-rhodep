#!/usr/bin/env python3
import struct, sys

# program headers from findings/00_program_headers.txt
# idx b_file vaddr paddr filesz memsz flags
PH = [
 (0,"modem.b00",0x00000000,0x00000000,0x000004b4,0x00000000,"---"),
 (1,"modem.b01",0x9b800000,0x9b800000,0x00002068,0x00003000,"---"),
 (2,"modem.b02",0xc0800000,0x8b800000,0x00002930,0x00003000,"R-E"),
 (3,"modem.b03",0xa44f9000,0x8b803000,0x00002460,0x00002460,"R--"),
 (4,"modem.b04",0xc0900000,0x8b900000,0x0003bd40,0x0003c000,"RWE"),
 (5,"modem.b05",0xc0980000,0x8b980000,0x0002c190,0x0002d000,"RWE"),
 (6,"modem.b06",0xc09ad000,0x8b9ad000,0x0003e4a0,0x0003f000,"RW-"),
 (7,"modem.b07",0xc09ec000,0x8b9ec000,0x0000e3b0,0x0000f000,"R--"),
 (8,"modem.b08",0xc09fb000,0x8b9fb000,0x0002380c,0x00024000,"RWE"),
 (9,"modem.b09",0xc0a1f000,0x8ba1f000,0x00060064,0x00061000,"RWE"),
 (10,"modem.b10",0xc0a80000,0x8ba80000,0x0029ab14,0x0029b000,"R-E"),
 (11,"modem.b11",0xc0d20000,0x8bd20000,0x00009140,0x0000a000,"R--"),
 (12,"modem.b12",0xc0d30000,0x8bd30000,0x00006000,0x00006000,"R-E"),
 (13,"modem.b13",0xc0d36000,0x8bd36000,0x0031f1b0,0x00320000,"R-E"),
 (14,"modem.b14",0xc1080000,0x8c080000,0x00040000,0x00040000,"RW-"),
 (15,"modem.b15",0xc10c0000,0x8c0c0000,0x0039c000,0x0039c000,"RW-"),
 (17,"modem.b17",0xc145d000,0x8c45d000,0x0023aeb8,0x0023b000,"RW-"),
 (18,"modem.b18",0xc16c0000,0x8c6c0000,0x000a9cb0,0x000aa000,"RW-"),
 (19,"modem.b19",0xc1780000,0x8c780000,0x002d0000,0x002d0000,"RW-"),
 (20,"modem.b20",0xc1a50000,0x8ca50000,0x0096e988,0x01b03000,"RW-"),
 (21,"modem.b21",0xc3553000,0x8e553000,0x00d315f4,0x05616000,"R--"),
 (22,"modem.b22",0xa1073000,0x93b69000,0x0000002d,0x0000002d,"R--"),
 (23,"modem.b23",0xc8b6a000,0x93b6a000,0x005cdd97,0x005ce000,"RW-"),
 (25,"modem.b25",0xcbf4f000,0x96f4f000,0x00019900,0x0001a000,"RW-"),
 (26,"modem.b26",0xcc000000,0x97000000,0x0244a040,0x0244b000,"RW-"),
 (27,"modem.b27",0xce480000,0x99480000,0x0011922f,0x0011a000,"R--"),
 (28,"modem.b28",0xce59a000,0x9959a000,0x00016000,0x00016000,"RW-"),
 (29,"modem.b29",0xce5b1000,0x995b1000,0x00001064,0x00002000,"R--"),
 (30,"modem.b30",0x1e400000,0x99600000,0x00014044,0x00015000,"R-E"),
 (33,"modem.b33",0xa1000000,0x99700000,0x00072f48,0x00072f48,"R--"),
]

import os
base="/tmp/modemre"
for idx,fn,va,pa,fsz,msz,fl in PH:
    p=os.path.join(base,fn)
    if not os.path.exists(p): continue
    with open(p,"rb") as f:
        head=f.read(64)
    w=struct.unpack_from("<16L",head,0)
    # entropy-ish: just show first words
    print(f"[{idx:2d}] {fn} va={va:08x} fsz={fsz:08x} {fl}  first8w: "+" ".join("%08x"%x for x in w[:8]))
