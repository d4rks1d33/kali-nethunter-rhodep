# NFC on rhodep (Moto G82 5G) — card emulation research

Everything for making NFC **card emulation (listen mode)** work under mainline
Linux on rhodep. Reading tags (poll mode) already works; emulation is the open
item. The target use case is emulating a transit card (SUBE) provisioned in the
phone's embedded secure element (eSE).

Kept separate from the modem research (`../modem-blob/`).

## The chip (confirmed)

Samsung **S3FWRN5 / S3NRN4V** (chip code 0x86), on i2c 0x27 (`2-0027`), driver
`s3fwrn5_i2c`. Confirmed in the vendor DT (`blair-rhodep-common-overlay.dtsi`:
`sec-nfc@27`) and live. The `st,st21nfc` seen in some Motorola DTs is the
**blair-milanf** variant, NOT rhodep. GPIOs: VEN=48, FIRM=8, IRQ=9, clk_req=7.

## The diagnosis (triangulated by 3 sources)

Card emulation accepts the full NCI listen setup (RF_SET_LISTEN_MODE_ROUTING and
RF_DISCOVER return status 0x0) but historically never raised
RF_INTF_ACTIVATED_NTF on NFC-A. The cause is **NOT** a missing RF listen profile:
- The chip firmware (`sec_s3nrn4v_firmware.bin`, Cortex-M/Thumb-2, v3.65, SLSI)
  HAS the full NFC-A listen card path built in (LA_ tags, REQA/WUPA, SEL_REQ,
  RATS). Not gated in firmware. (findings/firmware_re.md)
- The RF blobs (hwreg/swreg) are byte-identical to ours (md5); nobody flashes the
  chip firmware (FW_UPDATE_MODE=0). (findings/swreg_rfreg_analysis.md)
- The Samsung HAL sends no proprietary listen-enable command; the listen NCI
  stream comes from AOSP libnfc-nci. (findings/hal_listen_re.md)

The concrete deltas vs the vendor (findings/vendor_listen_sequence.md):
1. **listen-mode routing power byte 0x3B, not 0x3f** — the chip accepts 0x3f
   (status 0) but never activates for it. **This fix is applied** (patch 0111,
   NCI_LMRT_POWER_STATE_ALL 0x3f->0x3b) and built into the flashed kernel.
2. command order should be SET_CONFIG -> RF_DISCOVER_MAP -> LMRT -> RF_DISCOVER
   (still to try if 0x3B alone is insufficient).
3. eSE routing: route NFC-A technology + MIFARE protocol to NFCEE 0x83, power
   0x3B, after NFCEE_MODE_SET(0x83, ENABLE).

## State at last session (2026-09-26)

Flashed the kernel with the 0x3B fix and tested `rhodep-nfc listen`. Live NCI
(live-logs/): the listen still hits problems — a CORE_SET_CONFIG returns
**status 0x9** (a rejected config tag) and NFCEE_MODE_SET returns **status 0x3**
(rejected). The clean listen run kept getting cut by SSH/WiFi drops before a
verdict; a poll-mode RF_INTF_ACTIVATED_NTF was seen (reading the external reader),
but a LISTEN-mode activation (activation_rf_tech_and_mode & 0x80) was not yet
confirmed. Next session: an SSH-drop-proof on-device test + resolve the SET_CONFIG
0x9 (which tag) and the NFCEE_MODE_SET 0x3.

## Layout

- `vendor-lineage/` — the Android NFC HAL extracted byte-exact from the LineageOS
  rhodep OTA (payload.bin -> vendor.img ext4): chip firmware, RF blobs, HAL .so,
  service binary, configs, init.rc. `super-extract-raw/` = the earlier raw dd
  fragments from the on-device super partition (superseded by the clean LineageOS
  extraction) + lp_extract.py.
- `findings/` — the RE reports (also mirrored in the repo `docs/nfc-wip/`).
- `scripts/` — `rhodep-nfc` (userspace NCI tool: read/watch/raw/listen/info) and
  `rhodep-nfc-listen-test.sh` (on-device listen test with logging).
- `live-logs/` — on-device NCI captures (nfc_raw.log has the frame dump; nfc.pcap
  for Wireshark).

## How to reproduce the extraction (LineageOS vendor)

    unzip -o lineage-...-rhodep-signed.zip payload.bin
    python3 dump_payload.py payload.bin vendor vendor.img   # A/B OTA extractor
    sudo mount -o ro,loop vendor.img /mnt
    # HAL: /mnt/lib64/nfc_nci_sec.so, /mnt/bin/hw/android.hardware.nfc-service.sec
    # fw:  /mnt/firmware/sec_s3nrn4v_firmware.bin
    # cfg: /mnt/etc/libnfc-nci.conf, /mnt/etc/libnfc-sec-vendor.conf
