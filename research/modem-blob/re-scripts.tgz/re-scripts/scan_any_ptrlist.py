#!/usr/bin/env python3
# Find long monotonic ptr lists anywhere (>=1000 entries), small deltas (<0x2000),
# values in 0xc0000000..0xe0000000. These are candidate q6zip/delta page tables.
import struct, json, array
d=open('/tmp/modemre/modem_full.elf','rb').read()
phs=json.load(open('/tmp/modemre/phs.json'))
def f2v(fo):
    for off,va,fsz,msz,fl in phs:
        if off<=fo<off+fsz: return va+(fo-off)
    return None
n=len(d)//4
w=array.array('I'); w.frombytes(d[:n*4])
i=0; runs=[]
while i<n-1:
    a=w[i]
    if 0xc0000000<=a<0xe0000000:
        j=i
        while j+1<n and w[j+1]>=w[j] and 0<=(w[j+1]-w[j])<0x4000 and 0xc0000000<=w[j+1]<0xe0000000:
            j+=1
        if j-i>=1000:
            runs.append((i,j-i))
        i=j+1
    else:
        i+=1
runs.sort(key=lambda x:-x[1])
for idx,L in runs[:20]:
    fo=idx*4
    print(f"len={L:6d} fileofs={fo:08x} vaddr={f2v(fo):08x} first={w[idx]:08x} last={w[idx+L-1]:08x} span={w[idx+L-1]-w[idx]:08x}")
