#!/usr/bin/env python3
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack('<I',data[i:i+4])[0] for i in range(0,N-3,4)]

# gp-relative STORE memb offset 0x740: 0x4803e?40 (bits: 0x4803e040 + (reg<<8))
# memb store S2_storerbgp: base 0x48000000 ... let's just mask the register nibble.
# From samples: memb gp+0x740 = 0x4803e040 | (reg<<8)  -> reg in bits [11:8]
def is_gp_store_memb(w):
    return (w & 0xFFFFF0FF) == 0x4803e040
# memh gp+0x740? offset for memh is 0x740>>1 encoded differently; assemble to check.
# We'll also catch memw. Add separately below.

# Also scan gp LOADS for context
def is_gp_load_memub(w):
    return (w & 0xFFFFF0FF) == 0x4923e800  # r?=memub(gp+0x740)
def is_gp_load_memb(w):
    return (w & 0xFFFFF0FF) == 0x4903e800

stores=[]; loads=[]
for i,w in enumerate(words):
    va=BASE+i*4
    if is_gp_store_memb(w): stores.append((va,w,'memb_store'))
    if is_gp_load_memub(w): loads.append((va,w,'memub_load'))
    if is_gp_load_memb(w): loads.append((va,w,'memb_load'))

print("=== gp+0x740 STORES (memb) ===", len(stores))
for va,w,t in stores: print("  %08x %08x %s"%(va,w,t))
print("=== gp+0x740 LOADS ===", len(loads))
for va,w,t in loads: print("  %08x %08x %s"%(va,w,t))
