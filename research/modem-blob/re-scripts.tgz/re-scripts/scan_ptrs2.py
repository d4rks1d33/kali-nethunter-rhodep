import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, SEGS, off_to_va, seg_of

NAME_LO=0xc414b000
NAME_HI=0xc414c200

allhits=[]
for i,off,vaddr,pa,fsz,msz,fl in SEGS:
    if not fsz: continue
    data=FULL[off:off+fsz]
    for p in range(0, len(data)-4, 4):
        v=struct.unpack('<I',data[p:p+4])[0]
        if NAME_LO<=v<NAME_HI:
            allhits.append((vaddr+p, v, i))
print("total pointers into name-cluster (all segs):", len(allhits))
from collections import Counter
segc=Counter(h[2] for h in allhits)
print("by segment:", dict(segc))
# imprimir primeros 30
for va,v,i in allhits[:40]:
    print("  ptr@0x%08x -> 0x%08x (seg%d)"%(va,v,i))
