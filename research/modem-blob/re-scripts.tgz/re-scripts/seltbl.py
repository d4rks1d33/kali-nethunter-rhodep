import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, u16
tbl=0xc37bd1e8
print("FTM 0x0B selector table @ 0x%08x (75 entries, 8 bytes each)"%tbl)
seen={}
for i in range(75):
    va=tbl+8*i
    sel_lo=u16(va); sel_hi=u16(va+2); disp=u32(va+4)
    seen[disp]=seen.get(disp,0)+1
    print("[%2d] sel=0x%04x(%5d) hi=0x%04x disp=0x%08x"%(i,sel_lo,sel_lo,sel_hi,disp))
print("distinct dispatch pointers:", {hex(k):v for k,v in seen.items()})
