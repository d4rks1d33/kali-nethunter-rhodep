import sys, struct
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, SEGS, va_to_off, off_to_va, u32, is_valid_va
def cstr(va, maxlen=40):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
# Look at cluster around 0xc378a3e0
print("=== string cluster @0xc378a3e0 ===")
o=va_to_off(0xc378a3e0)
d=FULL[o:o+120]
print(repr(d))
print("\n=== find ptr arrays referencing 0xc378a3ea (WCDMA) region ===")
lo,hi=0xc378a3e0,0xc378a480
for i,off,va,pa,fsz,msz,fl in SEGS:
    if not fsz: continue
    data=FULL[off:off+fsz]
    for p in range(0,len(data)-4,4):
        v=struct.unpack('<I',data[p:p+4])[0]
        if lo<=v<hi:
            # print small window as array
            pva=va+p
            print("ptr@0x%08x(seg%d) -> 0x%08x '%s'"%(pva,i,v,cstr(v)))
