#!/usr/bin/env python3
import struct,sys,collections
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
def w(off): return struct.unpack('<I',data[off:off+4])[0]
def val_imm(ww):
    b_hi=(ww>>16)&0x1ff; b_lo=(ww>>1)&0x1fff
    imm=(b_hi<<13)|b_lo
    if imm&(1<<21): imm-=(1<<22)
    return imm<<2
# precompute all call/jump edges once
def callers(tgt):
    res=[]
    for off in range(0,N-4,4):
        ww=w(off); op7=(ww>>25)&0x7f
        if op7==0b0101101:
            if BASE+off+val_imm(ww)==tgt: res.append(('C',BASE+off))
        elif op7==0b0101100:
            if BASE+off+val_imm(ww)==tgt: res.append(('J',BASE+off))
    return res
def fnstart(va):
    off=va-BASE
    lim=max(0,off-0x3000)
    for o in range(off,lim,-4):
        ww=w(o)
        if ww in (0x961ec01e,0x529fc000,0x529f4000):
            return BASE+o+4
    return None
# BFS backward on function level
roots=[int(x,0) for x in sys.argv[1:]]
seen=set()
q=collections.deque()
for r in roots:
    fs=fnstart(r) or r
    q.append((fs,0,[hex(r)]))
    seen.add(fs)
maxdepth=6
while q:
    fn,d,path=q.popleft()
    cs=callers(fn)
    tag="VTABLE/ROOT(no static callers)" if not cs else ""
    print("  "*d+f"FN {hex(fn)} depth={d} {tag} callsites={[ (t,hex(v)) for t,v in cs][:8]}")
    if d>=maxdepth: continue
    for t,site in cs:
        pfn=fnstart(site)
        if pfn and pfn not in seen:
            seen.add(pfn)
            q.append((pfn,d+1,path+[hex(site)]))
