#!/usr/bin/env python3
# Read rodata/data words from the modem segments by VA (auto-select b-file).
import sys,struct
# (vaddr, filesz, bfile)
SEGS=[
 (0xc0800000,0x00002930,'modem.b02'),
 (0xc0900000,0x0003bd40,'modem.b04'),
 (0xc0980000,0x0002c190,'modem.b05'),
 (0xc09ad000,0x0003e4a0,'modem.b06'),
 (0xc09ec000,0x0000e3b0,'modem.b07'),
 (0xc09fb000,0x0002380c,'modem.b08'),
 (0xc0a1f000,0x00060064,'modem.b09'),
 (0xc0a80000,0x0029ab14,'modem.b10'),
 (0xc0d20000,0x00009140,'modem.b11'),
 (0xc0d30000,0x00006000,'modem.b12'),
 (0xc0d36000,0x0031f1b0,'modem.b13'),
 (0xc1080000,0x00040000,'modem.b14'),
 (0xc10c0000,0x0039c000,'modem.b15'),
 (0xc145d000,0x0023aeb8,'modem.b17'),
 (0xc16c0000,0x000a9cb0,'modem.b18'),
 (0xc1780000,0x002d0000,'modem.b19'),
 (0xc1a50000,0x0096e988,'modem.b20'),
 (0xc3553000,0x00d315f4,'modem.b21'),
 (0xc8b6a000,0x005cdd97,'modem.b23'),
 (0xcbf4f000,0x00019900,'modem.b25'),
 (0xcc000000,0x0244a040,'modem.b26'),
 (0xce480000,0x0011922f,'modem.b27'),
 (0xce5b1000,0x00001064,'modem.b29'),
]
def find_seg(va):
    for base,sz,f in SEGS:
        if base<=va<base+sz: return base,f
    return None,None
def readbytes(va,n):
    base,f=find_seg(va)
    if not f: return None,None
    data=open('/tmp/modemre/'+f,'rb').read()
    off=va-base
    return data[off:off+n],f

if __name__=='__main__':
    va=int(sys.argv[1],0)
    n=int(sys.argv[2],0) if len(sys.argv)>2 else 16
    mode=sys.argv[3] if len(sys.argv)>3 else 'w'
    b,f=readbytes(va,n*4 if mode=='w' else n)
    if b is None: print("no seg for",hex(va)); sys.exit(1)
    print(f"# {f} va=0x{va:08x}")
    if mode=='w':
        for k in range(n):
            w=struct.unpack('<I',b[k*4:k*4+4])[0]
            print(f"0x{va+k*4:08x}: 0x{w:08x}")
    else:
        # string/hex dump
        s=b.split(b'\x00')[0]
        print(repr(b[:n]))
