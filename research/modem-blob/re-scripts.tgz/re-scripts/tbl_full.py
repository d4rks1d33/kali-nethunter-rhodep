import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va, seg_of
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]
    n=d.find(b'\x00')
    if n<0: n=maxlen
    try: return d[:n].decode('ascii')
    except: return None

# Definir rangos de rodata donde viven nombres (strings ascii legibles cortos)
def is_name_ptr(v):
    if v is None or not is_valid_va(v): return False
    s=cstr(v,64)
    if not s: return False
    # nombre valido: mayusculas/digitos/underscore/espacio, longitud razonable
    if len(s)<2 or len(s)>40: return False
    ok=all(c.isupper() or c.isdigit() or c in '_ ' for c in s)
    return ok

# Encontrar limites: retroceder desde 0xc906c294 mientras haya name-ptrs o ceros
start=0xc906c294
# retroceder
p=start
while True:
    v=u32(p-4)
    if is_name_ptr(v) or v==0:
        p-=4
    else:
        break
tbl_start=p
# avanzar
p=start
while True:
    v=u32(p)
    if is_name_ptr(v) or v==0:
        p+=4
    else:
        break
tbl_end=p
print("Table span: 0x%08x .. 0x%08x  (%d entries)"%(tbl_start,tbl_end,(tbl_end-tbl_start)//4))
# ver que hay justo antes y despues
print("before start:")
for va in range(tbl_start-16, tbl_start,4):
    v=u32(va); print("  0x%08x: 0x%08x %s"%(va,v, ("'"+str(cstr(v))+"'") if is_valid_va(v) else ""))
print("after end:")
for va in range(tbl_end, tbl_end+16,4):
    v=u32(va); print("  0x%08x: 0x%08x %s"%(va,v, ("'"+str(cstr(v))+"'") if is_valid_va(v) else ""))
