# Contexto para análisis del dispatcher FTM (SM6375 Moto G82 5G)

## Estado
La descompresión CLADE está RESUELTA (libclade.so HW-accurate). El código en 0xd8xxxxxx
está descomprimido LIMPIO en `/tmp/modemre/clade_code_10m.bin` (VA base 0xd8000000, 10MB).
Disassembly completo: `/tmp/big10.txt` (llvm-objdump hexagon v66, <0.14% invalid).

## Objetivo
Extraer del dispatcher FTM RF (entry 0xd8150ed8, ftm_cmd_id 0x27 = LTE):
1. sub_command exacto de TECH_ENTER (bajo cmd 0x27)
2. enum numérico de TECH para LTE (y NR5G) - TLV field_id 2, grupo 16
3. flag tech_entered (dirección global) + condición exacta del error 0x14 (DIAG_BAD_PARM)
4. mapeo sub_command -> handler
5. TLVs obligatorios de cada comando

## Datos clave
- Tabla dispatch rodata @ file b21 offset 0x26a1e8 (VA 0xc37bd1e8): 78 entries {cmd:u16dup,handler:u32}, todas -> 0xd8150ed8. cmd 0x27 = entry 4.
- 0xd8150ed8 = wrapper de registro DIAG (valida subsys 0xb, cmd 0x14, id 0x35a). Registra el handler.
- Regiones: código en 0xd8xxxxxx; los handlers FTM RF en 0xd813xxxx-0xd81dxxxx.
- Herramienta de disasm: `llvm-objdump-18 -d --triple=hexagon --mcpu=hexagonv66`
- Para desensamblar un rango: `python3 /tmp/modemre/mkelf.py <bin> <vaddr> <out.elf>`

## Cómo descomprimir más código/datos
`/tmp/qbs/clade_extractor_sm6375 <out> <req_va_hex> <len_hex>` bajo:
`QEMU_LD_PREFIX=/usr/x86_64-linux-gnu LD_LIBRARY_PATH=/tmp/qbs:/usr/lib/x86_64-linux-gnu qemu-x86_64-static`
donde req_va = 0xcc000000 + (output_vaddr - 0xd8000000). Ej: para 0xd8150000 usar req_va=0xcc150000.
