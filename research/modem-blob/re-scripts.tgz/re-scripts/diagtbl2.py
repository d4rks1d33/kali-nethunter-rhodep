import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va, seg_of
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
def dump(tbl,count,name):
    print("\n=== %s @ 0x%08x count=%d  ({name_ptr,handler} 8-byte) ==="%(name,tbl,count))
    for i in range(count):
        va=tbl+8*i
        a=u32(va); h=u32(va+4)
        s=cstr(a) if is_valid_va(a) else None
        print("[%2d] 0x%08x name=0x%08x handler=0x%08x  %s"%(i,va,a,h, ("'"+s+"'") if s else ""))
dump(0xc379d848,18,"tbl_A")
dump(0xc379ee88,25,"tbl_B")
