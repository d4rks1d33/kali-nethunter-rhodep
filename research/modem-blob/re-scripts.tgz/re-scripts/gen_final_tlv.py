import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
def is_name_ptr(v):
    if v is None or not is_valid_va(v): return False
    s=cstr(v,64)
    if not s: return False
    if len(s)<2 or len(s)>40: return False
    return all(c.isupper() or c.isdigit() or c in '_ ' for c in s)

def read_group(base):
    names=[]
    va=base
    while True:
        v=u32(va)
        if v==0: break
        if is_name_ptr(v):
            names.append(cstr(v)); va+=4
        else: break
    return names

groups={13:0xc906c630,14:0xc906c720,10:0xc906c5d8}
for g,b in groups.items():
    names=read_group(b)
    print("\n### GROUP %d @ 0x%08x (%d fields) ###"%(g,b,len(names)))
    for i,n in enumerate(names):
        print("  ID=%-3d  %s"%(i,n))
