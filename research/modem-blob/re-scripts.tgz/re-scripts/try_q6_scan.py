#!/usr/bin/env python3
# Try to find a q6zip header anywhere in the ELF by validating the tool's
# self-consistency: at offset O, npages/ver plausible, dict, then ptrs where
# ptrs are strictly increasing and ptrs[0] maps to just-after-the-ptrlist.
# Then attempt a decompress of page 0 and see if output disassembles as hexagon
# (heuristic: many words have valid-looking instruction encodings).
import sys, struct, json, array
sys.path.insert(0,'/tmp/q6zip')
d=open('/tmp/modemre/modem_full.elf','rb').read()
phs=json.load(open('/tmp/modemre/phs.json'))
def f2v(fo):
    for off,va,fsz,msz,fl in phs:
        if off<=fo<off+fsz: return va+(fo-off)
    return None
def v2f(va):
    for off,vaddr,fsz,msz,fl in phs:
        if vaddr<=va<vaddr+fsz: return off+(va-vaddr)
    return None
n=len(d)//4
w=array.array('I'); w.frombytes(d[:n*4])

# The tool: datastart offset = 4 + (dict1+dict2)*4 + npages*4 (bytes) from header start.
# ptrs[0] is a vaddr; elfbase = ptrs[0] - datastart(bytes offset within section file window)
# For a valid header: ptrs must be increasing, ptrs[0] < ptrs[-1], and
# ptrs[-1]-ptrs[0] roughly == data size. We look for headers where the ptr list
# (located dict-words after header) is long & strictly increasing with small deltas.

def check(i, dictwords):
    npages=w[i]&0xffff
    ver=(w[i]>>16)&0xffff
    if not (200<=npages<=20000): return None
    if ver>0x30: return None
    pl=i+1+dictwords
    if pl+npages+2>=n: return None
    # first ptr
    p0=w[pl]
    if not (0xc0000000<=p0<0xe0000000): return None
    # verify strictly increasing for the whole list, deltas 4..0x2000
    prev=p0; okcount=0
    for k in range(1,npages):
        v=w[pl+k]
        dl=v-prev
        if 0< dl <0x4000:
            okcount+=1; prev=v
        else:
            break
    return (npages,ver,okcount,p0,prev)

results=[]
for dictwords in [0x4400,0x4200,0x4100,0x8400,0x2400,0x1400,0x4800,0x0]:
    for i in range(0, n-0x5000):
        r=check(i,dictwords)
        if r and r[2]>=r[0]*0.9 and r[0]>=800:  # 90% of ptrs strictly increasing
            results.append((f2v(i*4),dictwords,)+r)
# dedupe by header va
seen=set(); out=[]
for r in results:
    if r[0] in seen: continue
    seen.add(r[0]); out.append(r)
for r in out[:40]:
    print('hdr@%08x dict=%#x npages=%d ver=%d ok=%d p0=%08x plast=%08x'%r)
print('total',len(out))
