#!/usr/bin/env python3
import struct, numpy as np
d = open('/tmp/modemre/modem_full.elf','rb').read()
a = np.frombuffer(d[:len(d)//4*4], dtype='<u4')

# find file offsets where a word == 0xd8000000
idx = np.nonzero(a == 0xd8000000)[0]
for i in idx:
    ctx = [int(a[j]) for j in range(max(0,i-4), min(len(a),i+8))]
    fo = i*4
    print(f"foff 0x{fo:08x}: " + " ".join(f"{v:08x}" for v in ctx))
