#!/usr/bin/env python3
# Forward direct-call/jump reachability BFS from roots to a set of targets, over 36MB.
import struct,sys,collections,pickle
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
def w(off):
    if off<0 or off+4>N: return 0
    return struct.unpack('<I',data[off:off+4])[0]
def val_imm(ww):
    b_hi=(ww>>16)&0x1ff; b_lo=(ww>>1)&0x1fff
    imm=(b_hi<<13)|b_lo
    if imm&(1<<21): imm-=(1<<22)
    return imm<<2
def is_term(ww):
    if ww in (0x529fc000,0x529f4000,0x961ec01e,0x901ec01e): return True
    if (ww&0x0000ff00)==0x00001f00 and (ww>>28)==0x3: return True
    if (ww&0xffff)==0xc01e and (ww>>24)==0x90: return True
    return False
def is_nop(ww): return ww==0x7f00c000
def fnstart(va):
    off=va-BASE
    lim=max(0,off-0x4000)
    for o in range(off-4,lim,-4):
        if is_term(w(o)):
            s=o+4
            while s<off and is_nop(w(s)): s+=4
            return BASE+s
    return None
# forward edges: from a fn, collect call/jump targets within [fn, fn_end); fn_end = next terminator+scan
def out_edges(fn):
    off=fn-BASE
    outs=[]
    if off<0 or off>=N: return outs
    o=off
    while o<N-8:
        ww=w(o)
        op7=(ww>>25)&0x7f
        if op7==0b0101101 or op7==0b0101100:
            outs.append(BASE+o+val_imm(ww))
        if is_term(ww):
            break
        o+=4
        if o-off>0x6000: break
    return outs
roots=[int(x,0) for x in sys.argv[1].split(',')]
targets=set(int(x,0) for x in sys.argv[2].split(','))
tgt_fns=set()
for t in targets: tgt_fns.add(fnstart(t) or t); tgt_fns.add(t)
seen=set(); q=collections.deque()
parent={}
for r in roots:
    fs=fnstart(r) or r; q.append(fs); seen.add(fs); parent[fs]=None
found=[]
steps=0
while q and steps<200000:
    steps+=1
    fn=q.popleft()
    if fn in tgt_fns or fn in targets:
        # reconstruct
        path=[]; c=fn
        while c is not None: path.append(hex(c)); c=parent.get(c)
        print("REACHED",hex(fn),"path(up):"," <- ".join(path))
        found.append(fn); continue
    for t in out_edges(fn):
        tf=fnstart(t) or t
        if tf not in seen:
            seen.add(tf); parent[tf]=fn; q.append(tf)
if not found:
    print("NOT reached. visited",len(seen),"fns")
