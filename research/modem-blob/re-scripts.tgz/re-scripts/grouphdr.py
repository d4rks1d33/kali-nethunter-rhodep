import sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, va_to_off, u32, is_valid_va
def cstr(va, maxlen=80):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]; n=d.find(b'\x00')
    if n<0:n=maxlen
    try:return d[:n].decode('ascii','replace')
    except:return None
# group bases (UNASSIGNED start). Look at the 16 bytes BEFORE each group base.
bases={0:0xc906c268,1:0xc906c290,2:0xc906c328,3:0xc906c388,4:0xc906c438,5:0xc906c4d8,
6:0xc906c530,7:0xc906c560,8:0xc906c588,9:0xc906c5c0,10:0xc906c5d8,11:0xc906c608,12:0xc906c618,
13:0xc906c630,14:0xc906c720,15:0xc906c850,16:0xc906c8e8,17:0xc906c8f8,18:0xc906c968,19:0xc906cce0,
20:0xc906cd78,21:0xc906cdf0,22:0xc906ce18,23:0xc906ce38,24:0xc906ce80}
for g,b in bases.items():
    hdr=[u32(b-16+4*j) for j in range(4)]
    print("grp %2d base=0x%08x  hdr[-16..]= %08x %08x %08x %08x"%(g,b,hdr[0],hdr[1],hdr[2],hdr[3]))
