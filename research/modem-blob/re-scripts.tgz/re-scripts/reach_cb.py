#!/usr/bin/env python3
import struct,sys,bisect
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
def val_imm(w):
    b_hi=(w>>16)&0x1ff; b_lo=(w>>1)&0x1fff
    imm=(b_hi<<13)|b_lo
    if imm&(1<<21): imm-=(1<<22)
    return imm<<2
def calls_in(va, span=0x900):
    out=set()
    off=va-BASE
    if off<0: return out
    for a in range(off, min(off+span, N-3), 4):
        w=struct.unpack('<I',data[a:a+4])[0]
        op7=(w>>25)&0x7f
        cur=BASE+a
        if op7==0b0101101:
            t=cur+val_imm(w)
            if BASE<=t<BASE+N: out.add(('c',t))
        elif op7==0b0101100:
            t=cur+val_imm(w)
            if BASE<=t<BASE+N and not(va<=t<va+span): out.add(('j',t))
    return out

# gate-related targets: writers of gate(a), creator/accessor gate(b), carrier-activate, apply, setter
TARGETS={
 0xd81bd494:'gateA_write_mux', 0xd81bd5fc:'gateA_write_mux2', 0xd81bd7c8:'gateA_reset0',
 0xd8284eac:'gateB_getorcreate', 0xd8284cf4:'gateB_creator', 0xd81bd018:'carrier_activate',
 0xd8273b2c:'APPLY', 0xd8279264:'carrier_setter', 0xd827923c:'carrier_getter_SSR',
}
def bfs(root, maxnodes=60000):
    seen=set(); fr=[root]; parent={root:None}
    hits=[]
    while fr:
        x=fr.pop()
        if x in seen: continue
        seen.add(x)
        if len(seen)>maxnodes: break
        for kind,t in calls_in(x):
            if t in TARGETS and t not in [h[0] for h in hits]:
                p=[t,x]; q=parent.get(x)
                while q is not None: p.append(q); q=parent.get(q)
                hits.append((t,list(reversed(p))))
            if t not in seen and t not in parent:
                parent[t]=x; fr.append(t)
    return hits, len(seen)

for name,root in [('LTE_cb_entry_0xd8247540',0xd8247540),
                  ('LTE_cb_worker_0xd8247574',0xd8247574),
                  ('LTE_cb_func_0xd82473e4',0xd82473e4),
                  ('commit_0xd81dfecc',0xd81dfecc)]:
    hits,nseen=bfs(root)
    print("==== %s (visited %d) ===="%(name,nseen))
    if hits:
        for t,path in hits:
            print("  REACHES %s (%s)"%(hex(t),TARGETS[t]))
            print("    path:"," -> ".join(hex(z) for z in path))
    else:
        print("  reaches NO gate-related target")
