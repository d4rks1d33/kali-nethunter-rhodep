#!/usr/bin/env python3
# Search the whole ELF for references to the clade region base (0xd8xxxxxx)
# and for pairs of {start,end} that bracket 0xd8150ed8.
import struct, numpy as np

d = open('/tmp/modemre/modem_full.elf','rb').read()
a = np.frombuffer(d[:len(d)//4*4], dtype='<u4')

TARGET = 0xd8150ed8
# find all words that look like they're in 0xd8000000..0xd9000000
mask = (a >= 0xd8000000) & (a < 0xda000000)
idx = np.nonzero(mask)[0]
print("count words in 0xd8..0xda:", len(idx))
# histogram of distinct values that are page-aligned region bounds
from collections import Counter
c = Counter()
for i in idx:
    v = int(a[i])
    if v & 0xfff == 0:  # page aligned candidates for region bounds
        c[v]+=1
print("most common page-aligned 0xd8/d9 values:")
for v,n in c.most_common(30):
    print(f"  {v:08x}  x{n}")
