#!/usr/bin/env python3
import struct,subprocess,os
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()

hits=[
0xd808eac0,0xd815022c,0xd8167a48,0xd8167e74,0xd81bc63c,0xd81bd0a8,0xd81bd1ac,
0xd81bd268,0xd81bd2c0,0xd81bd31c,0xd81bd3ac,0xd81bd40c,0xd81bd454,0xd81bd5b8,
0xd81bd7ac,0xd81bd7bc,0xd8209200,0xd820920c,0xd820bca8,0xd82c23c4,0xd82dd7b4,
0xd82f0d78,0xd833e548,0xd833e6bc,0xd833e758,0xd83553a8,0xd8356330,0xd835ba04,
0xd835c04c,0xd83606a4,0xd838e9a8,0xd8395008,0xd839d3f0,0xd846f82c,
]

def dis(va,n=6):
    off=va-BASE
    code=data[off:off+n*4]
    from mkelf import make_elf
    make_elf(code,va,'/tmp/_h.elf')
    out=subprocess.check_output(['llvm-objdump-18','-d','--triple=hexagon','--mcpu=hexagonv66','/tmp/_h.elf']).decode()
    lines=out.splitlines()[7:]
    return "\n".join(lines)

import sys
sys.path.insert(0,'/tmp/modemre')
for h in hits:
    print("==== %08x ===="%h)
    print(dis(h,5))
    print()
