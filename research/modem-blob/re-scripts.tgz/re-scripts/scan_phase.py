#!/usr/bin/env python3
# Scan full 36MB for stores to the FTM phase struct 0xcb8dbeb0 (offset ~0x18 => 0xcb8dbec8)
# and immext references to the base/struct.
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack_from('<I',data,i)[0] for i in range(0,N-3,4)]
NW=len(words)

def immext_val(w):
    if (w>>28)!=0: return None
    return (((((w>>16)&0xFFF)<<14)|(w&0x3FFF))<<6) & 0xffffffff

STRUCT_BASE=0xcb8dbeb0
PHASE=0xcb8dbec8  # base+0x18
# absolute store: high part = target & ~0x3f. For 0xcb8dbec8 -> 0xcb8dbec0 (low6=0x08)
#                 for 0xcb8dbeb0 -> 0xcb8dbe80 (low6=0x30)
# The immext could also carry the exact aligned target for a [Rs+#u] load into base ptr.

# We want:
#  (A) immext whose value (high part) is 0xcb8dbe80 or 0xcb8dbec0  (covers base & phase)
#      i.e. immext_val in {0xcb8dbe80, 0xcb8dbec0}
#  (B) immext value == 0xcb8dbeb0 exactly (ptr load: r=##0xcb8dbeb0; then memX(r+#0x18))
# Then examine paired/following instruction to see if it's a STORE.

# store opcode top bytes:
#  absolute store S2_storerX_io w/ ##: class 0x48 (memX(##)=Rt), 0x4a?, 
#  store-imm memb/memh/memw(Rs+#u)=#S: class 0x3c/0x3d/0x3e maybe
#  conditional abs store: 0xaf/0xab
#  reg-offset store: 0xa1 (memX(Rs+#s11)=Rt)

def top(w): return (w>>24)&0xff

hits_abs=[]   # absolute store or immext ref to phase/base high parts
hits_ptr=[]   # immext produces exact 0xcb8dbeb0

for i,w in enumerate(words):
    v=immext_val(w)
    if v is None: continue
    va=BASE+i*4
    if v in (0xcb8dbe80,0xcb8dbec0,0xcb8dbeb0):
        nxt = words[i+1] if i+1<NW else 0
        nxt2 = words[i+2] if i+2<NW else 0
        nxt3 = words[i+3] if i+3<NW else 0
        rec=(va,v,nxt,nxt2,nxt3)
        if v==0xcb8dbeb0:
            hits_ptr.append(rec)
        else:
            hits_abs.append(rec)

def desc(w):
    t=top(w)
    kinds={0x48:'ABS-store/load(##)',0x49:'ABS-load(##)',0x4a:'ABS',
           0x3c:'store-imm(Rs+#)=#',0x3d:'store-imm',0x3e:'store-imm',
           0xa1:'store(Rs+#)=Rt',0xa0:'store-imm(Rs+#)',
           0xaf:'cond-abs-store',0xab:'cond',0x91:'load(Rs+#)',0x92:'loadu'}
    return kinds.get(t,'')+(' top=%02x'%t)

print("=== immext high-part hits (0xcb8dbe80 / 0xcb8dbec0) ===")
for va,v,n1,n2,n3 in hits_abs:
    print("%08x immext=%08x | +4:%08x %s | +8:%08x %s"%(va,v,n1,desc(n1),n2,desc(n2)))

print("\n=== immext exact 0xcb8dbeb0 (ptr load) ===")
for va,v,n1,n2,n3 in hits_ptr:
    print("%08x immext=%08x | +4:%08x %s | +8:%08x %s | +12:%08x %s"%(va,v,n1,desc(n1),n2,desc(n2),n3,desc(n3)))
print("\ncounts: abs-high=%d ptr=%d"%(len(hits_abs),len(hits_ptr)))
