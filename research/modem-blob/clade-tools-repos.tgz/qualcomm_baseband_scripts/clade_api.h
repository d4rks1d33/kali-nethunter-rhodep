/* Reconstructed clade_api.h for libclade.so (Hexagon SDK 3.5.4)
 * Layout recovered by disassembling libclade.so:
 *   - clade_init (config struct offsets)
 *   - print_config (config + pd_params offsets)
 *   - print_memblocks / clade_read (clade_memblock_t offsets)
 *
 * clade_memblock_t (size 0x50):
 *   +0x00 prev (u64)
 *   +0x08 next (u64)
 *   +0x10 id[0x20] (char)
 *   +0x30 wordsize (u32)
 *   +0x38 addr (u64)
 *   +0x40 len (u32)
 *   +0x48 data (u64)
 *
 * clade_config_t:
 *   +0x00 region (u64)
 *   +0x08 num_pds (u32)
 *   +0x0c version/buildid area (set internally to 0x300010144)
 *   +0x10 num_dicts (u32)
 *   +0x14 dict_len (u32)
 *   +0x18 pd_params (ptr)
 *   +0x20 dicts (ptr)
 *   +0x38 error (u32, set internally)
 *   +0x3c magic 0xb993b56 (set internally)
 *
 * clade_pd_params_t (stride 0x40, referenced from pd_params + idx*0x40):
 *   The clade_read PD-search loop reads, at (pd_params + 0x38 + idx*0x40):
 *     [-0x18]=comp addr(u64) [-0x10]=comp len(u32) [-0x08]=exc_hi addr(u64) [0]=exc_hi len(u32)
 *   => within one pd_params entry (base = pd_params + idx*0x40):
 *     +0x20 comp addr, +0x28 comp len, +0x30 exc_hi addr, +0x38 exc_hi len
 *   The .c names the first two written fields ".comp" and ".exc_hi"; we keep those
 *   names but place them so the on-wire layout matches libclade.
 */
#ifndef CLADE_API_H
#define CLADE_API_H

#include <stdint.h>

#pragma pack(push, 1)

typedef struct clade_memblock {
    struct clade_memblock *prev;   /* +0x00 */
    struct clade_memblock *next;   /* +0x08 */
    char       id[0x20];           /* +0x10 */
    uint32_t   wordsize;           /* +0x30 */
    uint32_t   _pad34;             /* +0x34 */
    uint64_t   addr;               /* +0x38 */
    uint32_t   len;                /* +0x40 */
    uint32_t   _pad44;             /* +0x44 */
    uint64_t   data;               /* +0x48 (uint8_t*) */
} clade_memblock_t;

/* one PD descriptor; stride is 0x40 bytes */
typedef struct clade_pd_params {
    uint8_t    _pad00[0x20];       /* +0x00 (metadata/low fields, unused for pure decode) */
    uint64_t   comp;               /* +0x20 comp base addr */
    uint32_t   comp_len;           /* +0x28 comp len */
    uint32_t   _pad2c;             /* +0x2c */
    uint64_t   exc_hi;             /* +0x30 exc_high base addr */
    uint32_t   exc_hi_len;         /* +0x38 exc_high len */
    uint32_t   _pad3c;             /* +0x3c */
} clade_pd_params_t;

typedef struct clade_config {
    uint64_t   region;             /* +0x00 */
    uint32_t   num_pds;            /* +0x08 */
    uint32_t   _ver_lo;            /* +0x0c set internally (part of 0x300010144) */
    uint32_t   num_dicts;          /* +0x10 (also holds high dword of version write) */
    uint32_t   dict_len;           /* +0x14 */
    clade_pd_params_t *pd_params;  /* +0x18 */
    uint32_t **dicts;              /* +0x20 */
    uint8_t    _pad28[0x10];       /* +0x28 .. 0x37 */
    uint32_t   error;              /* +0x38 */
    uint32_t   magic;              /* +0x3c */
} clade_config_t;

#ifdef __cplusplus
extern "C" {
#endif

typedef clade_memblock_t* (*clade_alloc_fn)(clade_memblock_t *request, clade_memblock_t *previous, void *mem);
typedef clade_memblock_t* (*clade_lookup_fn)(clade_memblock_t *request, void *mem);
typedef int               (*clade_free_fn)(clade_memblock_t *request);

int  clade_init(clade_config_t *config);
clade_memblock_t* clade_read(clade_memblock_t *request, void *mem,
                             clade_alloc_fn alloc, clade_lookup_fn lookup, clade_free_fn freefn);
void clade_create_trace_file(const char *name);
void clade_set_trace(int level);
int  clade_get_trace_level(void);
const char* clade_get_error_string(void *cfg);

#ifdef __cplusplus
}
#endif

#pragma pack(pop)
#endif
