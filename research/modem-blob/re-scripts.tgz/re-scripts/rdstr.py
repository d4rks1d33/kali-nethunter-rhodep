import sys
# read a C string from seg27_dec.bin (VA base 0xce480000) or other bins
va=int(sys.argv[1],0)
cands=[('/tmp/modemre/seg27_dec.bin',0xce480000),
       ('/tmp/modemre/clade_dec_36m.bin',0xd8000000)]
for f,base in cands:
    try: d=open(f,'rb').read()
    except: continue
    off=va-base
    if 0<=off<len(d):
        end=d.find(b'\x00',off)
        s=d[off:end]
        try: print(f,hex(va),repr(s.decode('latin1'))); 
        except: pass
