import struct
from elftools.elf.elffile import ELFFile

E = ELFFile(open('/tmp/modemre/modem_full.elf','rb'))
SEGS=[]
for s in E.iter_segments():
    h=s.header
    if h.p_type!='PT_LOAD': 
        # still record
        pass
    SEGS.append((h.p_vaddr,h.p_filesz,h.p_memsz,h.p_offset))

def v2o(va):
    for vaddr,fsz,msz,off in SEGS:
        if fsz and vaddr<=va<vaddr+fsz:
            return off+(va-vaddr)
    return None

def read(va,n):
    o=v2o(va)
    if o is None: return None
    E.stream.seek(o)
    return E.stream.read(n)

def rd32(va):
    b=read(va,4)
    if b is None or len(b)<4: return None
    return struct.unpack('<I',b)[0]

def seg_data(idx):
    s=list(E.iter_segments())[idx]
    h=s.header
    E.stream.seek(h.p_offset)
    return h.p_vaddr, E.stream.read(h.p_filesz)

if __name__=='__main__':
    print('helpers loaded')
