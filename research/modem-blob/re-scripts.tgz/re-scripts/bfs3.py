#!/usr/bin/env python3
# Precise forward BFS with function-boundary detection and hub blacklist.
import subprocess, re, sys
DIS='/tmp/modemre/dis.sh'
LO,HI=0xd8000000,0xd8a00000
SETTER=0xd8279264; GETTER=0xd827923c; APPLY=0xd8273b2c

# Hubs to NOT traverse into (prologue guard, allocators, memcpy, logging, panic).
BLACK={
 0xd814e6ac,  # stack-check/guard called by (almost) every prologue
 0xd8829a00, 0xd8829688, 0xd8829698,  # allocframe stack spill helpers
 0xd80d77a8, 0xd80d8998, 0xd80d8988, 0xd80d8990,  # F3/log/err msg
 0xd8041828,
}

fn_cache={}
def fn_body(va, cap=0x600):
    """Disassemble and return list of (addr, line) up to function end (dealloc_return / jumpr r31
    at a packet boundary '}'), capped at cap bytes."""
    if va in fn_cache: return fn_cache[va]
    o=subprocess.run([DIS,hex(va),hex(cap)],capture_output=True,text=True).stdout
    lines=o.splitlines()
    out=[]
    ended=False
    for ln in lines:
        m=re.match(r'\s*([0-9a-f]+):',ln)
        if not m: 
            out.append((None,ln)); continue
        addr=int(m.group(1),16)
        out.append((addr,ln))
        # function end heuristics: dealloc_return, or (jumpr r31) closing a packet '}'
        if 'dealloc_return' in ln:
            ended=True
        if re.search(r'jumpr r31', ln):
            ended=True
        if ended and '}' in ln:
            break
    fn_cache[va]=out
    return out

def callees(va):
    body=fn_body(va)
    cs=set()
    for addr,ln in body:
        for c in re.findall(r'call (0x[0-9a-f]+)', ln):
            cs.add(int(c,16))
        # tail-call jumps to another function prologue (in code range) count as calls
        for j in re.findall(r'jump (0x[0-9a-f]+)', ln):
            jv=int(j,16)
            # heuristic: tail-call if jump target is far outside this function body
            if LO<=jv<HI and (jv<va or jv>va+0x600):
                cs.add(jv)
    return cs

def touches_ptr(va):
    body=fn_body(va)
    load=store=False
    for addr,ln in body:
        if 'ca79c494' in ln:
            if re.search(r'memw\(##0xca79c494\)\s*=',ln): store=True
            elif re.search(r'memw\(##0xca79c494\)',ln): load=True
    return load,store

def bfs(root, maxd=10):
    seen=set(); fr={root}; d=0
    path={root:None}
    hit={}
    order=[]
    while fr and d<maxd:
        nx=set()
        for x in fr:
            if x in seen: continue
            seen.add(x); order.append(x)
            cs=callees(x)
            for t in (SETTER,GETTER,APPLY):
                if t in cs: hit.setdefault(t,x)
            ld,st=touches_ptr(x)
            if ld: hit.setdefault(('LOAD',x),x)
            if st: hit.setdefault(('STORE',x),x)
            for c in cs:
                if c in BLACK: continue
                if LO<=c<HI and c not in seen:
                    path.setdefault(c,x); nx.add(c)
        fr=nx-seen; d+=1
    return seen,hit,path

def chain(path,node):
    c=[]; 
    while node is not None: c.append(node); node=path.get(node)
    return list(reversed(c))

if __name__=='__main__':
    root=int(sys.argv[1],0)
    seen,hit,path=bfs(root)
    print(f"root={hex(root)} scanned={len(seen)}")
    reaches_get = GETTER in hit or any(isinstance(k,tuple) and k[0]=='LOAD' for k in hit)
    reaches_set = SETTER in hit or any(isinstance(k,tuple) and k[0]=='STORE' for k in hit)
    for t,name in [(SETTER,'SETTER(store 0xca79c494)'),(GETTER,'GETTER(load/deref 0xca79c494)'),(APPLY,'APPLY carrier fn')]:
        if t in hit:
            ch=chain(path,hit[t])+[t]
            print(f"  REACHES {name}: {' -> '.join(hex(c) for c in ch)}")
        else:
            print(f"  no  {name}")
    print(f"  => reaches_getter(deref)={reaches_get}  reaches_setter(store)={reaches_set}")
