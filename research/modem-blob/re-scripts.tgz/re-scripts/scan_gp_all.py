#!/usr/bin/env python3
import struct
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
words=[struct.unpack('<I',data[i:i+4])[0] for i in range(0,N-3,4)]

# memb gp+0x740 store: base 0x4803e040, reg in bits[12:8] (0x00..0x1f << 8)
# memh gp+0x740 store: base 0x4841e0a0, reg in bits[12:8]
# memw gp+0x740 store: base 0x4880e0d0, reg in bits[12:8]
def match(w, base):
    return (w & ~0x1F00)==base
found=[]
for i,w in enumerate(words):
    va=BASE+i*4
    if match(w,0x4803e040): found.append((va,w,'memb',(w>>8)&0x1f))
    if match(w,0x4841e0a0): found.append((va,w,'memh',(w>>8)&0x1f))
    if match(w,0x4880e0d0): found.append((va,w,'memw',(w>>8)&0x1f))
print("gp+0x740 stores (all reg):",len(found))
for va,w,t,r in found: print("  %08x %08x %s r%d"%(va,w,t,r))
