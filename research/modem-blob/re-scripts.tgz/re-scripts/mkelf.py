#!/usr/bin/env python3
# Wrap a raw code blob into a minimal Hexagon ELF for llvm-objdump.
import struct, sys

def make_elf(code, vaddr, out):
    EI = b'\x7fELF' + bytes([1,1,1,0]) + b'\x00'*8  # 32-bit LE
    e_type=2; e_machine=0xa4; e_version=1
    e_entry=vaddr
    ehsize=52; phentsize=32; phnum=1
    e_phoff=ehsize
    e_shoff=0; e_flags=0x73; e_shentsize=0; e_shnum=0; e_shstrndx=0
    code_off = ehsize + phentsize*phnum
    eh = EI + struct.pack('<HHIIIIIHHHHHH',
        e_type,e_machine,e_version,e_entry,e_phoff,e_shoff,e_flags,
        ehsize,phentsize,phnum,e_shentsize,e_shnum,e_shstrndx)
    # program header PT_LOAD
    p_type=1; p_offset=code_off; p_vaddr=vaddr; p_paddr=vaddr
    p_filesz=len(code); p_memsz=len(code); p_flags=5; p_align=0x1000
    ph = struct.pack('<IIIIIIII', p_type,p_offset,p_vaddr,p_paddr,p_filesz,p_memsz,p_flags,p_align)
    with open(out,'wb') as f:
        f.write(eh); f.write(ph); f.write(code)

if __name__=='__main__':
    code=open(sys.argv[1],'rb').read()
    vaddr=int(sys.argv[2],0)
    make_elf(code, vaddr, sys.argv[3])
    print('wrote', sys.argv[3], 'vaddr', hex(vaddr), 'len', len(code))
