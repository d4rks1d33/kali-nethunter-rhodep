import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, SEGS, va_to_off, off_to_va, u32, u16, read_va, is_valid_va, seg_of

# Cluster de nombres de parametros TLV
NAME_LO=0xc414b000
NAME_HI=0xc414c200

# Escanear seg21 (rodata) buscando u32 que caigan en el rango de nombres
seg21=[s for s in SEGS if s[0]==21][0]
i,off,vaddr,pa,fsz,msz,fl=seg21
data=FULL[off:off+fsz]

hits=[]
for p in range(0, len(data)-4, 4):
    v=struct.unpack('<I',data[p:p+4])[0]
    if NAME_LO<=v<NAME_HI:
        va=vaddr+p
        hits.append((va,v))
print("total pointers into name-cluster found in seg21:", len(hits))
# Buscar runs contiguos (arrays de punteros): >=4 seguidos con stride constante
# Detectar posibles structs: mirar el gap entre punteros consecutivos
prev=None
runs=[]
cur=[]
for va,v in hits:
    if prev is None:
        cur=[(va,v)]
    else:
        cur.append((va,v))
    prev=va
# Analicemos distancias entre hits consecutivos para ver stride de struct
dists={}
for k in range(1,len(hits)):
    d=hits[k][0]-hits[k-1][0]
    dists[d]=dists.get(d,0)+1
print("stride histogram (distance between consecutive name-pointers):")
for d in sorted(dists, key=lambda x:-dists[x])[:15]:
    print("  stride=%d (0x%x): count=%d"%(d,d,dists[d]))
