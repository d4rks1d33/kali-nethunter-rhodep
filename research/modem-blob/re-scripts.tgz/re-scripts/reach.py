#!/usr/bin/env python3
# Definitive sound reachability using function boundaries [start,next_start).
import re, bisect, pickle, sys
LINES,ORDER,S = pickle.load(open('/tmp/modemre/_fns.pkl','rb'))
LO,HI=0xd8000000,0xd8a00000
SETTER=0xd8279264; GETTER=0xd827923c; APPLY=0xd8273b2c; RESOLVER=0xd8272684
EXECS={0xd826d7b0,0xd826d9b4,0xd826d3e4,0xd826d67c,0xd826db54,0xd826e090,0xd8272cd8,
       0xd8292298,0xd826e204,0xd826e458,0xd826e6bc}
CALLR_EDGES={0xd8272cd8:{0xd826d3e4,0xd8292298}}
BLACK={0xd814e6ac,0xd8829a00,0xd8829688,0xd8829698,0xd8829924,0xd8829a04,
 0xd80d77a8,0xd80d8998,0xd80d8988,0xd80d8990,0xd8041828,0xc0913a54,0xc0913ad8}
RET_TRAMP={0xd8829698,0xd8829688,0xd8829a00,0xd8829924,0xc0913b74,0xc0913a54,0xc0913ad8,0xc0913b6c,0xc0913bd8,0xd8829a04}
def is_ret(t): return t in RET_TRAMP or 0xc0913a00<=t<0xc0913c00

def fn_range(va):
    # if va is a known prologue, extent = [va, next prologue). else leaf: bounded window until a
    # terminal packet.
    i=bisect.bisect_right(S,va)-1
    if i>=0 and S[i]==va:
        nxt = S[i+1] if i+1<len(S) else va+0x800
        return va, min(nxt, va+0x2000)
    # leaf / mid-function target: scan until first terminal, cap 0x120
    return va, va+0x120

fc={}
def analyze(va):
    if va in fc: return fc[va]
    lo,hi=fn_range(va)
    i=bisect.bisect_left(ORDER,lo)
    cs=set(); ld=st=reg=callr=False
    is_leaf = not (bisect.bisect_right(S,va)-1>=0 and S[bisect.bisect_right(S,va)-1]==va)
    ended=False
    while i<len(ORDER):
        a=ORDER[i]
        if a>=hi: break
        ln=LINES[a]
        for c in re.findall(r'call (0x[0-9a-f]+)',ln): cs.add(int(c,16))
        for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
            jv=int(j,16)
            if is_ret(jv): continue
            # tail-call: jump outside [lo,hi)
            if LO<=jv<HI and not(lo<=jv<hi): cs.add(jv)
        if 'callr' in ln: callr=True
        if 'ca79c494' in ln:
            if re.search(r'memw\(##0xca79c494\)\s*=',ln): st=True
            elif 'memw(##0xca79c494)' in ln: ld=True
        if 'ca6e3228' in ln: reg=True
        if is_leaf:
            if 'dealloc_return' in ln or re.search(r'jumpr r31',ln): ended=True
            for j in re.findall(r'jump (0x[0-9a-f]+)',ln):
                if is_ret(int(j,16)): ended=True
            if ended and '}' in ln: break
        i+=1
    cs|=CALLR_EDGES.get(va,set())
    fc[va]=(cs,ld,st,reg,callr); return fc[va]

def bfs(root,maxd=30):
    seen=set();fr={root};d=0;hit={};callr_fns=set();path={root:None}
    while fr and d<maxd:
        nx=set()
        for x in fr:
            if x in seen:continue
            seen.add(x);cs,ld,st,reg,callr=analyze(x)
            if callr and x not in CALLR_EDGES:callr_fns.add(x)
            for t in list(EXECS)+[SETTER,GETTER,APPLY,RESOLVER]:
                if t in cs and t not in hit:hit[t]=x
            if ld:hit.setdefault('LOAD',x)
            if st:hit.setdefault('STORE',x)
            if reg:hit.setdefault('REGION',x)
            for c in cs:
                if c in BLACK:continue
                if LO<=c<HI and c not in seen:path.setdefault(c,x);nx.add(c)
        fr=nx-seen;d+=1
    return seen,hit,callr_fns,path
def chn(path,n):
    c=[]
    while n is not None:c.append(n);n=path.get(n)
    return list(reversed(c))
if __name__=='__main__':
    root=int(sys.argv[1],0)
    seen,hit,callr_fns,path=bfs(root)
    getter=(GETTER in hit) or ('LOAD' in hit)
    setter=(SETTER in hit) or ('STORE' in hit)
    print(f"{hex(root)}: resolver={RESOLVER in hit} getter={getter} setter={setter} "
          f"exec={any(e in hit for e in EXECS)} region={'REGION' in hit} "
          f"scanned={len(seen)} callr_unresolved={len(callr_fns)}")
    if '-v' in sys.argv:
        for lbl,k in [('RESOLVER',RESOLVER),('GETTER',GETTER),('SETTER',SETTER),('APPLY',APPLY)]:
            if k in hit: print(f"   {lbl}: {' -> '.join(hex(z) for z in chn(path,hit[k])+[k])}")
        if 'LOAD' in hit: print(f"   LOAD via: {' -> '.join(hex(z) for z in chn(path,hit['LOAD']))}")
    if '-c' in sys.argv:
        for f in sorted(callr_fns): print("   callr@",hex(f))
