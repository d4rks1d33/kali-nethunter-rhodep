#!/usr/bin/env python3
# Scan the 10MB image for immext(#0xca79c480) packets followed by memw/store or load of 0xca79c494.
# immext encodes bits [31:6] of the constant. For 0xca79c494, immext carries 0xca79c480 (upper bits),
# low 6 bits (0x14) come from the memw offset field.
import struct, sys
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_full.bin','rb').read()

# immext instruction: opcode 0000 (top nibble 0x0), 26-bit immediate = const>>6.
# const upper = 0xca79c494 >> 6 << 6 = 0xca79c480. immext imm26 = 0xca79c494>>6 = 0x329e7125? Let's compute
const=0xca79c494
imm26 = (const>>6)&0x3ffffff
# immext encoding: bits[27:16] high, bits[13:0]... actual: A2_immext: 0x0??????? with imm in [27:16]|[13:0]?
# Simpler: search for the exact 4-byte immext word we saw: 12 67 a7 0c = 0x0ca76712
IMMEXT_WORD = 0x0ca76712   # immext(#0xca79c480)
STORE_R0    = 0x4880c014   # memw(##0xca79c494) = r0
LOAD_R0     = 0x49804280   # r0 = memw(##0xca79c494)

def find_word(word):
    res=[]
    for off in range(0,len(data)-4,4):
        w=struct.unpack('<I',data[off:off+4])[0]
        if w==word:
            res.append(BASE+off)
    return res

print("immext(#0xca79c480) sites:", len(find_word(IMMEXT_WORD)))
imm=find_word(IMMEXT_WORD)
stores=find_word(STORE_R0)
loads=find_word(LOAD_R0)
print("STORE memw(##0xca79c494)=r0 sites:",[hex(x) for x in stores])
print("LOAD  r0=memw(##0xca79c494) sites:",[hex(x) for x in loads])
print("all immext(0xca79c480) VAs:")
for x in imm: print("  ",hex(x))
