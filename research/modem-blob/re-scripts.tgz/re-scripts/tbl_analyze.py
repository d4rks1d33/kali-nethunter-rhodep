import struct, sys
sys.path.insert(0,'/tmp/modemre')
from vmap import FULL, SEGS, va_to_off, read_va, u32, is_valid_va, seg_of

NAME_LO=0xc414b000
NAME_HI=0xc414c200

def cstr(va, maxlen=64):
    o=va_to_off(va)
    if o is None: return None
    d=FULL[o:o+maxlen]
    n=d.find(b'\x00')
    if n<0: n=maxlen
    try: return d[:n].decode('ascii')
    except: return repr(d[:n])

# Dump crudo de la region de la tabla desde 0xc906c294. Veamos como se ve palabra por palabra
start=0xc906c290
end=0xc906c290 + 0x400
o=va_to_off(start)
for va in range(start, end, 4):
    v=u32(va)
    tag=""
    if v is not None and NAME_LO<=v<NAME_HI:
        tag=" -> NAME '%s'"%cstr(v)
    elif v is not None and is_valid_va(v):
        tag=" (valid va seg%s)"%seg_of(v)
    print("0x%08x: 0x%08x%s"%(va,v if v is not None else 0,tag))
