#!/usr/bin/env python3
import struct,sys,bisect
BASE=0xd8000000
data=open('/tmp/modemre/clade_dec_36m.bin','rb').read()
N=len(data)
# Build call/jump target extraction on the fly per function window.
def val_imm(w):
    b_hi=(w>>16)&0x1ff; b_lo=(w>>1)&0x1fff
    imm=(b_hi<<13)|b_lo
    if imm&(1<<21): imm-=(1<<22)
    return imm<<2
# find all function prologues (allocframe / combine+allocframe) as boundaries: heuristic = any word with allocframe.
# Simpler: treat each call target as fn; scan a window [va, va+0x600] collecting call targets until we cap.
words=None
def w_at(va):
    off=va-BASE
    if off<0 or off+4>N: return None
    return struct.unpack('<I',data[off:off+4])[0]
def calls_in(va, span=0x800):
    out=set()
    off=va-BASE
    for a in range(off, min(off+span, N-3), 4):
        w=struct.unpack('<I',data[a:a+4])[0]
        op7=(w>>25)&0x7f
        cur=BASE+a
        if op7==0b0101101: # call
            t=cur+val_imm(w)
            if BASE<=t<BASE+N: out.add(('c',t))
        elif op7==0b0101100: # jump (tail-call if outside window)
            t=cur+val_imm(w)
            if BASE<=t<BASE+N and not(va<=t<va+span): out.add(('j',t))
        # detect dealloc_return to stop leaf scan
    return out

TARGETS={0xd81bd494,0xd81bd5fc,0xd81bd7c8,0xd8284eac,0xd8284cf4,0xd81bd018}
def bfs(root, maxnodes=20000):
    seen=set(); fr=[root]; parent={root:None}
    while fr:
        x=fr.pop()
        if x in seen: continue
        seen.add(x)
        if len(seen)>maxnodes: break
        for kind,t in calls_in(x):
            if t in TARGETS:
                # reconstruct path
                p=[t,x]; q=parent.get(x)
                while q is not None: p.append(q); q=parent.get(q)
                return True, t, list(reversed(p))
            if t not in seen and t not in parent:
                parent[t]=x; fr.append(t)
    return False, None, None

for name,root in [('0x10F=0xd8263e2c',0xd8263e2c),('0x4F5/7=0xd86f8514',0xd86f8514)]:
    ok,t,path=bfs(root)
    if ok:
        print(name,"REACHES",hex(t))
        print("   path:", " -> ".join(hex(z) for z in path))
    else:
        print(name,"does NOT reach any gate writer / accessor")
